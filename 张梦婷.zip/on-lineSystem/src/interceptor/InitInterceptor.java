package interceptor;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.Interceptor;

public class InitInterceptor implements Interceptor {

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}
	
	@Override
	public void init() {
		System.out.println("zzz:��������ʼ��");
	}

	@Override
	public String intercept(ActionInvocation actionInvocation) throws Exception {

		long start =new Date().getTime();
		String result=actionInvocation.invoke();
		long end =new Date().getTime();
		System.out.println("zzz:this request takes time "+(end-start)+" ms");
		return result;
	}

}
