package com.domain;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Paper {
	private int pid;
	private String title;
	private String subjects;
	private String type;//���Ա���
	private String state="δ����";//״̬��Ĭ��Ϊδ����      δ�������ڿ���/���Խ���
	private Date start;//����ʱ��
	private int minute;//����ʱ��
	private int countScore;//�Ծ��ܷ�
	private int countQuestion;//������
	private int average;//ÿ��ƽ����
	private String testClass;//���԰༶
	private Set<Question> setQuestion = new HashSet<Question>();
	private Set<Classes> setClasses = new HashSet<Classes>();
	
	
	public String getTestClass() {
		return testClass;
	}
	public void setTestClass(String testClass) {
		this.testClass = testClass;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSubjects() {
		return subjects;
	}
	public void setSubjects(String subjects) {
		this.subjects = subjects;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Date getStart() {
		return start;
	}
	public void setStart(Date start) {
		this.start = start;
	}
	public int getMinute() {
		return minute;
	}
	public void setMinute(int minute) {
		this.minute = minute;
	}
	public int getCountScore() {
		return countScore;
	}
	public void setCountScore(int countScore) {
		this.countScore = countScore;
	}
	public int getCountQuestion() {
		return countQuestion;
	}
	public void setCountQuestion(int countQuestion) {
		this.countQuestion = countQuestion;
	}
	public int getAverage() {
		return average;
	}
	public void setAverage(int average) {
		this.average = average;
	}
	public Set<Question> getSetQuestion() {
		return setQuestion;
	}
	public void setSetQuestion(Set<Question> setQuestion) {
		this.setQuestion = setQuestion;
	}
	public Set<Classes> getSetClasses() {
		return setClasses;
	}
	public void setSetClasses(Set<Classes> setClasses) {
		this.setClasses = setClasses;
	}
}
