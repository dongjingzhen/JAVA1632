package com.domain;

public class Teacher {
	private int id;
	private String taccount;
	private String tpwd;
	private String tname;
	private String tsex;
	private String tbirthday;
	private String teducation;
	private String ttelphone;
	private String tjop;
	private String remarks;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTaccount() {
		return taccount;
	}
	public void setTaccount(String taccount) {
		this.taccount = taccount;
	}
	public String getTpwd() {
		return tpwd;
	}
	public void setTpwd(String tpwd) {
		this.tpwd = tpwd;
	}
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public String getTsex() {
		return tsex;
	}
	public void setTsex(String tsex) {
		this.tsex = tsex;
	}
	public String getTbirthday() {
		return tbirthday;
	}
	public void setTbirthday(String tbirthday) {
		this.tbirthday = tbirthday;
	}
	public String getTeducation() {
		return teducation;
	}
	public void setTeducation(String teducation) {
		this.teducation = teducation;
	}
	public String getTtelphone() {
		return ttelphone;
	}
	public void setTtelphone(String ttelphone) {
		this.ttelphone = ttelphone;
	}
	public String getTjop() {
		return tjop;
	}
	public void setTjop(String tjop) {
		this.tjop = tjop;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
}
