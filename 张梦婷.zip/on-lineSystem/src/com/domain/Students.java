package com.domain;

import java.util.Date;

public class Students {
	
	private int id;
	private String pwd;  //��¼����
	private String xueHao; //ѧ��
	private String studentName; //ѧ������
	private String sex;  //�Ա�
	private String inDate;//��ѧ���
	private Date birthday; //����
	private Classes classes;  //�����༶
	private String idCard;  //����֤��
	private String zhengzLook; //������ò
	private String shengFen;  //ʡ��
	private String city; //ʡ��
	private String zhuanYe;  //רҵ���
	private String jiudu; //�Ͷ�����
	private String telephone;//��ϵ�绰
	private String liveAdress;//��ͥסַ
	private String parentsTel;//�ҳ���ϵ�绰
	private String releation;//�໤����ѧ����ϵ
	private String sushe; //����
	private String susheNum;//�����
	private String baseInfo; //������Ϣ
	private String edcutionBg; //��������
	private String beizhu; //��ע
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getXueHao() {
		return xueHao;
	}
	public void setXueHao(String xueHao) {
		this.xueHao = xueHao;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getInDate() {
		return inDate;
	}
	public void setInDate(String inDate) {
		this.inDate = inDate;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	public Classes getClasses() {
		return classes;
	}
	public void setClasses(Classes classes) {
		this.classes = classes;
	}
	public String getIdCard() {
		return idCard;
	}
	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}
	public String getZhengzLook() {
		return zhengzLook;
	}
	public void setZhengzLook(String zhengzLook) {
		this.zhengzLook = zhengzLook;
	}
	public String getShengFen() {
		return shengFen;
	}
	public void setShengFen(String shengFen) {
		this.shengFen = shengFen;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getZhuanYe() {
		return zhuanYe;
	}
	public void setZhuanYe(String zhuanYe) {
		this.zhuanYe = zhuanYe;
	}
	public String getJiudu() {
		return jiudu;
	}
	public void setJiudu(String jiudu) {
		this.jiudu = jiudu;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getLiveAdress() {
		return liveAdress;
	}
	public void setLiveAdress(String liveAdress) {
		this.liveAdress = liveAdress;
	}
	public String getParentsTel() {
		return parentsTel;
	}
	public void setParentsTel(String parentsTel) {
		this.parentsTel = parentsTel;
	}
	public String getReleation() {
		return releation;
	}
	public void setReleation(String releation) {
		this.releation = releation;
	}
	public String getSushe() {
		return sushe;
	}
	public void setSushe(String sushe) {
		this.sushe = sushe;
	}
	public String getSusheNum() {
		return susheNum;
	}
	public void setSusheNum(String susheNum) {
		this.susheNum = susheNum;
	}
	public String getBaseInfo() {
		return baseInfo;
	}
	public void setBaseInfo(String baseInfo) {
		this.baseInfo = baseInfo;
	}
	public String getEdcutionBg() {
		return edcutionBg;
	}
	public void setEdcutionBg(String edcutionBg) {
		this.edcutionBg = edcutionBg;
	}
	public String getBeizhu() {
		return beizhu;
	}
	public void setBeizhu(String beizhu) {
		this.beizhu = beizhu;
	}
	
	
	
	
	
	

}
