package action;
import java.util.ArrayList;
import java.util.List;
import org.apache.struts2.ServletActionContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;


import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;
import domain.Admin;
import domain.Classes;
import domain.PageBean;
import domain.Students;
import domain.Teacher;
import domain.TestPaper;
import domain.TiKu;

public class UserAction implements Action {
	private String name;
	private int bid;
	private int tkid;//���id
	@SuppressWarnings("unchecked")
	private List list;
	private Admin admin;
	private List<Object[]> tikuList=new ArrayList<Object []>();
	private List<Students> studentList=new ArrayList<Students>();
	private List<Classes> classList = new ArrayList<Classes>();
	private List<TiKu> tkList=new ArrayList<TiKu>();
	private TiKu tiku;
	private TestPaper testPaper=new TestPaper();
	private List<TestPaper> paperList=new ArrayList<TestPaper>();
	
	
	
	
	
	
	public String list(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "list";
	}
	
	
	/*
	 * ��¼��֤
	 */
	public String admins(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		if (bid==1) {
			list=session.createCriteria(Students.class).list();
			for (int i = 0; i <list.size(); i++) {
				Students stu=(Students) list.get(i);
				if (stu. getsNo().equals(admin.getAname())&&stu.getPwd().equals(admin.getPwd())) {
					ServletActionContext.getRequest().getSession().setAttribute("bm",1);
					ServletActionContext.getRequest().getSession().setAttribute("aname", stu.getSname());
					return "admins";
				}
			}
		}else if (bid==2) {
			list=session.createCriteria(Teacher.class).list();
			for (int i = 0; i <list.size(); i++) {
				Teacher tea=(Teacher) list.get(i);
				if (tea.gettNo().equals(admin.getAname())&&tea.getPwd().equals(admin.getPwd())) {
					ServletActionContext.getRequest().getSession().setAttribute("bm",2);
					ServletActionContext.getRequest().getSession().setAttribute("aname", tea.getTname());
					return "admins";
				}
			}
		}else if (bid==4) {
			list=session.createCriteria(Admin.class).list();
			for (int i = 0; i <list.size(); i++) {
				Admin a=(Admin) list.get(i);
				if (a.getAname().equals(admin.getAname())&&a.getPwd().equals(admin.getPwd())) {
					ServletActionContext.getRequest().getSession().setAttribute("bm",3);
					ServletActionContext.getRequest().getSession().setAttribute("aname", a.getAname());
					return "admins";
				}
			}
		}
		name="�˺Ż��������";
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return ERROR;
	}
	
	/*
	 * ע����¼
	 */
	public String login(){
		
		return "login";
	}
	
	/*
	 * ��ʾ���ѡ��
	 */
	public String showTiKu()
	{
		return "showTiKu";
	}
	
	//��ѯ�������
	@SuppressWarnings("unchecked")
	public String tiku()
	{
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		//����һ��Criteria��ѯ
		Criteria criteria=session.createCriteria(TiKu.class);//��ѯ������
		
		//����һ��projections,ָ��ͶӰ������
		ProjectionList projectionsList=Projections.projectionList()
										.add(Projections.groupProperty("direction"))//��������רҵ����
										.add(Projections.groupProperty("keMu"))//�������Ľ׶η���
										.add(Projections.groupProperty("jiWrite"))//���������������������� ���ͣ����ǻ��Ի�����⣩����
										.add(Projections.count("tkid").as("count"));//ͳ������ĸ���
		//��ͶӰ���������ӵ���ѯ�����
		criteria.setProjection(projectionsList);
		
	    tikuList=criteria.list();//�ŵ�������ļ��ϣ����ص���List<Object []>,�������ĸ�����
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "tiku";
	}
	//��ѯ����
	@SuppressWarnings("unchecked")
	public String test()
	{
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		String direction = ServletActionContext.getRequest().getParameter("direction");
		String keMu = ServletActionContext.getRequest().getParameter("keMu");
		String jiWrite = ServletActionContext.getRequest().getParameter("jiWrite");
		System.out.println(jiWrite);
		Criteria criteria=session.createCriteria(TiKu.class)
						.add(Restrictions.eq("direction", direction))
						.add(Restrictions.eq("keMu", keMu))
						.add(Restrictions.eq("jiWrite", jiWrite));
		
									
		//ͶӰ�����б����ӵ�Criteriaʵ���н���ͶӰ��ѯ				
		tkList  = criteria.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		return "test";
		
	}
	//��ת�������������
	public String addti()
	{
		return "addti";
		
	}
	//��������
	public String toaddti()
	{
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		String direction = ServletActionContext.getRequest().getParameter("direction");
		String keMu = ServletActionContext.getRequest().getParameter("keMu");
		String tiType = ServletActionContext.getRequest().getParameter("tiType");
		String difficult = ServletActionContext.getRequest().getParameter("difficult");
		String tiTitle = ServletActionContext.getRequest().getParameter("tiTitle");
		String optionA = ServletActionContext.getRequest().getParameter("optionA");
		String optionB = ServletActionContext.getRequest().getParameter("optionB");
		String optionC = ServletActionContext.getRequest().getParameter("optionC");
		String optionD = ServletActionContext.getRequest().getParameter("optionD");
		String answer = ServletActionContext.getRequest().getParameter("answer");
		String jiWrite = ServletActionContext.getRequest().getParameter("jiWrite");
		TiKu tiKu = new TiKu();
		tiKu.setDirection(direction);
		tiKu.setKeMu(keMu);
		tiKu.setTiType(tiType);
		tiKu.setDifficult(difficult);
		tiKu.setTiTitle(tiTitle);
		tiKu.setOptionA(optionA);
		tiKu.setOptionA(optionB);
		tiKu.setOptionA(optionC);
		tiKu.setOptionA(optionD);
		tiKu.setAnswer(answer);
		tiKu.setJiWrite(jiWrite);
		
		session.save(tiKu);

		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		return "toaddti";
		
	}

	/*
	 * �����Ծ�ҳ��
	 */
	@SuppressWarnings("unchecked")
	public String testPaper(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		Criteria criteria=session.createCriteria(TestPaper.class);
		paperList = criteria.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		return "testPaper";
	}
	//���������Ծ�����
	public String showTestPaper()
	{
		return "showTestPaper";
	}
	//�����Ծ�����
	@SuppressWarnings("unchecked")
	public String toAddPaper(){
		
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		
		
		//��ȡ�����������id��list���Ͻ���
		List<Integer> qidList= session.createSQLQuery("select tkid from " +
				"(select top 2 tkid from t_tiku where keMu='Struts2' and tiType='��ѡ'  and difficult= '��' and jiWrite='����'  order by newId() " +
				"union " +
				"select top 2 tkid from t_tiku where keMu='Struts2' and tiType='��ѡ'  and difficult= '�е�' and jiWrite='����'  order by newId() " +
				"union " +
				"select top 2 tkid from t_tiku where keMu='SQL_Server' and tiType='��ѡ'  and difficult= '����' and jiWrite='����'  order by newId() " +
				"union " +
				"select top 2 tkid from t_tiku where keMu='Hibernate' and tiType='��ѡ'  and difficult= '��' and jiWrite='����'  order by newId() " +
				"union " +
				"select top 2 tkid from t_tiku where keMu='Hibernate' and tiType='��ѡ'  and difficult= '�е�' and jiWrite='����'  order by newId()" +
				") as t").list();
		
		
		System.out.println("���ȣ�"+qidList);
		
		for (Integer inte : qidList) {
			TiKu tiku1 =  (TiKu)session.get(TiKu.class,inte);
			System.out.println(inte+":"+tiku1.getTkid());
			testPaper.getTopicSet().add(tiku1);
		}
		session.save(testPaper);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		return "";
	}
	
	/*
	 * ��ת��ѧ��ҳ��
	 */
	@SuppressWarnings("unchecked")
	public String student(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		Criteria criteria=session.createCriteria(Students.class);
		studentList = criteria.list();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "student";
	}
	//��ת������ѧ��ҳ��
	public String addstu()
	{
		return "addstu";
	}
	public String toaddstu(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		//���֮ǰ���������רҵ�ͽ׶�
//		String major=(String) ServletActionContext.getRequest().getSession().getAttribute("major");
//		String stage=(String) ServletActionContext.getRequest().getSession().getAttribute("stage");
//		//����רҵ�ͽ׶λ��������
//		Questions tiku=(Questions)session.createCriteria(Questions.class)
//			.add(Restrictions.eq("major", major))
//			.add(Restrictions.eq("stage", stage))
//			.uniqueResult();

		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "toaddstu";
	}
	
	/*
	 * ��ת���༶ҳ�沢��ʾ����
	 */
	@SuppressWarnings("unchecked")
	public String classes(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		Criteria criteria=session.createCriteria(Classes.class);
		classList = criteria.list();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "classes";
	}
	//��ת���Ӱ༶showClasses
	public String showClasses()
	{
		return "showClasses";
	}
	//���Ӱ༶
	public String toClasses(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		

		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "toClasses";
	}
	//���Գɼ�����
	public String scoreShow()
	{
		return "scoreShow";
	}
	
	/*
	 * ��ʾ������Ϣ
	 */
	public String myMessage()
	{
		return "myMessage";
		
	}
	//���Կ�Ŀ����
	public String testOnli()
	{
		return "testOnli";
	}
	//���Գɼ�ҳ��
	public String score()
	{
		return "score";
	}
	
	

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	public int getTkid() {
		return tkid;
	}


	public void setTkid(int tkid) {
		this.tkid = tkid;
	}


	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	@SuppressWarnings("unchecked")
	public List getList() {
		return list;
	}
	@SuppressWarnings("unchecked")
	public void setList(List list) {
		this.list = list;
	}
	public Admin getAdmin() {
		return admin;
	}
	public void setAdmin(Admin admin) {
		this.admin = admin;
	}
	public List<Object[]> getTikuList() {
		return tikuList;
	}
	public void setTikuList(List<Object[]> tikuList) {
		this.tikuList = tikuList;
	}
	public List<Classes> getClassList() {
		return classList;
	}
	public void setClassList(List<Classes> classList) {
		this.classList = classList;
	}
	public List<TiKu> getTkList() {
		return tkList;
	}
	public void setTkList(List<TiKu> tkList) {
		this.tkList = tkList;
	}
	public List<Students> getStudentList() {
		return studentList;
	}
	public void setStudentList(List<Students> studentList) {
		this.studentList = studentList;
	}
	public List<TestPaper> getPaperList() {
		return paperList;
	}
	public void setPaperList(List<TestPaper> paperList) {
		this.paperList = paperList;
	}
	
	public TestPaper getTestPaper() {
		return testPaper;
	}
	public void setTestPaper(TestPaper testPaper) {
		this.testPaper = testPaper;
	}


	public TiKu getTiku() {
		return tiku;
	}
	public void setTiku(TiKu tiku) {
		this.tiku = tiku;
	}
	
	
	
	
}
