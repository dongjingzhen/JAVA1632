package domain;

import java.util.HashSet;
import java.util.Set;

public class TiKu {
	
	private int tkid;
	
	private String direction;//רҵ����
	
	private String keMu;//��Ŀ
	
	private String tiType;//�������ͣ���ѡ���ѡ��

	private String difficult;//�����Ѷ�
	
	private String tiTitle;//������Ŀ
	
	private String optionA;//ѡ��
	
	private String optionB;
	
	private String optionC;
	
	private String optionD;
	
	private String answer;//��
	
	private String jiWrite;// ����/����


	private Set<TestPaper> tiSet = new HashSet<TestPaper>();//

	
	public TiKu(){}
	public TiKu(String tiType,String tiTitle,String optionA,
				String optionB,String optionC,String optionD,
				String answer,String direction,String keMu,
				String difficult,String jiWrite)
	{
		this.tiType = tiType;
		this.tiTitle = tiTitle;
		this.optionA = optionA;
		this.optionB = optionB;
		this.optionC = optionC;
		this.optionD = optionD;
		this.answer = answer;
		this.direction = direction;
		this.keMu = keMu;
		this.difficult = difficult;
		this.jiWrite  =jiWrite;
		
	}
	
	
	public int getTkid() {
		return tkid;
	}
	public void setTkid(int tkid) {
		this.tkid = tkid;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getKeMu() {
		return keMu;
	}
	public void setKeMu(String keMu) {
		this.keMu = keMu;
	}
	public String getTiType() {
		return tiType;
	}
	public void setTiType(String tiType) {
		this.tiType = tiType;
	}
	public String getDifficult() {
		return difficult;
	}
	public void setDifficult(String difficult) {
		this.difficult = difficult;
	}
	public String getTiTitle() {
		return tiTitle;
	}
	public void setTiTitle(String tiTitle) {
		this.tiTitle = tiTitle;
	}
	public String getOptionA() {
		return optionA;
	}
	public void setOptionA(String optionA) {
		this.optionA = optionA;
	}
	public String getOptionB() {
		return optionB;
	}
	public void setOptionB(String optionB) {
		this.optionB = optionB;
	}
	public String getOptionC() {
		return optionC;
	}
	public void setOptionC(String optionC) {
		this.optionC = optionC;
	}
	public String getOptionD() {
		return optionD;
	}
	public void setOptionD(String optionD) {
		this.optionD = optionD;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getJiWrite() {
		return jiWrite;
	}
	public void setJiWrite(String jiWrite) {
		this.jiWrite = jiWrite;
	}
	public Set<TestPaper> getTiSet() {
		return tiSet;
	}
	public void setTiSet(Set<TestPaper> tiSet) {
		this.tiSet = tiSet;
	}


}
