package domain;

public class Students {
	private int sid;
	
	private String sNo;//���
	
	private String pwd;//����
	
	private String sname;//����
	
	private String sphone;//�绰
	
	private Classes classes;//���ڰ༶
	
	
	public Students(){}
	public Students(String sNo,String pwd,String sname,String sphone)
	{
		this.sNo = sNo;
	this.sname = sname;
			this.pwd = pwd;
		this.sphone = sphone;
	}

	
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getsNo() {
		return sNo;
	}
	public void setsNo(String sNo) {
		this.sNo = sNo;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getSphone() {
		return sphone;
	}
	public void setSphone(String sphone) {
		this.sphone = sphone;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public Classes getClasses() {
		return classes;
	}
	public void setClasses(Classes classes) {
		this.classes = classes;
	}
	

}
