package domain;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

//�Ծ�
public class TestPaper {
	
	private int tid;
	
	private String tpName;//�Ծ���
	
//	private String state;//״̬     1δ���� 2���ڿ��� 3���Խ���
	
//	private Date startTime;//��ʼ���Ե�ʱ��   yyyy-MM-dd
	
	private int minute;//����ʱ������λ������
	
	private int countage;//�ܷ�
	
	private int average;//ƽ����
	
	private int coun;//������
	
	
	
	private Set<TiKu> topicSet=new HashSet<TiKu>();//���Ծ��е����⼯�ϣ�����л�ȡ��
	
	private Set<Classes> classSet=new HashSet<Classes>();//��Ҫ�����Ծ��İ༶����
	
	
	public TestPaper(){}
	public TestPaper(String tpName,int minute,int countage,int average,int coun){
		
		this.tpName = tpName;
		this.minute = minute;
		this.countage = countage;
		this.average =average;
		this.coun = coun;
	}
	
	
	
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public String getTpName() {
		return tpName;
	}
	public void setTpName(String tpName) {
		this.tpName = tpName;
	}
//	public String getState() {
//		return state;
//	}
//	public void setState(String state) {
//		this.state = state;
//	}
//	public Date getStartTime() {
//		return startTime;
//	}
//	public void setStartTime(Date startTime) {
//		this.startTime = startTime;
//	}
	public int getMinute() {
		return minute;
	}
	public void setMinute(int minute) {
		this.minute = minute;
	}
	public Set<TiKu> getTopicSet() {
		return topicSet;
	}
	public void setTopicSet(Set<TiKu> topicSet) {
		this.topicSet = topicSet;
	}
	public Set<Classes> getClassSet() {
		return classSet;
	}
	public void setClassSet(Set<Classes> classSet) {
		this.classSet = classSet;
	}
	public int getCountage() {
		return countage;
	}
	public void setCountage(int countage) {
		this.countage = countage;
	}
	public int getAverage() {
		return average;
	}
	public void setAverage(int average) {
		this.average = average;
	}
	public int getCoun() {
		return coun;
	}
	public void setCoun(int coun) {
		this.coun = coun;
	}
	
	
	
	
	
}
