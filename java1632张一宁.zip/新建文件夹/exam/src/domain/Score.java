package domain;
//�ɼ�
public class Score {
	private int sid;
	
	
	private String score;//ѧ���Ŀ��Գɼ�
	
	private TestPaper testPaper;//���Ե��Ծ�
	
	private Students student;//���Ե�ѧ��
	
	
	public  Score() {}
	public  Score(String score) {
		
		this.score = score;
	}
	

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}

	public TestPaper getTestPaper() {
		return testPaper;
	}

	public void setTestPaper(TestPaper testPaper) {
		this.testPaper = testPaper;
	}

	public Students getStudent() {
		return student;
	}

	public void setStudent(Students student) {
		this.student = student;
	}
	
}
