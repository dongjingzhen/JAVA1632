package domain;

import java.util.Date;

public class Teacher {
	private int tid;
	private String tNo;//���
	private String pwd;//����
	private String tname;//����
	private String tsex;//�Ա�
	private Date tbirthday;//����
	private String telphone;//�绰;
	private String job;//ְλ
	private Classes classes;//���ڰ༶
	
	public Teacher(){}
	public Teacher(String tNo,String pwd,String tname,String tsex,
			Date tbirthday,String telphone,String job)
	{
		this.tNo = tNo;
		this.tname = tname;
		this.tsex = tsex;
		this.tbirthday = tbirthday;
		this.telphone = telphone;
		this.job= job;
	}
	
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public String gettNo() {
		return tNo;
	}
	public void settNo(String tNo) {
		this.tNo = tNo;
	}
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public String getTsex() {
		return tsex;
	}
	public void setTsex(String tsex) {
		this.tsex = tsex;
	}
	public Date getTbirthday() {
		return tbirthday;
	}
	public void setTbirthday(Date tbirthday) {
		this.tbirthday = tbirthday;
	}
	public String getTelphone() {
		return telphone;
	}
	public void setTelphone(String telphone) {
		this.telphone = telphone;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public Classes getClasses() {
		return classes;
	}
	public void setClasses(Classes classes) {
		this.classes = classes;
	}
	
	

}
