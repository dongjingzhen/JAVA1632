package domain;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Classes {
	private int cid;
	private String cname;//�༶����
	private String cNo;//�༶���
	private Date ctime;//��������
	private String cstatus;//״̬
	private Set<Teacher> teacherSet=new HashSet<Teacher>();
	private Set<Students> studentSet=new HashSet<Students>();
	
	public Classes(){}
	public Classes(String cNo,String cname,
			Date ctime,String cstatus)
	{
		this.cNo = cNo;
		this.cname = cname;
		this.ctime = ctime;
		this.cstatus = cstatus;
	}
	
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	
	public String getcNo() {
		return cNo;
	}
	public void setcNo(String cNo) {
		this.cNo = cNo;
	}
	public Date getCtime() {
		return ctime;
	}
	public void setCtime(Date ctime) {
		this.ctime = ctime;
	}
	public String getCstatus() {
		return cstatus;
	}
	public void setCstatus(String cstatus) {
		this.cstatus = cstatus;
	}
	public Set<Teacher> getTeacherSet() {
		return teacherSet;
	}
	public void setTeacherSet(Set<Teacher> teacherSet) {
		this.teacherSet = teacherSet;
	}
	public Set<Students> getStudentSet() {
		return studentSet;
	}
	public void setStudentSet(Set<Students> studentSet) {
		this.studentSet = studentSet;
	}
	

}
