package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class text {
	public static void main(String[] args) {
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		List<Dept> lis=session.createCriteria(Dept.class).list();
		for (Dept s : lis) {
			System.out.println(s.toString());
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}

}
