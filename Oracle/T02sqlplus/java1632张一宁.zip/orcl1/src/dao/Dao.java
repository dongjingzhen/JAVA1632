package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class Dao {
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		Session session=HibernateSessionFactory.getSession();
		
		List<Dept> list=session.createCriteria(Dept.class).list();
		for (Dept d : list) {
			System.out.println(d.toString());
		}
		
		HibernateSessionFactory.closeSession();
	}

}
