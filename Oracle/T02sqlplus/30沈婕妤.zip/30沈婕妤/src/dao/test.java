package dao;

import org.hibernate.Session;

public class test {
	public static void main(String[] args) {
		Session session=HibernateSessionFactory.getSession();
	     Dept e =	(Dept) session.get(Dept.class, 10);

		System.out.println(e);
	}

	
}
