package action;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.opensymphony.xwork2.Action;
import com.sun.corba.se.impl.activation.ServerTableEntry;

import dao.HibernateSessionFactory;
import domain.Paper;
import domain.Question;
import domain.Score;
import domain.Student;

public class ExamAction implements Action {
	private List<Paper> paperList = new ArrayList<Paper>();
	private int pid;
	private Paper paper;
	private Set<Paper> paperSet = new HashSet<Paper>();
	private Question question;
	private Integer questionIndex;
	private Integer questionReadyIndex;
	private List<Score> scoreList = new ArrayList<Score>();
	
	

	public List<Score> getScoreList() {
		return scoreList;
	}
	public void setScoreList(List<Score> scoreList) {
		this.scoreList = scoreList;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	public Integer getQuestionIndex() {
		return questionIndex;
	}
	public void setQuestionIndex(Integer questionIndex) {
		this.questionIndex = questionIndex;
	}
	public Integer getQuestionReadyIndex() {
		return questionReadyIndex;
	}
	public void setQuestionReadyIndex(Integer questionReadyIndex) {
		this.questionReadyIndex = questionReadyIndex;
	}
	public Set<Paper> getPaperSet() {
		return paperSet;
	}
	public void setPaperSet(Set<Paper> paperSet) {
		this.paperSet = paperSet;
	}
	public Paper getPaper() {
		return paper;
	}
	public void setPaper(Paper paper) {
		this.paper = paper;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public List<Paper> getPaperList() {
		return paperList;
	}
	public void setPaperList(List<Paper> paperList) {
		this.paperList = paperList;
	}

	//�鿴�����Ծ�
	public String stushowPaper(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		String loginName = (String) ServletActionContext.getRequest().getSession().getAttribute("name");
		Student student = (Student) session.createCriteria(Student.class).add(Restrictions.eq("stuNo", loginName)).uniqueResult();
		paperSet=student.getClasses().getPaperSet();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "stushowpaper";	
	}
	//��ʼ����
	public String getOnepaperQuest(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Map questionMap = (Map) ServletActionContext.getRequest().getSession().getAttribute("questionMap");
		if(questionMap==null){
			paper= (Paper) session.get(Paper.class, pid);
			ServletActionContext.getRequest().getSession().setAttribute("paper", paper);
			questionMap = new HashMap();
			Set<Question> questionSet = null;
			questionSet = paper.getQuestionSet();
			Integer i = 1;
			for (Question question : questionSet) {
				questionMap.put(i, question);
				i++;
			}
			ServletActionContext.getRequest().getSession().setAttribute("questionMap", questionMap);
		}else{
			if(question!=null){
				questionMap.put(questionIndex, question);
				questionIndex = questionReadyIndex;
			}
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "getOnepaperQ";
	}
	//��ɿ���
	public String accexam(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Map<Integer,Question> queMap =  (Map<Integer, Question>) ServletActionContext.getRequest().getSession().getAttribute("questionMap");
		int j = 0 ;
		for (int i = 1; i < queMap.size()+1; i++) {
			Question que = (Question) queMap.get(i);
			System.out.println(que.getAnswer()+que.getDaan());
			if (que.getAnswer().equals(que.getDaan())) {
				j++;
			}
		}
		
		Paper paper = (Paper) ServletActionContext.getRequest().getSession().getAttribute("paper");
		j=j*paper.getAvgScore();
		System.out.println(j);
		String loginName = (String) ServletActionContext.getRequest().getSession().getAttribute("name");
		Student student = (Student) session.createCriteria(Student.class).add(Restrictions.eq("stuNo", loginName)).uniqueResult();
		Score s = new Score();
		s.setScName(student.getStuName());
		s.setScClasses(student.getClasses().getClassName());
		s.setScTitle(paper.getTitle());
		s.setScScore(j);
		s.setStartTime(new Date());
		s.setEndTime(new Date());
		session.save(s);
		ServletActionContext.getRequest().getSession().removeAttribute("paper");
		ServletActionContext.getRequest().getSession().removeAttribute("questionMap");
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "yesKaoshi";
		
	}
	//�鿴���Գɼ�
	public String getBiscore(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		String loginName = (String) ServletActionContext.getRequest().getSession().getAttribute("name");
		Student student = (Student) session.createCriteria(Student.class).add(Restrictions.eq("stuNo", loginName)).uniqueResult();
		Criteria criteria = (Criteria) session.createCriteria(Score.class).add(Restrictions.eq("scName", student.getStuName()));
		scoreList = criteria.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "showStuentSc";
		
	}
	//�鿴�����Ծ�
	public String showBpaper(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return null;
		
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
}
