package domain;

import java.util.Date;

public class Score {
	private int scId;
	private String scName;//����
	private String scClasses;//�༶
	private String scTitle;//����
	private int scScore;//����
	private Date startTime;//��ʼʱ��
	private Date endTime;//����ʱ��
	
	public int getScId() {
		return scId;
	}
	public void setScId(int scId) {
		this.scId = scId;
	}
	public String getScName() {
		return scName;
	}
	public void setScName(String scName) {
		this.scName = scName;
	}
	public String getScClasses() {
		return scClasses;
	}
	public void setScClasses(String scClasses) {
		this.scClasses = scClasses;
	}
	public String getScTitle() {
		return scTitle;
	}
	public void setScTitle(String scTitle) {
		this.scTitle = scTitle;
	}
	public int getScScore() {
		return scScore;
	}
	public void setScScore(int scScore) {
		this.scScore = scScore;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	
	
	
}
