package domain;

public class Scoredetails {
	private int scID;
	private String studentid;//ѧ��ID
	private String paperid;//�Ծ�ID
	private String questionid;//����ID
	private String answer;//��
	
	
	

}
