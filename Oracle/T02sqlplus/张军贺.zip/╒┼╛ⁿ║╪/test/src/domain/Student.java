package domain;
/*
 * ѧ����
 */
public class Student {
	private int sid;
	private String stuNo;//ѧ��
	private String stuPwd;//����
	private Classes classes;//�༶����
	private String stuName;//ѧ������
	private String stuSex;//ѧ���Ա�
	private String stuTelphone;//ѧ���绰
	private String parentPhone;//�ҳ��绰
	private String stuSchoolyear;//ѧ��
	private String stubrithday;//ѧ������
	private String stuProvide;//ʡ��
	private String stuMajor;//ѧ��רҵ
	private String stuParent;//�ҳ�
	private String stuDrom;//����
	private String stuDromNo;//�����
	private String basicSituation;//�������
	private String educational;//��������
	private String guardian;//�໤�˹�ϵ
	private String address;//סַ
	private String city;//����
	private String studyDirection;//�Ͷ�����
	private String image;//��Ƭ
	private String political;//������ò

	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getStuNo() {
		return stuNo;
	}
	public void setStuNo(String stuNo) {
		this.stuNo = stuNo;
	}
	public String getStuPwd() {
		return stuPwd;
	}
	public void setStuPwd(String stuPwd) {
		this.stuPwd = stuPwd;
	}
	
	public Classes getClasses() {
		return classes;
	}
	public void setClasses(Classes classes) {
		this.classes = classes;
	}
	public String getStuName() {
		return stuName;
	}
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}
	public String getStuSex() {
		return stuSex;
	}
	public void setStuSex(String stuSex) {
		this.stuSex = stuSex;
	}
	public String getStuTelphone() {
		return stuTelphone;
	}
	public void setStuTelphone(String stuTelphone) {
		this.stuTelphone = stuTelphone;
	}
	public String getParentPhone() {
		return parentPhone;
	}
	public void setParentPhone(String parentPhone) {
		this.parentPhone = parentPhone;
	}
	public String getStuSchoolyear() {
		return stuSchoolyear;
	}
	public void setStuSchoolyear(String stuSchoolyear) {
		this.stuSchoolyear = stuSchoolyear;
	}
	public String getStubrithday() {
		return stubrithday;
	}
	public void setStubrithday(String stubrithday) {
		this.stubrithday = stubrithday;
	}
	public String getStuProvide() {
		return stuProvide;
	}
	public void setStuProvide(String stuProvide) {
		this.stuProvide = stuProvide;
	}
	public String getStuMajor() {
		return stuMajor;
	}
	public void setStuMajor(String stuMajor) {
		this.stuMajor = stuMajor;
	}
	public String getStuParent() {
		return stuParent;
	}
	public void setStuParent(String stuParent) {
		this.stuParent = stuParent;
	}
	public String getStuDrom() {
		return stuDrom;
	}
	public void setStuDrom(String stuDrom) {
		this.stuDrom = stuDrom;
	}
	public String getStuDromNo() {
		return stuDromNo;
	}
	public void setStuDromNo(String stuDromNo) {
		this.stuDromNo = stuDromNo;
	}
	public String getBasicSituation() {
		return basicSituation;
	}
	public void setBasicSituation(String basicSituation) {
		this.basicSituation = basicSituation;
	}
	public String getEducational() {
		return educational;
	}
	public void setEducational(String educational) {
		this.educational = educational;
	}
	public String getGuardian() {
		return guardian;
	}
	public void setGuardian(String guardian) {
		this.guardian = guardian;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getStudyDirection() {
		return studyDirection;
	}
	public void setStudyDirection(String studyDirection) {
		this.studyDirection = studyDirection;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getPolitical() {
		return political;
	}
	public void setPolitical(String political) {
		this.political = political;
	}
	
	
	
}