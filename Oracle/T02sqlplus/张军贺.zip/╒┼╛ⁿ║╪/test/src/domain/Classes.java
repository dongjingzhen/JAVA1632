package domain;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/*
 * �༶��
 */
public class Classes {
	private int cid;
	private String classNo;//�༶���
	private String className;//�༶����
	private String direction;//��������
	private Teacher headteacher; //������
	private Teacher lecturer; //��ʦ��
	private Date date;//��������
	private String state;//״̬
	private Set<Student> studentSet = new HashSet<Student>();//���ѧ���ļ���
	private Set<Paper> paperSet = new HashSet<Paper>();//����Ծ��ļ���
	
	
	
	public Set<Paper> getPaperSet() {
		return paperSet;
	}
	public void setPaperSet(Set<Paper> paperSet) {
		this.paperSet = paperSet;
	}
	public Set<Student> getStudentSet() {
		return studentSet;
	}
	public void setStudentSet(Set<Student> studentSet) {
		this.studentSet = studentSet;
	}
	
	public Teacher getHeadteacher() {
		return headteacher;
	}
	public void setHeadteacher(Teacher headteacher) {
		this.headteacher = headteacher;
	}
	public Teacher getLecturer() {
		return lecturer;
	}
	public void setLecturer(Teacher lecturer) {
		this.lecturer = lecturer;
	}

	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getClassNo() {
		return classNo;
	}
	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}

	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	
	
}
