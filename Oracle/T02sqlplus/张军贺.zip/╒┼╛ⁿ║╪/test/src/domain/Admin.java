package domain;
/*
 * ����Ա��
 */
public class Admin {
	private int id;
	private String adminName;//����Ա�˺�
	private String adminPwd;//��·Ա����
		
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getAdminPwd() {
		return adminPwd;
	}
	public void setAdminPwd(String adminPwd) {
		this.adminPwd = adminPwd;
	}
	
	
}
