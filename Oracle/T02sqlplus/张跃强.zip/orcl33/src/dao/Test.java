package dao;

import org.hibernate.Session;

import domain.Dept;

public class Test {
	public static void main(String[] args) {
		Session session = HibernateSessionFactory.getSession();
		Dept dept = (Dept) session.get(Dept.class,10);
		System.out.println(dept.toString());
		session.beginTransaction();
	}

}
