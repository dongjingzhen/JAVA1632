package dao;

import org.hibernate.Session;

public class test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	Session session = HibernateSessionFactory.getSession();
	Dept dept = (Dept) session.get(Dept.class, 20);
	
	System.out.println(dept.toString());
	
	session.close();
	}

}
