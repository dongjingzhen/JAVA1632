package domain;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Paper {
private int pid;
private String subjectName;
private String kind;
private String title;
private String className;
private String testTime;
private String testHour;
private String totalScore;
private String qnumber;
private String state;
private int avgScore;//ÿ��ƽ����
private Set<Question> questionSet=new HashSet<Question>();

private Set<Student> studentSet = new HashSet<Student>();


public Set<Student> getStudentSet() {
	return studentSet;
}
public void setStudentSet(Set<Student> studentSet) {
	this.studentSet = studentSet;
}
private Set<Classes> classSet=new HashSet<Classes>();


public Set<Classes> getClassSet() {
	return classSet;
}
public void setClassSet(Set<Classes> classSet) {
	this.classSet = classSet;
}
public int getAvgScore() {
	return avgScore;
}
public void setAvgScore(int avgScore) {
	this.avgScore = avgScore;
}


public Set<Question> getQuestionSet() {
	return questionSet;
}
public void setQuestionSet(Set<Question> questionSet) {
	this.questionSet = questionSet;
}
public int getPid() {
	return pid;
}
public void setPid(int pid) {
	this.pid = pid;
}
public String getSubjectName() {
	return subjectName;
}
public void setSubjectName(String subjectName) {
	this.subjectName = subjectName;
}
public String getKind() {
	return kind;
}
public void setKind(String kind) {
	this.kind = kind;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public String getClassName() {
	return className;
}
public void setClassName(String className) {
	this.className = className;
}


public String getTestTime() {
	return testTime;
}
public void setTestTime(String testTime) {
	this.testTime = testTime;
}
public String getTestHour() {
	return testHour;
}
public void setTestHour(String testHour) {
	this.testHour = testHour;
}
public String getTotalScore() {
	return totalScore;
}
public void setTotalScore(String totalScore) {
	this.totalScore = totalScore;
}
public String getQnumber() {
	return qnumber;
}
public void setQnumber(String qnumber) {
	this.qnumber = qnumber;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}



}



