package domain;

import java.util.Date;

public class Teacher {
	private int tid;
	private String tzhanghao;
	private String pwd;
	private String tname;
	private String tsex;
	private String telphont;//�绰;
	private String jop;
	private Classes classes;
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public String getTzhanghao() {
		return tzhanghao;
	}
	public void setTzhanghao(String tzhanghao) {
		this.tzhanghao = tzhanghao;
	}
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public String getTsex() {
		return tsex;
	}
	public void setTsex(String tsex) {
		this.tsex = tsex;
	}
	
	public String getTelphont() {
		return telphont;
	}
	public void setTelphont(String telphont) {
		this.telphont = telphont;
	}
	public String getJop() {
		return jop;
	}
	public void setJop(String jop) {
		this.jop = jop;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public Classes getClasses() {
		return classes;
	}
	public void setClasses(Classes classes) {
		this.classes = classes;
	}
	
	

}
