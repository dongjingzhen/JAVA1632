package action;

import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;



import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;
import domain.Classes;
import domain.Paper;
import domain.Student;


public class PaperAction implements Action {
	
	
	private List<Paper> paperList;//�Ծ��б�
	private List<Classes> classList;//���ÿ��Եİ༶�б�
	private Paper paper; //���Ӷ���

private int pqid;
private String className;
	
	public int getPqid() {
	return pqid;
}


public void setPqid(int pqid) {
	this.pqid = pqid;
}


public String getClassName() {
	return className;
}


public void setClassName(String className) {
	this.className = className;
}


	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	public String list()
	{
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
	
		paperList = session.createCriteria(Paper.class).list();
		
		//�������ݿ��ѯ��¼
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "list";
	}

	public String setPaper()
	{
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		paper = (Paper) session.get(Paper.class, paper.getPid());
		classList = session.createCriteria(Classes.class).list();
		
		
		//�������ݿ��ѯ��¼
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "showSetPaper";
	}
	
	
	public String updatePaper()
	{
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		//����ѡ��İ༶���ƣ���ѯ�༶����ע�����༶��Ҫ�ָ�
		
		
		
		//�õ����ݿ�����Ӷ��󣬸��¾��ӵĿ��԰༶�Լ�����ʱ��,����״̬
		Paper paperDB = (Paper) session.get(Paper.class, pqid);
		
		paperDB.setClassName(className);
		paperDB.setTestTime(paper.getTestTime());
		paperDB.setState(paper.getState());
		
		return SUCCESS;
		
		
	}
	public List<Paper> getPaperList() {
		return paperList;
	}


	public void setPaperList(List<Paper> paperList) {
		this.paperList = paperList;
	}


	public List<Classes> getClassList() {
		return classList;
	}


	public void setClassList(List<Classes> classList) {
		this.classList = classList;
	}



	

	public Paper getPaper() {
		return paper;
	}


	public void setPaper(Paper paper) {
		this.paper = paper;
	}



	

	

	

}
