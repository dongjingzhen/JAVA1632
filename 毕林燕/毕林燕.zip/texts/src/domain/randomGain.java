package domain;

public class randomGain {

	private String fangxiang;
	private String jieduan;
	private int rdj;
	private int rdz;
	private int rdk;
	private int rduoj;
	private int rduoz;
	private int rdouk;
	
	
	public String getFangxiang() {
		return fangxiang;
	}
	public void setFangxiang(String fangxiang) {
		this.fangxiang = fangxiang;
	}
	public String getJieduan() {
		return jieduan;
	}
	public void setJieduan(String jieduan) {
		this.jieduan = jieduan;
	}
	public int getRdj() {
		return rdj;
	}
	public void setRdj(int rdj) {
		this.rdj = rdj;
	}
	public int getRdz() {
		return rdz;
	}
	public void setRdz(int rdz) {
		this.rdz = rdz;
	}
	public int getRdk() {
		return rdk;
	}
	public void setRdk(int rdk) {
		this.rdk = rdk;
	}
	public int getRduoj() {
		return rduoj;
	}
	public void setRduoj(int rduoj) {
		this.rduoj = rduoj;
	}
	public int getRduoz() {
		return rduoz;
	}
	public void setRduoz(int rduoz) {
		this.rduoz = rduoz;
	}
	public int getRdouk() {
		return rdouk;
	}
	public void setRdouk(int rdouk) {
		this.rdouk = rdouk;
	}
	
	

}
