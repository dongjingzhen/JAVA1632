package action;




import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;






import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;
import domain.Admain;
import domain.Classes;
import domain.Paper;
import domain.Question;
import domain.Student;
import domain.randomGain;

import domain.Teacher;
import domain.User;



public class QuestionAction implements Action {
	private String class1;
	private String class2;
	
	
	
	private randomGain randomgain;//������������ȡֵ
	private Paper paper;//����������
	private List<Paper> paperList = new ArrayList<Paper>();
	
	private List<Classes> classList = new ArrayList<Classes>();
	
	
	public String getClass1() {
		return class1;
	}

	public void setClass1(String class1) {
		this.class1 = class1;
	}

	public String getClass2() {
		return class2;
	}

	public void setClass2(String class2) {
		this.class2 = class2;
	}

	


	




	public List<Classes> getClassList() {
		return classList;
	}

	public void setClassList(List<Classes> classList) {
		this.classList = classList;
	}









	private int pid;
	
	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public List<Paper> getPaperList() {
		return paperList;
	}

	public void setPaperList(List<Paper> paperList) {
		this.paperList = paperList;
	}

	public Paper getPaper() {
		return paper;
	}

	public void setPaper(Paper paper) {
		this.paper = paper;
	}

	public randomGain getRandomgain() {
		return randomgain;
	}

	public void setRandomgain(randomGain randomgain) {
		this.randomgain = randomgain;
	}


	private List addList;
	
	public List getAddList() {
		return addList;
	}

	public void setAddList(List addList) {
		this.addList = addList;
	}


	private List<Object []> questionList = new ArrayList<Object[]>();
	private List<Question> queList = new ArrayList<Question>();
	
	private String kind;//������ѡ
	private String type;
	private String content;//��Ŀ
	private String objectA;
	private String objectB;
	private String objectC;
	private String objectD;
	private String radioSelectAnwsers;//��
	private String difficulty;//�Ѷ�
	private String subjectId;//��Ŀ
	private String chapter;//���
	private String subName;
	
	

	public String getRadioSelectAnwsers() {
		return radioSelectAnwsers;
	}

	public void setRadioSelectAnwsers(String radioSelectAnwsers) {
		this.radioSelectAnwsers = radioSelectAnwsers;
	}

	public String getKind() {
		return kind;
	}

	public void setKind(String kind) {
		this.kind = kind;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getObjectA() {
		return objectA;
	}

	public void setObjectA(String objectA) {
		this.objectA = objectA;
	}

	public String getObjectB() {
		return objectB;
	}

	public void setObjectB(String objectB) {
		this.objectB = objectB;
	}

	public String getObjectC() {
		return objectC;
	}

	public void setObjectC(String objectC) {
		this.objectC = objectC;
	}

	public String getObjectD() {
		return objectD;
	}

	public void setObjectD(String objectD) {
		this.objectD = objectD;
	}

	

	public String getDifficulty() {
		return difficulty;
	}

	public void setDifficulty(String difficulty) {
		this.difficulty = difficulty;
	}

	public String getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}

	public String getChapter() {
		return chapter;
	}

	public void setChapter(String chapter) {
		this.chapter = chapter;
	}

	public String getSubName() {
		return subName;
	}

	public void setSubName(String subName) {
		this.subName = subName;
	}

	public List<Question> getQueList() {
		return queList;
	}

	public void setQueList(List<Question> queList) {
		this.queList = queList;
	}





	public List<Object[]> getQuestionList() {
		return questionList;
	}

	public void setQuestionList(List<Object[]> questionList) {
		this.questionList = questionList;
	}

	

	@Override
	public String execute() throws Exception {
		return SUCCESS;
	}
	
		

	//������ ��ʾ��Ŀ ���ٵ����Զ��ٵ�����
	public String quesList(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Criteria criteria = session.createCriteria(Question.class);
							
							
		ProjectionList projectionList = Projections.projectionList()
							.add(Projections.groupProperty("subjectId"))
							.add(Projections.groupProperty("type"))
							.add(Projections.groupProperty("stage"))
							.add(Projections.count("qid"));
		criteria.setProjection(projectionList);
		questionList=criteria.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "list";
		
	}
		
		
	//��ʾ����ķ���
	public String show(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		Criteria criteria = session.createCriteria(Question.class)
		                   
						   .add(Restrictions.eq("subjectId", subName));
		queList=criteria.list();
		//ServletActionContext.getRequest().getSession().setAttribute("����", queList);
		ServletActionContext.getRequest().getSession().setAttribute("type", type);
		ServletActionContext.getRequest().getSession().setAttribute("subjectId", subName);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "show";
	}
		
	
	//����
	public String getQues(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		//����session��Ŀ�Ŀ������
		
		String subjectId=(String) ServletActionContext.getRequest().getSession().getAttribute("subjectId");
		addList=session.createCriteria(Question.class).list();
		Question q = new Question();
		q.setKind(kind);
		q.setContent(content);
		q.setObjectA(objectA);
		q.setObjectB(objectB);
		q.setObjectC(objectC);
		q.setObjectD(objectD);
		q.setAnswer(radioSelectAnwsers);
		q.setType(type);
		q.setDifficulty(difficulty);
		q.setSubjectId(subjectId);
	    q.setChapter("chapter");
		session.saveOrUpdate(q);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "getQues";
	}

	//��ʾ�Ծ�
	public String showPaper(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Criteria criteria = (Criteria)session.createCriteria(Paper.class);
		paperList=criteria.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "showpaper";	
	}
	
	//�������ķ���
	public String randomP(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		String sql = "select qid from"+ 
					"(select top "+randomgain.getRdj()+" qid from question where difficulty= '��' and kind='��ѡ'  order by newId()"+					
					" union "+ 
					"select top "+randomgain.getRdz()+" qid from question where difficulty= '�е�'  and kind='��ѡ' order by newId()"+ 					
					" union "+
					"select top "+randomgain.getRdk()+" qid from question where difficulty= '����' and kind='��ѡ' order by newId()"+
					" union "+
					"select top "+randomgain.getRduoj()+" qid from question where difficulty= '��' and kind='��ѡ' order by newId()"+					
					" union "+ 
					"select top "+randomgain.getRduoz()+" qid from question where difficulty= '�е�' and kind='��ѡ' order by newId()"+ 					
					" union "+
					"select top "+randomgain.getRdouk()+" qid from question where difficulty= '����' and kind='��ѡ' order by newId()"+	
					") as k";
		List<Integer> qidList = session.createSQLQuery(sql).list();
		paper.setSubjectName(randomgain.getFangxiang()+randomgain.getJieduan()+paper.getSubjectName());
		
		for (Integer integer : qidList) {
			Question q = (Question) session.get(Question.class, integer);
			q.getPaperSet().add(paper);
			session.saveOrUpdate(paper);
		}
		
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "randompaper";	
	}
	
	//�鿴�Ծ��ķ���
	public String getOnepaperQuestion(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		paper = (Paper) session.get(Paper.class, pid);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "getOnepaperQ";
	}

	
	
	//��ʼ����
	public String beginPaper(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Criteria criteria = (Criteria)session.createCriteria(Classes.class)
		.add(Restrictions.eq("className", class1));
		classList=criteria.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "beginpaper";	
	}
	
	
}
