package domain;
//����Ա��
public class Admin {
	private int id;//id
	private String userName;//��¼ʱ�õ� �û���
	private String pwd;//��¼ʱ�õ� ����
	private String name;//����Ա������
	
	
	public Admin() {}
	public Admin(String userName, String pwd, String name) {
		super();
		this.userName = userName;
		this.pwd = pwd;
		this.name = name;
	}



	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
	
}
