package domain;
//��ʦ��
public class Teacher {
	private int id;//id
	private String userName;//��¼ʱ�õ� �û���
	private String pwd;//��¼ʱ�õ� ����
	private String name;//��ʦ����
	private String sex;//�Ա�
	private String education;//ѧ��
	private String telPhone;//��ϵ�绰
	private String post;//��λ
	private String remark;//��ע
	
	
	public Teacher() {}
	public Teacher(String userName, String pwd, String name, String sex,
			String education, String telPhone, String post, String remark) {
		super();
		this.userName = userName;
		this.pwd = pwd;
		this.name = name;
		this.sex = sex;
		this.education = education;
		this.telPhone = telPhone;
		this.post = post;
		this.remark = remark;
	}




	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public String getTelPhone() {
		return telPhone;
	}
	public void setTelPhone(String telPhone) {
		this.telPhone = telPhone;
	}
	public String getPost() {
		return post;
	}
	public void setPost(String post) {
		this.post = post;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	
	
	

}
