package domain;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Classes {
	private int cid;//id
	private String code;//�༉����
	private String cname;//�༶����
	private String direction;//����
	private Teacher headlmaster ;//������
	private Teacher lecturer ;//��ʦ
	private Date openDate ;//��������
	private String state ;//״̬
	private String remark;//��ע
	private Set<Students> studentSet=new HashSet<Students>();//���ѧ���ļ���
	private Set<Paper> paperSet=new HashSet<Paper>();//�༶��Ҫ�����Ծ�
	
	
	public Set<Paper> getPaperSet() {
		return paperSet;
	}
	public void setPaperSet(Set<Paper> paperSet) {
		this.paperSet = paperSet;
	}
	public Classes() {}
	public Classes( String code, String cname, String direction,
			Date openDate, String state, String remark) {
		super();
		this.code = code;
		this.cname = cname;
		this.direction = direction;
		this.openDate = openDate;
		this.state = state;
		this.remark = remark;
	}
	public Set<Students> getStudentSet() {
		return studentSet;
	}
	public void setStudentSet(Set<Students> studentSet) {
		this.studentSet = studentSet;
	}
	
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	
	public Teacher getHeadlmaster() {
		return headlmaster;
	}
	public void setHeadlmaster(Teacher headlmaster) {
		this.headlmaster = headlmaster;
	}
	public Teacher getLecturer() {
		return lecturer;
	}
	public void setLecturer(Teacher lecturer) {
		this.lecturer = lecturer;
	}
	public Date getOpenDate() {
		return openDate;
	}
	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	
	
	

}
