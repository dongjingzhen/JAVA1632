package domain;

import java.util.Date;

public class Students {
	private int id;//id
	private String userName;//��¼ʱ�õ� �û���
	private String pwd;//��¼ʱ�õ� ����
	private String name;//ѧ������
	private String sex;//�Ա�
	private Date schoolDate;//��ѧ����
	private Classes classes;//�༶
	private Date birthday;//����
	private String address;//��ͥסַ
	//private String photo;//��Ƭ·��
	private String telPhone;//��ϵ�绰
	
	
	
	public Students() {}

	public Students(String userName, String pwd, String name, String sex,
			Date schoolDate, Date birthday, String address,
			String telPhone) {
		super();
		this.userName = userName;
		this.pwd = pwd;
		this.name = name;
		this.sex = sex;
		this.schoolDate = schoolDate;
		this.birthday = birthday;
		this.address = address;
		this.telPhone = telPhone;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	
	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Date getSchoolDate() {
		return schoolDate;
	}

	public void setSchoolDate(Date schoolDate) {
		this.schoolDate = schoolDate;
	}

	public Classes getClasses() {
		return classes;
	}

	public void setClasses(Classes classes) {
		this.classes = classes;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTelPhone() {
		return telPhone;
	}

	public void setTelPhone(String telPhone) {
		this.telPhone = telPhone;
	}
	
	

}
