package domain;

import java.util.Date;

//���Գɼ�
public class Score {
	private int sid;//id
	private Paper paper;//���Ե��Ծ�
	private Classes classes;//���Եİ༶
	private Students student;//���Ե�ѧ��
	private String title;//�Ծ�����
	private Date startTime;//����ʱ��
	private int score;//��ο��Ե��ܳɼ�
	
	
	
	
	public Score() {
		super();
	}
	public Score(Paper paper, Classes classes, Students student, String title,
			Date startTime, int score) {
		super();
		this.paper = paper;
		this.classes = classes;
		this.student = student;
		this.title = title;
		this.startTime = startTime;
		this.score = score;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public Paper getPaper() {
		return paper;
	}
	public void setPaper(Paper paper) {
		this.paper = paper;
	}
	public Classes getClasses() {
		return classes;
	}
	public void setClasses(Classes classes) {
		this.classes = classes;
	}
	public Students getStudent() {
		return student;
	}
	public void setStudent(Students student) {
		this.student = student;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	
	
	
	
}
