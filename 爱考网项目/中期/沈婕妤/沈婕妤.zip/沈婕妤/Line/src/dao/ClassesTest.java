package dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import domain.Admin;
import domain.Classes;
import domain.Paper;
import domain.Question;
import domain.Score;
import domain.Students;
import domain.Teacher;
import domain.Users;

public class ClassesTest {
	
	public static void main(String[] args) {
		
		try {
			 save();
			save1();
			save3();
			test2();
			test4();
			test5();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//test6();
		
	}
	
	public static void test6() {
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		Students s1=(Students)session.get(Students.class, 1);
		Paper p1=(Paper)session.get(Paper.class, 9);
		
		Score score=(Score)session.createCriteria(Score.class)
				.add(Restrictions.eq("student",s1))
				.add(Restrictions.eq("paper",p1))
				.uniqueResult();
		
		System.out.println(score.getTitle());
		score.setScore(10);
		
		session.update(score);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
	
	}
	public static void test5() {
		String aa="A";
		String [] bb=aa.split(",");
		
		System.out.println(bb.length);
		
		for (String string : bb) {
			System.out.println(":"+string);
		}
		System.out.println(bb.length);
		
	}
	public static void test4() {
		
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		Paper paper=(Paper)session.get(Paper.class,7);
		
		Set<Question> qSet=paper.getQuestionSet();
		
		for (Question que : qSet) {
			System.out.println(que.getQid());
		}
		List<Question> qList=new ArrayList<Question>(qSet);
		System.out.println("list1:"+qList.get(1).getQid());
		for (Question que : qList) {
			System.out.println(que.getQid());
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
	}
	public static void test3() {
		
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		//�õ������session�е�ѧ������
		Students student1=(Students)session.get(Students.class, 1);
		
		//ͨ��ѧ���õ��������İ༶�����õ��༶�µ��Ծ�����
		Set<Paper> paperSet=student1.getClasses().getPaperSet();

		for (Paper pap : paperSet) {
			Set<Classes> classSet= pap.getClassSet();
			String cname="";
			for (Classes classes : classSet) {
				cname+=classes.getCname()+",";
				System.out.println(cname);
			}
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	
	public static void test2() {

		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		Students s1=(Students)session.get(Students.class, 1);
		
		Set<Paper> paperSet=s1.getClasses().getPaperSet();
		
		for (Paper paper : paperSet) {
			System.out.println(paper.getTitle());
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	
	public static void test1() {

		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		Paper paper=(Paper)session.get(Paper.class, 1);
		Set<Question> qList=paper.getQuestionSet();
		
		for (Question q : qList) {
			System.out.println(q.getSubject());
			
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	//�����û�����
	public static void save3() throws ParseException{
		
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		//��ȡһ���༶
		Classes c1=(Classes)session.get(Classes.class, 1);
		
		for (int i = 0; i < 20; i++) {
			Students s1=new Students("aa"+i, "111", "�"+i, "��",	new Date(), new Date(), "����", "12456789");
				
			s1.setClasses(c1);
			c1.getStudentSet().add(s1);
			session.save(s1);
		}
		
		
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
	}
	
	
	//�����������
	public static  void save1() throws ParseException{
		
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		for (int i = 0; i < 10; i++) {
			Question q1=new Question("java","G1","��","��ѡ",i+"a+a=��","aa","bb","cc","dd","A","����");
			session.save(q1);
		}
		for (int i = 0; i < 10; i++) {
			Question q1=new Question("java","G1","��","��ѡ",i+"b+b=��","aa","bb","cc","dd","A","����");
			session.save(q1);
		}
		for (int i = 0; i < 10; i++) {
			Question q1=new Question("java","G2","һ��","��ѡ",i+"c+c=��","aa","bb","cc","dd","A","����");
			session.save(q1);
		}
		for (int i = 0; i < 10; i++) {
			Question q1=new Question("java","G2","һ��","��ѡ",i+"d+d=��","aa","bb","cc","dd","A","����");
			session.save(q1);
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
	}
	
	//�����û�����
	public static void save() throws ParseException{
		
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		Admin a1=new Admin("vvv", "111","vvv");
		Teacher t1=new Teacher("ttt", "111", "����", "Ů", "��ѧ", "123456789", "����Ա", "dGSgSGDgb");			
		Teacher t2=new Teacher("ttt1", "111", "��ŷ", "��", "��ѧ", "123456789", "��Ա", "gagaegddvzcv");			
		Classes c1=new Classes("java1632", "java1632��", "java", new Date(), "����", "111");
		c1.setLecturer(t1);
		c1.setHeadlmaster(t2);
		
		
		Students s1=new Students("aaa", "111", "����", "��",new Date(), new Date(), "������", "110");	
		s1.setClasses(c1);
		Students s2=new Students("bbb", "111", "����", "Ů",new Date(), new Date(), "������", "110");			
		s2.setClasses(c1);
		Students s3=new Students("ccc", "111", "����", "��",new Date(), new Date(), "������", "110");				
		s3.setClasses(c1);
		
		

		c1.getStudentSet().add(s1);
		c1.getStudentSet().add(s2);
		c1.getStudentSet().add(s3);
		session.save(a1);
		session.save(t1);
		session.save(t2);
		session.save(c1);
		session.save(s1);
		session.save(s2);
		session.save(s3);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
	}
}
