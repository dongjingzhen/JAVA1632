package filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EncodeFilter implements Filter {
	private String encode=null;
	//��ʼ��������
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub
		encode=filterConfig.getInitParameter("encode");
	}
	
	//����������Ĺ���
	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse,
			FilterChain filterChain) throws IOException, ServletException {
		
		HttpServletRequest request=(HttpServletRequest)servletRequest;
		HttpServletResponse response=(HttpServletResponse)servletResponse;
		request.setCharacterEncoding(encode);
		response.setCharacterEncoding(encode);
		filterChain.doFilter(servletRequest, servletResponse);
		
	}
	
	//����������
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
	}
	

}
