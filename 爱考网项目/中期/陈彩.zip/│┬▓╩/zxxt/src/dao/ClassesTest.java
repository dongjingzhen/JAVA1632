package dao;

import java.text.ParseException;
import java.util.Date;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.Transaction;

import domain.Admin;
import domain.Classes;
import domain.Paper;
import domain.Question;
import domain.Students;
import domain.Subject;
import domain.Teacher;
public class ClassesTest {
	
	public static void main(String[] args) {
		
		try {
			save4();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//get();
		
	}
	public static void test2() {

		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		Students s1=(Students)session.get(Students.class, 1);
		
		Set<Paper> paperSet=s1.getClasses().getPaperSet();
		
		for (Paper paper : paperSet) {
			System.out.println(paper.getTitle());
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	
	public static void test1() {

		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		Paper paper=(Paper)session.get(Paper.class, 1);
		Set<Question> qList=paper.getQuestionSet();
		
		for (Question q : qList) {
			System.out.println(q.getSubject());
			
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	
	
	//�����û�����
	public static void save4() throws ParseException{
		
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		//��ȡһ���༶
		Subject subject=new Subject();
		subject.setMajor("JAVA");
		subject.setStage("S1");
		subject.setSubjectId("1");
		session.save(subject);
		//��ȡһ���༶
		Subject subject1=new Subject();
		subject.setMajor("Hibernate");
		subject.setStage("S2");
		subject.setSubjectId("2");
		session.save(subject1);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	
	//�����û�����
	public static void save3() throws ParseException{
		
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		//��ȡһ���༶
		Classes c1=(Classes)session.get(Classes.class, 1);
		
		for (int i = 0; i < 20; i++) {
			Students s1=new Students("aa"+i, "123", "����"+i, "��",
					new Date(), new Date(), "������", "110");
			s1.setClasses(c1);
			c1.getStudentSet().add(s1);
			session.save(s1);
		}
	}
	
	//�����������
	public static void save1() throws ParseException{
		
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		

		for (int i = 0; i < 10; i++) {
			Question q1=new Question("java","G1","��","��ѡ",i+"1��3���ڼ���","2","3","4","5","A","����");
			session.save(q1);
		}
		for (int i = 0; i < 10; i++) {
			Question q1=new Question("java","G1","��","��ѡ",i+"1��3���ڼ���","2","3","4","5","A","����");
			session.save(q1);
		}
		for (int i = 0; i < 10; i++) {
			Question q1=new Question("java","G2","һ��","��ѡ",i+"1��3���ڼ���","2","3","4","5","A","����");
			session.save(q1);
		}
		for (int i = 0; i < 10; i++) {
			Question q1=new Question("java","G2","��","��ѡ",i+"1��3���ڼ���","2","3","4","5","A","����");
			session.save(q1);
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
	}
	
	public static void save() throws ParseException{
		
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		Admin a1=new Admin("admin", "123");
		
		Teacher t1=new Teacher("tom", "123", "��12", 
				"��", "��ר", "110", "b������", "aaaaaaaaa");
		Teacher t2=new Teacher("tom1", "123", "��12", 
				"��", "��ר", "110", "b������", "aaaaaaaaaa");
		
		//����һ���༶
		Classes c1=new Classes();
		c1.setLecturer(t1);
		c1.setHeadlmaster(t2);
		
		Students s1=new domain.Students("stu", "123", "����", "��",
				new Date(), new Date(), "������", "110");
		s1.setClasses(c1);
		c1.getStudentSet().add(s1);
		
		session.save(a1);
		session.save(t1);
		session.save(t2);
		session.save(c1);
		session.save(s1);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
	}

}
