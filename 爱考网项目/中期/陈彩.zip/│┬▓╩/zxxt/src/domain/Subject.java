package domain;

import java.util.HashSet;
import java.util.Set;

/**��Ŀ��*/
public class Subject {
	
	private int id;	
	private String major;//��������
	private String stage;//�׶�
	private String subjectId;//��Ŀ���
	private Set<Paper> paperSet=new HashSet<Paper>();//���Ծ��е����⼯��
	
	@Override
	public String toString() {
		return "Subject [id=" + id + ", major=" + major + ", stage=" + stage
				+ ", subjectId=" + subjectId + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public String getStage() {
		return stage;
	}
	public void setStage(String stage) {
		this.stage = stage;
	}
	public String getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}
	public Set<Paper> getPaperSet() {
		return paperSet;
	}
	public void setPaperSet(Set<Paper> paperSet) {
		this.paperSet = paperSet;
	}

}
