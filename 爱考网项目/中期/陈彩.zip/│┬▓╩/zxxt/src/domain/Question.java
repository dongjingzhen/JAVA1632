package domain;

import java.util.HashSet;
import java.util.Set;

//����
public class Question {
	private int qid;//id
	private String major;//רҵ
	private String stage;//�׶�
	private String difficult;//���׳̶�    ��/һ��/����
	private String mr;//��ѡ/��ѡ
	private String subject;//��Ŀ
	private String optionA;//ѡ��A�Ĵ�
	private String optionB;//ѡ��B�Ĵ�
	private String optionC;//ѡ��C�Ĵ�
	private String optionD;//ѡ��D�Ĵ�
	private String answer;//��ȷ��
	private String mw;// ����/���� 
	private Set<Paper>  paperSet=new HashSet<Paper>();//�Ծ��ļ��ϣ��������ö�Զ��ϵ
	
	
	
	public Question() {
		super();
	}
	public Question(String major, String stage, String difficult, String mr,
			String subject, String optionA, String optionB, String optionC,
			String optionD, String answer, String mw) {
		super();
		this.major = major;
		this.stage = stage;
		this.difficult = difficult;
		this.mr = mr;
		this.subject = subject;
		this.optionA = optionA;
		this.optionB = optionB;
		this.optionC = optionC;
		this.optionD = optionD;
		this.answer = answer;
		this.mw = mw;
	}
	public int getQid() {
		return qid;
	}
	public void setQid(int qid) {
		this.qid = qid;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public String getStage() {
		return stage;
	}
	public void setStage(String stage) {
		this.stage = stage;
	}
	public String getDifficult() {
		return difficult;
	}
	public void setDifficult(String difficult) {
		this.difficult = difficult;
	}
	public String getMr() {
		return mr;
	}
	public void setMr(String mr) {
		this.mr = mr;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getOptionA() {
		return optionA;
	}
	public void setOptionA(String optionA) {
		this.optionA = optionA;
	}
	public String getOptionB() {
		return optionB;
	}
	public void setOptionB(String optionB) {
		this.optionB = optionB;
	}
	public String getOptionC() {
		return optionC;
	}
	public void setOptionC(String optionC) {
		this.optionC = optionC;
	}
	public String getOptionD() {
		return optionD;
	}
	public void setOptionD(String optionD) {
		this.optionD = optionD;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getMw() {
		return mw;
	}
	public void setMw(String mw) {
		this.mw = mw;
	}
	public Set<Paper> getPaperSet() {
		return paperSet;
	}
	public void setPaperSet(Set<Paper> paperSet) {
		this.paperSet = paperSet;
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
