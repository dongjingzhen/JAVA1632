package domain;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Classes {
	private int cId;//id
	private String code;//�༉����
	private String cName;//�༶����
	private String direction;//����
	private Teacher headlmaster ;//������
	private Teacher lecturer ;//��ʦ
	private Date openDate ;//��������
	private String state ;//״̬
	private String remark;//��ע
	private Set<Students> studentSet=new HashSet<Students>();//���ѧ���ļ���
	private Set<Paper> paperSet=new HashSet<Paper>();//�༶��Ҫ�����Ծ�
	
	
	@Override
	public String toString() {
		return "Classes [cId=" + cId + ", cName=" + cName + ", code=" + code
				+ ", direction=" + direction + ", headlmaster=" + headlmaster
				+ ", lecturer=" + lecturer + ", openDate=" + openDate
				+ ", paperSet=" + paperSet + ", remark=" + remark + ", state="
				+ state + ", studentSet=" + studentSet + "]";
	}
	public Set<Students> getStudentSet() {
		return studentSet;
	}
	public void setStudentSet(Set<Students> studentSet) {
		this.studentSet = studentSet;
	}
	public int getcId() {
		return cId;
	}
	public void setcId(int cId) {
		this.cId = cId;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	
	public Teacher getHeadlmaster() {
		return headlmaster;
	}
	public void setHeadlmaster(Teacher headlmaster) {
		this.headlmaster = headlmaster;
	}
	public Teacher getLecturer() {
		return lecturer;
	}
	public void setLecturer(Teacher lecturer) {
		this.lecturer = lecturer;
	}
	public Date getOpenDate() {
		return openDate;
	}
	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Set<Paper> getPaperSet() {
		return paperSet;
	}
	public void setPaperSet(Set<Paper> paperSet) {
		this.paperSet = paperSet;
	}
	
	
	
	

}
