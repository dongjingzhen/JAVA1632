package domain;
//��ʦ��
public class Teacher {
	private int tId;//id
	private String userName;//��¼ʱ�õ� �û���
	private String pwd;//��¼ʱ�õ� ����
	private String tName;//��ʦ����
	private String sex;//�Ա�
	private String education;//ѧ��
	private String telPhone;//��ϵ�绰
	private String post;//��λ
	private String remark;//��ע
	
	
	public Teacher() {}
	
	public Teacher( String userName, String pwd, String tName,
			String sex, String education, String telPhone, String post,
			String remark) {
		super();
		this.userName = userName;
		this.pwd = pwd;
		this.tName = tName;
		this.sex = sex;
		this.education = education;
		this.telPhone = telPhone;
		this.post = post;
		this.remark = remark;
	}

	public int gettId() {
		return tId;
	}
	public void settId(int tId) {
		this.tId = tId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String gettName() {
		return tName;
	}
	public void settName(String tName) {
		this.tName = tName;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public String getTelPhone() {
		return telPhone;
	}
	public void setTelPhone(String telPhone) {
		this.telPhone = telPhone;
	}
	public String getPost() {
		return post;
	}
	public void setPost(String post) {
		this.post = post;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	
	
	

}
