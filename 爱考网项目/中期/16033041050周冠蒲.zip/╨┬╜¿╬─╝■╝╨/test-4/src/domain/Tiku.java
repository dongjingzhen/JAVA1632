package domain;

import java.util.HashSet;
import java.util.Set;

public class Tiku {
	private int tid;
	private String tname;
	
	private Set<Jishiti> jishiSet=new HashSet<Jishiti>();
	private Set<Shiti> bishiSet=new HashSet<Shiti>();
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public Set<Jishiti> getJishiSet() {
		return jishiSet;
	}
	public void setJishiSet(Set<Jishiti> jishiSet) {
		this.jishiSet = jishiSet;
	}
	public Set<Shiti> getBishiSet() {
		return bishiSet;
	}
	public void setBishiSet(Set<Shiti> bishiSet) {
		this.bishiSet = bishiSet;
	}
	
}
