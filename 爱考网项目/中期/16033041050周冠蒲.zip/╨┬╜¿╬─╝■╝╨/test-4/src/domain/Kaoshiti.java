package domain;

public class Kaoshiti {
	private int shuliang;
	private String sname;
	private int shitiId;
	private String yesDaan;
	public int getShuliang() {
		return shuliang;
	}
	public void setShuliang(int shuliang) {
		this.shuliang = shuliang;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public int getShitiId() {
		return shitiId;
	}
	public void setShitiId(int shitiId) {
		this.shitiId = shitiId;
	}
	public String getYesDaan() {
		return yesDaan;
	}
	public void setYesDaan(String yesDaan) {
		this.yesDaan = yesDaan;
	}
	

}
