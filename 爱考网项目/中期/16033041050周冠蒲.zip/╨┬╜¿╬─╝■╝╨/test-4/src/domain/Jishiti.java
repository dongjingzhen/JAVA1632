package domain;

public class Jishiti {
	private int jsid;
	private String jsname;
	private String jstype;
	private String jsnandu;
	private String jsoptionA;
	private String jsoptionB;
	private String jsoptionC;
	private String jsoptionD;
	private Tiku tiku;
	private String tt;
	private String jishicounts;
	

	public String getJishicounts() {
		return jishicounts;
	}
	public void setJishicounts(String jishicounts) {
		this.jishicounts = jishicounts;
	}
	public String getTt() {
		return tt;
	}
	public void setTt(String tt) {
		this.tt = tt;
	}
	
	public Tiku getTiku() {
		return tiku;
	}
	public void setTiku(Tiku tiku) {
		this.tiku = tiku;
	}
	public int getJsid() {
		return jsid;
	}
	public void setJsid(int jsid) {
		this.jsid = jsid;
	}
	public String getJsname() {
		return jsname;
	}
	public void setJsname(String jsname) {
		this.jsname = jsname;
	}
	public String getJstype() {
		return jstype;
	}
	public void setJstype(String jstype) {
		this.jstype = jstype;
	}
	public String getJsoptionA() {
		return jsoptionA;
	}
	public void setJsoptionA(String jsoptionA) {
		this.jsoptionA = jsoptionA;
	}
	public String getJsoptionB() {
		return jsoptionB;
	}
	public void setJsoptionB(String jsoptionB) {
		this.jsoptionB = jsoptionB;
	}
	public String getJsoptionC() {
		return jsoptionC;
	}
	public void setJsoptionC(String jsoptionC) {
		this.jsoptionC = jsoptionC;
	}
	public String getJsoptionD() {
		return jsoptionD;
	}
	public void setJsoptionD(String jsoptionD) {
		this.jsoptionD = jsoptionD;
	}
	public String getJsnandu() {
		return jsnandu;
	}
	public void setJsnandu(String jsnandu) {
		this.jsnandu = jsnandu;
	}
	
}
