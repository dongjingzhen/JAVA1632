   package domain;

import java.util.HashSet;
import java.util.Set;

public class Paper {
	private int pid;
	private String subjectName;//���ӵ����
	private String kind;//���ӵĿ�Ŀ
	private String title;//����
	private String testTime;//����ʱ��
	private String testHour;
	private String state;
	private Set<Question> qSet=new HashSet<Question>();
	
	public Set<Question> getqSet() {
		return qSet;
	}
	public void setqSet(Set<Question> qSet) {
		this.qSet = qSet;
	}
	public Paper(){
		
	}
	public Paper(String subjectName,String kind,String title,String testTime,String testHour,String state){
		super();
		this.subjectName=subjectName;
		this.kind=kind;
		this.title=title;
		this.testTime=testTime;
		this.testHour=testHour;
		this.state=state;		
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTestTime() {
		return testTime;
	}
	public void setTestTime(String testTime) {
		this.testTime = testTime;
	}
	public String getTestHour() {
		return testHour;
	}
	public void setTestHour(String testHour) {
		this.testHour = testHour;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	

}
