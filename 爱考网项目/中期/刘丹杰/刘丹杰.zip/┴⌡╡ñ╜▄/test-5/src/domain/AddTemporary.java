package domain;
//��������������������Ծ�ʱ�Ĳ���
public class AddTemporary {
	private String major;//רҵ
	private String chapter;//�׶�
	private int djiandan;//��ѡ�򵥵ĸ���
	private int dyiban;//��ѡһ��
	private int dkunnan;//��ѡ����
	private int morejiandan;//��ѡ�򵥵ĸ���
	private int moreyiban;//��ѡһ��
	private int morekunnan;//��ѡ����
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public String getChapter() {
		return chapter;
	}
	public void setChapter(String chapter) {
		this.chapter = chapter;
	}
	public int getDjiandan() {
		return djiandan;
	}
	public void setDjiandan(int djiandan) {
		this.djiandan = djiandan;
	}
	public int getDyiban() {
		return dyiban;
	}
	public void setDyiban(int dyiban) {
		this.dyiban = dyiban;
	}
	public int getDkunnan() {
		return dkunnan;
	}
	public void setDkunnan(int dkunnan) {
		this.dkunnan = dkunnan;
	}
	public int getMorejiandan() {
		return morejiandan;
	}
	public void setMorejiandan(int morejiandan) {
		this.morejiandan = morejiandan;
	}
	public int getMoreyiban() {
		return moreyiban;
	}
	public void setMoreyiban(int moreyiban) {
		this.moreyiban = moreyiban;
	}
	public int getMorekunnan() {
		return morekunnan;
	}
	public void setMorekunnan(int morekunnan) {
		this.morekunnan = morekunnan;
	}
	

}
