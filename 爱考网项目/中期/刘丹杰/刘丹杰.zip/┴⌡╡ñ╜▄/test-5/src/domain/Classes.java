package domain;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Classes {
	private int cid;
	private String cname;
	private String cnum;
	private String  direction;//����
	private Date cdata;
	private String cstatus;//״̬
	private Set<Teacher> teacherSet=new HashSet<Teacher>();
	private Set<Students> studentSet=new HashSet<Students>();
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCnum() {
		return cnum;
	}
	public void setCnum(String cnum) {
		this.cnum = cnum;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public Date getCdata() {
		return cdata;
	}
	public void setCdata(Date cdata) {
		this.cdata = cdata;
	}
	public String getCstatus() {
		return cstatus;
	}
	public void setCstatus(String cstatus) {
		this.cstatus = cstatus;
	}
	public Set<Teacher> getTeacherSet() {
		return teacherSet;
	}
	public void setTeacherSet(Set<Teacher> teacherSet) {
		this.teacherSet = teacherSet;
	}
	public Set<Students> getStudentSet() {
		return studentSet;
	}
	public void setStudentSet(Set<Students> studentSet) {
		this.studentSet = studentSet;
	}
	

}
