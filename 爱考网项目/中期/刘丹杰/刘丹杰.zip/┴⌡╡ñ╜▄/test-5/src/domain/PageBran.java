package domain;

import com.sun.xml.internal.bind.v2.schemagen.xmlschema.List;

public class PageBran {
	private int pagesize=2;//ÿҳ����
	private int pagetotal;//��ҳ��
	private int p;//��ǰҳ
	private int count;//������
	private List data;
	public int getPagesize() {
		return pagesize;
	}
	public void setPagesize(int pagesize) {
		this.pagesize = pagesize;
	}
	public int getPagetotal() {
		return pagetotal;
	}
	public void setPagetotal(int count,int pagesize) {
		if (count%pagesize==0) {
			this.pagetotal = count/pagesize;
		}else {
			this.pagetotal =count/pagesize+1;
		}
		
	}
	public int getP() {
		return p;
	}
	public void setP(int p) {
		this.p = p;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public List getData() {
		return data;
	}
	public void setData(List lis) {
		data = lis;
	}
	
	

}
