package action;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.jms.TemporaryTopic;
import javax.servlet.RequestDispatcher;

import org.apache.struts2.ServletActionContext;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;


import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;
import domain.AddTemporary;
import domain.Admin;
import domain.PageBran;
import domain.Paper;
import domain.Question;
import domain.Students;
import domain.Teacher;



public class UserAction implements Action {
	private String name;
	private int pagetotal;//��ҳ��
	private List lis;
	private int id;
	private int bid;
	private List list;
	private Admin admin;
	private PageBran pageBran;
	private Question question;
	private Paper paper;
	private int pid;
	private AddTemporary addTemporary;
	//����һ������ļ���
	private List<Question> quesList=new ArrayList<Question>();
	//����һ������ļ���
	private List<Object[]> objList=new ArrayList<Object[]>();
	//����һ����ʾ�Ծ��ļ���
	private List<Paper> paperList=new ArrayList<Paper>();
	//����һ���������ļ���
	private List<Object> suijiList=new ArrayList<Object>();
	//����һ���鿴�Ծ��ļ���
	private List<Question> findList=new ArrayList<Question>();
	
	
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public List<Question> getFindList() {
		return findList;
	}
	public void setFindList(List<Question> findList) {
		this.findList = findList;
	}
	public Paper getPaper() {
		return paper;
	}
	public void setPaper(Paper paper) {
		this.paper = paper;
	}
	public List<Object> getSuijiList() {
		return suijiList;
	}
	public void setSuijiList(List<Object> suijiList) {
		this.suijiList = suijiList;
	}
	public AddTemporary getAddTemporary() {
		return addTemporary;
	}
	public void setAddTemporary(AddTemporary addTemporary) {
		this.addTemporary = addTemporary;
	}
	public List<Paper> getPaperList() {
		return paperList;
	}
	public void setPaperList(List<Paper> paperList) {
		this.paperList = paperList;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	public List<Question> getQuesList() {
		return quesList;
	}
	public void setQuesList(List<Question> quesList) {
		this.quesList = quesList;
	}
	public List<Object[]> getObjList() {
		return objList;
	}
	public void setObjList(List<Object[]> objList) {
		this.objList = objList;
	}
	public String list(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "list";
		
		
	}
	public String admins(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		if (bid==1) {
			list=session.createCriteria(Students.class).list();
			for (int i = 0; i <list.size(); i++) {
				Students a=	(Students) list.get(i);
				if (a. getShao().equals(admin.getAname())&&a.getPwd().equals(admin.getPwd())) {
					ServletActionContext.getRequest().getSession().setAttribute("bm",1);
					ServletActionContext.getRequest().getSession().setAttribute("aname", admin.getAname());
					return "admins";
				}
			}
		}else if (bid==2) {
			list=session.createCriteria(Teacher.class).list();
			for (int i = 0; i <list.size(); i++) {
				Teacher a=	(Teacher) list.get(i);
				if (a.getTzhanghao().equals(admin.getAname())&&a.getPwd().equals(admin.getPwd())) {
					ServletActionContext.getRequest().getSession().setAttribute("bm",2);
					ServletActionContext.getRequest().getSession().setAttribute("aname", admin.getAname());
					return "admins";
				}
			}
		}else {
			list=session.createCriteria(Admin.class).list();
			for (int i = 0; i <list.size(); i++) {
				Admin a=	(Admin) list.get(i);
				if (a.getAname().equals(admin.getAname())&&a.getPwd().equals(admin.getPwd())) {
					ServletActionContext.getRequest().getSession().setAttribute("bm",3);
					ServletActionContext.getRequest().getSession().setAttribute("aname", admin.getAname());
					return "admins";
				}
			}
		}
		name="�˺Ż��������";
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return ERROR;
		
	}
	//ͳ�Ʋ�ѯ����
	public String tjcount(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		Criteria criteria=session.createCriteria(Question.class);
		ProjectionList project=Projections.projectionList()
								.add(Projections.groupProperty("major"))
								.add(Projections.groupProperty("chapter"))
								.add(Projections.groupProperty("jsbs"))
								.add(Projections.count("qid").as("count"));
		criteria.setProjection(project);
		objList=criteria.list();
		System.out.println(objList);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "tjcount";
		
	}
	//��ʾ����
	public String showT(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		String chapter = ServletActionContext.getRequest().getParameter("chapter");
		System.out.println(chapter);
		String major = ServletActionContext.getRequest().getParameter("major");
		System.out.println(major);
		String jsbs = ServletActionContext.getRequest().getParameter("jsbs");
		System.out.println(jsbs);
//		String hql = "select q from Question q where q.chapter=:chapter and q.major=:major and q.jsbs=:jsbs";
//		Query query=session.createQuery(hql)
//					.setParameter("chapter", chapter)
//					.setParameter("major", major)
//					.setParameter("jsbs", jsbs);
//		
//		quesList=query.list();	
		
		Criteria criteria=session.createCriteria(Question.class)
							.add(Restrictions.eq("chapter", chapter))
							.add(Restrictions.eq("major", major))
							.add(Restrictions.eq("jsbs", jsbs));
		quesList=criteria.list();
		System.out.println(quesList.size());
		ServletActionContext.getRequest().getSession().setAttribute("major", major);
		ServletActionContext.getRequest().getSession().setAttribute("chapter", chapter);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "showT";
	}
	//���ӵ���ת
	public String addShow(){
		
		return "addShow";	
	}
	//��������
	public String addQues(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		String major=(String) ServletActionContext.getRequest().getSession().getAttribute("major");
		String chapter=(String) ServletActionContext.getRequest().getSession().getAttribute("chapter");
		question.setMajor(major);
		question.setChapter(chapter);	
		session.save(question);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		tjcount();
		return "addQues";
		
	}
	//��ʾ�Ծ�
	public String showPaper(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		Criteria criteria=session.createCriteria(Paper.class);
		paperList=criteria.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "showPaper";
		
	}
	//����������ת
	public String suijiShow(){		
		return "suijiShow";		
	}
	
	//����������
	@SuppressWarnings("unchecked")
	public String addPaper(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		String sql="select qid from("
			+" select top "+addTemporary.getDjiandan()+" qid from t_question where major=? and chapter=? and kind='��ѡ' and difficulty='��' order by newId()"
			+" union"
			+" select top "+addTemporary.getDyiban()+" qid from t_question where major=? and chapter=? and kind='��ѡ' and difficulty='һ��' order by newId()"
			+" union"
			+" select top "+addTemporary.getDkunnan()+" qid from t_question where major=? and chapter=? and kind='��ѡ' and difficulty='����' order by newId()"
			+" union"
			+" select top "+addTemporary.getMorejiandan()+" qid from t_question where major=? and chapter=? and kind='��ѡ' and difficulty='��' order by newId()"
			+" union"
			+" select top "+addTemporary.getMoreyiban()+" qid from t_question where major=? and chapter=? and kind='��ѡ' and difficulty='һ��' order by newId()"
			+" union"
			+" select top "+addTemporary.getMorekunnan()+" qid from t_question where major=? and chapter=? and kind='��ѡ' and difficulty='����' order by newId()"
			+")as t";
		suijiList=session.createSQLQuery(sql)
					.setParameter(0, addTemporary.getMajor())
					.setParameter(1, addTemporary.getChapter())
					.setParameter(2, addTemporary.getMajor())
					.setParameter(3, addTemporary.getChapter())
					.setParameter(4, addTemporary.getMajor())
					.setParameter(5, addTemporary.getChapter())
					.setParameter(6, addTemporary.getMajor())
					.setParameter(7, addTemporary.getChapter())
					.setParameter(8, addTemporary.getMajor())
					.setParameter(9, addTemporary.getChapter())
					.setParameter(10, addTemporary.getMajor())
					.setParameter(11, addTemporary.getChapter()).list();
		paper.setKind(addTemporary.getMajor()+addTemporary.getChapter());
		paper.setState("1");
	for (Object obj : suijiList) {
		Question q=(Question) session.get(Question.class,new Integer (suijiList.toString()));
		paper.getqSet().add(q);
	
	}
	System.out.println(suijiList.size());
	session.save(paper);
			
		transaction.commit();
		HibernateSessionFactory.closeSession();
		showPaper();
		return "addPaper";
		
	}
	//�鿴�Ծ�
	public String findQueston(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		Criteria criteria=session.createCriteria(Question.class)
								 .setFetchMode("pSet", FetchMode.JOIN)
								 .createAlias("pSet","p")
								 .add(Restrictions.eq("p.pid",pid));
		findList=criteria.list();
		System.out.println(findList.size());
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "findQueston";
		
	}
	
	
	
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPagetotal() {
		return pagetotal;
	}
	public void setPagetotal(int pagetotal) {
		this.pagetotal = pagetotal;
	}
	public List getLis() {
		return lis;
	}
	public void setLis(List lis) {
		this.lis = lis;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public List getList() {
		return list;
	}
	public void setList(List list) {
		this.list = list;
	}
	public PageBran getPageBran() {
		return pageBran;
	}
	public void setPageBran(PageBran pageBran) {
		this.pageBran = pageBran;
	}
	public Admin getAdmin() {
		return admin;
	}
	public void setAdmin(Admin admin) {
		this.admin = admin;
	}
	
	
	
	

}
