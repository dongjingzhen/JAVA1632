package action;



import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.xml.crypto.Data;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import dao.HibernateSessionFactory;
import domain.Admin;
import domain.Paper;
import domain.Question;

public class textBooks {
	public static void main(String[] args) {
		
			save();
		
//		 saveaaa();
//		fenye();
	}
	public static void save()
	{
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		Admin a=new Admin();
		a.setAname("ldj");
		a.setPwd("123");
		session.save(a);
		for (int i = 0; i <20; i++) {
			Question question=new Question();
			question.setAnswer("A");
			question.setContent("ʲô��������죿");
			question.setOptionA("�Ա�");
			question.setOptionB("����");
			question.setChapter("G1");
			question.setMajor("java");
			question.setJsbs("����");						
			session.save(question);
		  	
		}
		

		transaction.commit();
		HibernateSessionFactory.closeSession();
	}

	
}
