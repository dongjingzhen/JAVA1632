package dao;

import org.hibernate.Session;
import org.hibernate.Transaction;
import domain.Admin;
import domain.Classes;
import domain.Question;
import domain.Students;
import domain.Teacher;
public class TestDao {
	public static void main(String[] args) {
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		Admin admin = new Admin();
		admin.setUserName("admin");
		admin.setPwd(123);
		Classes c = new Classes();
		Students s = new Students();
		s.setStudyNo("stu123");
		s.setSpwd(123);
		Teacher t = new Teacher();
		t.setTname("tea123");
		t.setTpwd(123);
		 
		
		session.save(admin);
		session.save(c);
		session.save(s);
		session.save(t);
		
		

		for (int i = 0; i < 10; i++) {
			Question q1=new Question("java","G1","��","��ѡ",i+"1+1���ڣ�","2","3","4","5","A","����");
			session.save(q1);
		}
		for (int i = 0; i < 10; i++) {
			Question q1=new Question("java","G1","��","��ѡ",i+"1+1���ڣ�","2","3","4","5","A","����");
			session.save(q1);
		}
		for (int i = 0; i < 10; i++) {
			Question q1=new Question("java","G2","һ��","��ѡ",i+"1+1���ڣ�","2","3","4","5","A","����");
			session.save(q1);
		}
		for (int i = 0; i < 10; i++) {
			Question q1=new Question("java","G2","��","��ѡ",i+"1+1���ڣ�","2","3","4","5","A","����");
			session.save(q1);
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
}
