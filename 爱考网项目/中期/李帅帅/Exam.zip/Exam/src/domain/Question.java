package domain;

import java.util.HashSet;
import java.util.Set;

public class Question {
	private int qid;
	private String major;
	private String stage;  //�׶�
	private String difficulty;   //���׳̶�
	private String selects;  //��ѡ��ѡ
	private String neirong;
	private String optionA;
	private String optionB;
	private String optionC;
	private String optionD;
	private String answer;
	private String type;    //���Ի��Ǳ���
//	private String remarks;   
	
	private Set<Papers>  paperSet=new HashSet<Papers>();//�Ծ��ļ���
	
	
	
	
	public Question() {
		super();
	}
	public Question(String major, String stage, String difficulty, String selects,
			String neirong, String optionA, String optionB, String optionC,
			String optionD, String answer, String type) {
		super();
		this.major = major;
		this.stage = stage;
		this.difficulty = difficulty;
		this.selects = selects;
		this.neirong = neirong;
		this.optionA = optionA;
		this.optionB = optionB;
		this.optionC = optionC;
		this.optionD = optionD;
		this.answer = answer;
		this.type = type;
	}
	
	public String getStage() {
		return stage;
	}
	public void setStage(String stage) {
		this.stage = stage;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public Set<Papers> getPaperSet() {
		return paperSet;
	}
	public void setPaperSet(Set<Papers> paperSet) {
		this.paperSet = paperSet;
	}
	public int getQid() {
		return qid;
	}
	public void setQid(int qid) {
		this.qid = qid;
	}
	
	public String getSelects() {
		return selects;
	}
	public void setSelects(String selects) {
		this.selects = selects;
	}
	public String getNeirong() {
		return neirong;
	}
	public void setNeirong(String neirong) {
		this.neirong = neirong;
	}
	public String getOptionA() {
		return optionA;
	}
	public void setOptionA(String optionA) {
		this.optionA = optionA;
	}
	public String getOptionB() {
		return optionB;
	}
	public void setOptionB(String optionB) {
		this.optionB = optionB;
	}
	public String getOptionC() {
		return optionC;
	}
	public void setOptionC(String optionC) {
		this.optionC = optionC;
	}
	public String getOptionD() {
		return optionD;
	}
	public void setOptionD(String optionD) {
		this.optionD = optionD;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getDifficulty() {
		return difficulty;
	}
	public void setDifficulty(String difficulty) {
		this.difficulty = difficulty;
	}
//	public String getRemarks() {
//		return remarks;
//	}
//	public void setRemarks(String remarks) {
//		this.remarks = remarks;
//	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	
}
