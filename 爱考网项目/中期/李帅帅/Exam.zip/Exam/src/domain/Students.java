package domain;

import java.util.Date;

public class Students {
	private int sid;
	private String studyNo;     
	private String sname; 
	private int spwd;
	private String ssex;  
	private String syear; 
	private Date sbirthday; 
	private String stelephone;//��ϵ�绰
	private String sparentsTel;//�ҳ���ϵ�绰
	private String idCard;  //����֤��
	private String zhengzhi; //������ò
	private String shengFen;  //ʡ��
	private String city; 
	private String major;  //רҵ
	private String jiududirection; //�Ͷ�����
	private String Address;//��ͥסַ
	private String releation;//��ϵ
	private String sushe; //����
	private String susheNo;//�����
	private String baseInfo; //������Ϣ
	private String educationBj; //��������
	private String image;
	private int classes_id;
	
	
	private Classes classes;  //�����༶


	public int getSpwd() {
		return spwd;
	}


	public void setSpwd(int spwd) {
		this.spwd = spwd;
	}


	public int getSid() {
		return sid;
	}


	public void setSid(int sid) {
		this.sid = sid;
	}


	public String getStudyNo() {
		return studyNo;
	}


	public void setStudyNo(String studyNo) {
		this.studyNo = studyNo;
	}


	public String getSname() {
		return sname;
	}


	public void setSname(String sname) {
		this.sname = sname;
	}


	public String getSsex() {
		return ssex;
	}


	public void setSsex(String ssex) {
		this.ssex = ssex;
	}


	public String getSyear() {
		return syear;
	}


	public void setSyear(String syear) {
		this.syear = syear;
	}


	public Date getSbirthday() {
		return sbirthday;
	}


	public void setSbirthday(Date sbirthday) {
		this.sbirthday = sbirthday;
	}


	public String getStelephone() {
		return stelephone;
	}


	public void setStelephone(String stelephone) {
		this.stelephone = stelephone;
	}


	public String getSparentsTel() {
		return sparentsTel;
	}


	public void setSparentsTel(String sparentsTel) {
		this.sparentsTel = sparentsTel;
	}


	public String getIdCard() {
		return idCard;
	}


	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}


	public String getZhengzhi() {
		return zhengzhi;
	}


	public void setZhengzhi(String zhengzhi) {
		this.zhengzhi = zhengzhi;
	}


	public String getShengFen() {
		return shengFen;
	}


	public void setShengFen(String shengFen) {
		this.shengFen = shengFen;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getMajor() {
		return major;
	}


	public void setMajor(String major) {
		this.major = major;
	}


	public String getJiududirection() {
		return jiududirection;
	}


	public void setJiududirection(String jiududirection) {
		this.jiududirection = jiududirection;
	}


	public String getAddress() {
		return Address;
	}


	public void setAddress(String address) {
		Address = address;
	}


	public String getReleation() {
		return releation;
	}


	public void setReleation(String releation) {
		this.releation = releation;
	}


	public String getSushe() {
		return sushe;
	}


	public void setSushe(String sushe) {
		this.sushe = sushe;
	}


	public String getSusheNo() {
		return susheNo;
	}


	public void setSusheNo(String susheNo) {
		this.susheNo = susheNo;
	}


	public String getBaseInfo() {
		return baseInfo;
	}


	public void setBaseInfo(String baseInfo) {
		this.baseInfo = baseInfo;
	}


	public String getEducationBj() {
		return educationBj;
	}


	public void setEducationBj(String educationBj) {
		this.educationBj = educationBj;
	}


	public String getImage() {
		return image;
	}


	public void setImage(String image) {
		this.image = image;
	}




	public int getClasses_id() {
		return classes_id;
	}


	public void setClasses_id(int classesId) {
		classes_id = classesId;
	}


	public Classes getClasses() {
		return classes;
	}


	public void setClasses(Classes classes) {
		this.classes = classes;
	}


	
	
}
