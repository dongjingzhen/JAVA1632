package domain;

public class Users {
	private String account;
	private int mima;
	private String role;
	
	
	
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public int getMima() {
		return mima;
	}
	public void setMima(int mima) {
		this.mima = mima;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	
	
}
