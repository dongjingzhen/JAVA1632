package domain;

import java.util.HashSet;
import java.util.Set;

public class Teacher {
	private int tid;
	private String tcount;
	private String tname;
	private int tpwd;
	private String tsex;
	private String tbirthday;
	private String teducation;
	private String ttelphone;
	private String tjob;
	private String tremarks;
	
	
	private Set<Classes> classesteaset = new HashSet<Classes>();
	private Set<Classes> classeslecset = new HashSet<Classes>();
	
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public String getTcount() {
		return tcount;
	}
	public void setTcount(String tcount) {
		this.tcount = tcount;
	}
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public int getTpwd() {
		return tpwd;
	}
	public void setTpwd(int tpwd) {
		this.tpwd = tpwd;
	}
	public String getTsex() {
		return tsex;
	}
	public void setTsex(String tsex) {
		this.tsex = tsex;
	}
	public String getTbirthday() {
		return tbirthday;
	}
	public void setTbirthday(String tbirthday) {
		this.tbirthday = tbirthday;
	}
	public String getTeducation() {
		return teducation;
	}
	public void setTeducation(String teducation) {
		this.teducation = teducation;
	}
	public String getTtelphone() {
		return ttelphone;
	}
	public void setTtelphone(String ttelphone) {
		this.ttelphone = ttelphone;
	}
	public String getTjob() {
		return tjob;
	}
	public void setTjob(String tjob) {
		this.tjob = tjob;
	}
	public String getTremarks() {
		return tremarks;
	}
	public void setTremarks(String tremarks) {
		this.tremarks = tremarks;
	}
	public Set<Classes> getClassesteaset() {
		return classesteaset;
	}
	public void setClassesteaset(Set<Classes> classesteaset) {
		this.classesteaset = classesteaset;
	}
	public Set<Classes> getClasseslecset() {
		return classeslecset;
	}
	public void setClasseslecset(Set<Classes> classeslecset) {
		this.classeslecset = classeslecset;
	}
	
	
	
	
	
}
