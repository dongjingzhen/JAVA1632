package domain;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;


public class Papers {
	private int pid;//id
	private String title;//�Ծ�����
	private String kemu;//��Ŀ
	private String type;//���Ա���
	private String state="δ����";//״̬
	private Date startTime;//��ʼ���Ե�ʱ��
	private int minute;//����ʱ������λ������
	private int totalScore;//�Ծ��ܷ�
	private int totalQuestion;//������
	private int average;//ÿ��ƽ����
	private Set<Question> questionSet=new HashSet<Question>();//�Ծ������⼯��
	private Set<Classes> classSet=new HashSet<Classes>();//�Ծ��İ༶����
	
	
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Set<Classes> getClassSet() {
		return classSet;
	}
	public void setClassSet(Set<Classes> classSet) {
		this.classSet = classSet;
	}
	public String getKemu() {
		return kemu;
	}
	public void setKemu(String kemu) {
		this.kemu = kemu;
	}
	public int getTotalQuestion() {
		return totalQuestion;
	}
	public void setTotalQuestion(int totalQuestion) {
		this.totalQuestion = totalQuestion;
	}
	
	public Set<Question> getQuestionSet() {
		return questionSet;
	}
	public void setQuestionSet(Set<Question> questionSet) {
		this.questionSet = questionSet;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(int totalScore) {
		this.totalScore = totalScore;
	}
	public int getAverage() {
		return average;
	}
	public void setAverage(int average) {
		this.average = average;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public int getMinute() {
		return minute;
	}
	public void setMinute(int minute) {
		this.minute = minute;
	}
	
}
