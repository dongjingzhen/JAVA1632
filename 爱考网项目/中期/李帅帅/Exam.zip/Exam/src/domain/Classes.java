package domain;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;


public class Classes {
	private int cid;
	private String classNo;
	private String cname;
	private String direction;
	private String headteacher;
	private String lecture;
	private Date cdate;  //����ʱ��
	private String state;
	private String remark;//��ע
	
	private Set<Students> studentSet = new HashSet<Students>();  
	private Set<Papers> paperSet=new HashSet<Papers>();//�༶��Ҫ�����Ծ�
	
	
	
	public Classes() {}
	public Classes( String classNo, String cname, String direction,
			Date cdate, String state, String remark) {
		super();
		this.classNo = classNo;
		this.cname = cname;
		this.direction = direction;
		this.cdate = cdate;
		this.state = state;
		this.remark = remark;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Set<Papers> getPaperSet() {
		return paperSet;
	}
	public void setPaperSet(Set<Papers> paperSet) {
		this.paperSet = paperSet;
	}
	public Set<Students> getStudentSet() {
		return studentSet;
	}
	public void setStudentSet(Set<Students> studentSet) {
		this.studentSet = studentSet;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getClassNo() {
		return classNo;
	}
	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getHeadteacher() {
		return headteacher;
	}
	public void setHeadteacher(String headteacher) {
		this.headteacher = headteacher;
	}
	public String getLecture() {
		return lecture;
	}
	public void setLecture(String lecture) {
		this.lecture = lecture;
	}
	public Date getCdate() {
		return cdate;
	}
	public void setCdate(Date cdate) {
		this.cdate = cdate;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
}
