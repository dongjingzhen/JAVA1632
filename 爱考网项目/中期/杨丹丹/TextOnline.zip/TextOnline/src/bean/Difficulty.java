package bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Difficulty entity. @author MyEclipse Persistence Tools
 */

public class Difficulty implements java.io.Serializable {

	// Fields

	private Integer difid;
	private String difname;
	private Set topics = new HashSet(0);

	// Constructors

	/** default constructor */
	public Difficulty() {
	}

	/** minimal constructor */
	public Difficulty(Integer difid, String difname) {
		this.difid = difid;
		this.difname = difname;
	}

	/** full constructor */
	public Difficulty(Integer difid, String difname, Set topics) {
		this.difid = difid;
		this.difname = difname;
		this.topics = topics;
	}

	// Property accessors

	public Integer getDifid() {
		return this.difid;
	}

	public void setDifid(Integer difid) {
		this.difid = difid;
	}

	public String getDifname() {
		return this.difname;
	}

	public void setDifname(String difname) {
		this.difname = difname;
	}

	public Set getTopics() {
		return this.topics;
	}

	public void setTopics(Set topics) {
		this.topics = topics;
	}

}