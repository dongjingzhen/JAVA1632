package bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Type entity. @author MyEclipse Persistence Tools
 */

public class Type implements java.io.Serializable {

	// Fields

	private Integer tyid;
	private String tyname;
	private Set topics = new HashSet(0);
	//private Set papers = new HashSet(0);

	// Constructors

	/** default constructor */
	public Type() {
	}

	/** minimal constructor */
	public Type(Integer tyid, String tyname) {
		this.tyid = tyid;
		this.tyname = tyname;
	}

	/** full constructor */
	public Type(Integer tyid, String tyname, Set topics) {
		this.tyid = tyid;
		this.tyname = tyname;
		this.topics = topics;
		//this.papers = papers;
	}

	// Property accessors

	public Integer getTyid() {
		return this.tyid;
	}

	public void setTyid(Integer tyid) {
		this.tyid = tyid;
	}

	public String getTyname() {
		return this.tyname;
	}

	public void setTyname(String tyname) {
		this.tyname = tyname;
	}

	public Set getTopics() {
		return this.topics;
	}

	public void setTopics(Set topics) {
		this.topics = topics;
	}

//	public Set getPapers() {
//		return this.papers;
//	}
//
//	public void setPapers(Set papers) {
//		this.papers = papers;
//	}

}