package bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Clas entity. @author MyEclipse Persistence Tools
 */

public class Clas implements java.io.Serializable {

	// Fields

	private Integer clid;
	private String clname;
	private Set papers=new HashSet(); 
	private Set classs=new HashSet();

	// Constructors

	/** default constructor */
	public Clas() {
	}

	

	// Property accessors

	public Integer getClid() {
		return this.clid;
	}

	public void setClid(Integer clid) {
		this.clid = clid;
	}

	public String getClname() {
		return this.clname;
	}

	public void setClname(String clname) {
		this.clname = clname;
	}



	public Set getPapers() {
		return papers;
	}



	public void setPapers(Set papers) {
		this.papers = papers;
	}



	public Set getClasss() {
		return classs;
	}



	public void setClasss(Set classs) {
		this.classs = classs;
	}
	
	



	
	

}