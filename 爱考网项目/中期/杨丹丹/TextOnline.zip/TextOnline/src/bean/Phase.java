package bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Phase entity. @author MyEclipse Persistence Tools
 */

public class Phase implements java.io.Serializable {

	// Fields

	private Integer phid;
	private String phname;
	private Set subjects = new HashSet(0);

	// Constructors

	/** default constructor */
	public Phase() {
	}

	/** minimal constructor */
	public Phase(Integer phid, String phname) {
		this.phid = phid;
		this.phname = phname;
	}

	/** full constructor */
	public Phase(Integer phid, String phname, Set subjects) {
		this.phid = phid;
		this.phname = phname;
		this.subjects = subjects;
	}

	// Property accessors

	public Integer getPhid() {
		return this.phid;
	}

	public void setPhid(Integer phid) {
		this.phid = phid;
	}

	public String getPhname() {
		return this.phname;
	}

	public void setPhname(String phname) {
		this.phname = phname;
	}

	public Set getSubjects() {
		return this.subjects;
	}

	public void setSubjects(Set subjects) {
		this.subjects = subjects;
	}

}