package bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Subject entity. @author MyEclipse Persistence Tools
 */

public class Subject implements java.io.Serializable {

	// Fields

	private Integer subid;
	private Direction direction;
	private Phase phase;
	private String subname;
	private Set topics = new HashSet(0);
	private Set papers = new HashSet(0);

	// Constructors

	/** default constructor */
	public Subject() {
	}

	/** minimal constructor */
	public Subject(Integer subid, Direction direction, Phase phase,
			String subname) {
		this.subid = subid;
		this.direction = direction;
		this.phase = phase;
		this.subname = subname;
	}

	/** full constructor */
	public Subject(Integer subid, Direction direction, Phase phase,
			String subname, Set topics, Set papers) {
		this.subid = subid;
		this.direction = direction;
		this.phase = phase;
		this.subname = subname;
		this.topics = topics;
		this.papers = papers;
	}

	// Property accessors

	public Integer getSubid() {
		return this.subid;
	}

	public void setSubid(Integer subid) {
		this.subid = subid;
	}

	public Direction getDirection() {
		return this.direction;
	}

	public void setDirection(Direction direction) {
		this.direction = direction;
	}

	public Phase getPhase() {
		return this.phase;
	}

	public void setPhase(Phase phase) {
		this.phase = phase;
	}

	public String getSubname() {
		return this.subname;
	}

	public void setSubname(String subname) {
		this.subname = subname;
	}

	public Set getTopics() {
		return this.topics;
	}

	public void setTopics(Set topics) {
		this.topics = topics;
	}

	public Set getPapers() {
		return this.papers;
	}

	public void setPapers(Set papers) {
		this.papers = papers;
	}

}