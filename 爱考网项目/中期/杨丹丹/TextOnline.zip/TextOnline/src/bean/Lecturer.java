package bean;

/**
 * Lecturer entity. @author MyEclipse Persistence Tools
 */

public class Lecturer implements java.io.Serializable {

	// Fields

	private Integer lecid;
	private String lecname;
	private String lecpwd;

	// Constructors

	/** default constructor */
	public Lecturer() {
	}

	/** full constructor */
	public Lecturer(Integer lecid, String lecname, String lecpwd) {
		this.lecid = lecid;
		this.lecname = lecname;
		this.lecpwd = lecpwd;
	}

	// Property accessors

	public Integer getLecid() {
		return this.lecid;
	}

	public void setLecid(Integer lecid) {
		this.lecid = lecid;
	}

	public String getLecname() {
		return this.lecname;
	}

	public void setLecname(String lecname) {
		this.lecname = lecname;
	}

	public String getLecpwd() {
		return this.lecpwd;
	}

	public void setLecpwd(String lecpwd) {
		this.lecpwd = lecpwd;
	}

}