package bean;

/**
 * Shijuanbanji entity. @author MyEclipse Persistence Tools
 */

public class Shijuanbanji implements java.io.Serializable {

	// Fields

	private Integer sbid;
	private Clas clas;
	private Paper paper;

	// Constructors

	/** default constructor */
	public Shijuanbanji() {
	}

	/** minimal constructor */
	public Shijuanbanji(Integer sbid, Paper paper) {
		this.sbid = sbid;
		this.paper = paper;
	}

	/** full constructor */
	public Shijuanbanji(Integer sbid, Clas clas, Paper paper) {
		this.sbid = sbid;
		this.clas = clas;
		this.paper = paper;
	}

	// Property accessors

	public Integer getSbid() {
		return this.sbid;
	}

	public void setSbid(Integer sbid) {
		this.sbid = sbid;
	}

	public Clas getClas() {
		return this.clas;
	}

	public void setClas(Clas clas) {
		this.clas = clas;
	}

	public Paper getPaper() {
		return this.paper;
	}

	public void setPaper(Paper paper) {
		this.paper = paper;
	}

}