package bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Topic entity. @author MyEclipse Persistence Tools
 */

public class Topic implements java.io.Serializable {

	// Fields

	private Integer topid;
	private Difficulty difficulty;
	private Subject subject;
	private Type type;
	private String conten;
	private String a;
	private String b;
	private String c;
	private String d;
	private String answer;
	private Set cuntis = new HashSet(0);
	private Set papers=new HashSet(0);

	// Constructors

	/** default constructor */
	public Topic() {
	}

	/** minimal constructor */
	public Topic(Integer topid, Difficulty difficulty, Subject subject,
			Type type, String conten, String a, String b, String c, String d,
			String answer) {
		this.topid = topid;
		this.difficulty = difficulty;
		this.subject = subject;
		this.type = type;
		this.conten = conten;
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
		this.answer = answer;
	}

	/** full constructor */
	public Topic(Integer topid, Difficulty difficulty, Subject subject,
			Type type, String conten, String a, String b, String c, String d,
			String answer, Set cuntis) {
		this.topid = topid;
		this.difficulty = difficulty;
		this.subject = subject;
		this.type = type;
		this.conten = conten;
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
		this.answer = answer;
		this.cuntis = cuntis;
	}

	// Property accessors

	public Integer getTopid() {
		return this.topid;
	}

	public void setTopid(Integer topid) {
		this.topid = topid;
	}

	public Difficulty getDifficulty() {
		return this.difficulty;
	}

	public void setDifficulty(Difficulty difficulty) {
		this.difficulty = difficulty;
	}

	public Subject getSubject() {
		return this.subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	public Type getType() {
		return this.type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public String getConten() {
		return this.conten;
	}

	public void setConten(String conten) {
		this.conten = conten;
	}

	public String getA() {
		return this.a;
	}

	public void setA(String a) {
		this.a = a;
	}

	public String getB() {
		return this.b;
	}

	public void setB(String b) {
		this.b = b;
	}

	public String getC() {
		return this.c;
	}

	public void setC(String c) {
		this.c = c;
	}

	public String getD() {
		return this.d;
	}

	public void setD(String d) {
		this.d = d;
	}

	public String getAnswer() {
		return this.answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public Set getCuntis() {
		return this.cuntis;
	}

	public void setCuntis(Set cuntis) {
		this.cuntis = cuntis;
	}

	public Set getPapers() {
		return papers;
	}

	public void setPapers(Set papers) {
		this.papers = papers;
	}
	
}