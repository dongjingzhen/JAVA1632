package bean;

/**
 * Administrator entity. @author MyEclipse Persistence Tools
 */

public class Administrator implements java.io.Serializable {

	// Fields

	private Integer admid;
	private String admname;
	private String admpwd;

	// Constructors

	/** default constructor */
	public Administrator() {
	}

	/** full constructor */
	public Administrator(Integer admid, String admname, String admpwd) {
		this.admid = admid;
		this.admname = admname;
		this.admpwd = admpwd;
	}

	// Property accessors

	public Integer getAdmid() {
		return this.admid;
	}

	public void setAdmid(Integer admid) {
		this.admid = admid;
	}

	public String getAdmname() {
		return this.admname;
	}

	public void setAdmname(String admname) {
		this.admname = admname;
	}

	public String getAdmpwd() {
		return this.admpwd;
	}

	public void setAdmpwd(String admpwd) {
		this.admpwd = admpwd;
	}

}