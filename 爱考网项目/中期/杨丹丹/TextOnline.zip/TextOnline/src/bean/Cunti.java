package bean;

/**
 * Cunti entity. @author MyEclipse Persistence Tools
 */

public class Cunti implements java.io.Serializable {

	// Fields

	private Integer ctid;
	private Topic topic;
	private Paper paper;

	// Constructors

	/** default constructor */
	public Cunti() {
	}

	/** full constructor */
	public Cunti(Integer ctid, Topic topic, Paper paper) {
		this.ctid = ctid;
		this.topic = topic;
		this.paper = paper;
	}

	// Property accessors

	public Integer getCtid() {
		return this.ctid;
	}

	public void setCtid(Integer ctid) {
		this.ctid = ctid;
	}

	public Topic getTopic() {
		return this.topic;
	}

	public void setTopic(Topic topic) {
		this.topic = topic;
	}

	public Paper getPaper() {
		return this.paper;
	}

	public void setPaper(Paper paper) {
		this.paper = paper;
	}

}