package bean;

import java.util.HashSet;
import java.util.Set;

/**
 * Direction entity. @author MyEclipse Persistence Tools
 */

public class Direction implements java.io.Serializable {

	// Fields

	private Integer dirid;
	private String dirname;
	private Set subjects = new HashSet(0);

	// Constructors

	/** default constructor */
	public Direction() {
	}

	/** minimal constructor */
	public Direction(Integer dirid, String dirname) {
		this.dirid = dirid;
		this.dirname = dirname;
	}

	/** full constructor */
	public Direction(Integer dirid, String dirname, Set subjects) {
		this.dirid = dirid;
		this.dirname = dirname;
		this.subjects = subjects;
	}

	// Property accessors

	public Integer getDirid() {
		return this.dirid;
	}

	public void setDirid(Integer dirid) {
		this.dirid = dirid;
	}

	public String getDirname() {
		return this.dirname;
	}

	public void setDirname(String dirname) {
		this.dirname = dirname;
	}

	public Set getSubjects() {
		return this.subjects;
	}

	public void setSubjects(Set subjects) {
		this.subjects = subjects;
	}

}