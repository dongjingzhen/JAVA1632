package bean;

import java.util.HashSet;
import java.util.Set;

import com.sun.org.apache.bcel.internal.generic.NEW;

/**
 * Paper entity. @author MyEclipse Persistence Tools
 */

public class Paper implements java.io.Serializable {

	// Fields

	private Integer paid;
	private Subject subject;
	private String headline;
	private Integer time;
	private String state;
	private Integer fenshu;
	private Integer tishu;
	private String kaishishijian;
	private Set classs=new HashSet();
	private Set topics=new HashSet(0);
	// Constructors

	/** default constructor */
	public Paper() {
	}

	

	// Property accessors

	public Integer getPaid() {
		return this.paid;
	}

	public void setPaid(Integer paid) {
		this.paid = paid;
	}

	public Subject getSubject() {
		return this.subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}


	public String getHeadline() {
		return this.headline;
	}

	public void setHeadline(String headline) {
		this.headline = headline;
	}

	public Integer getTime() {
		return this.time;
	}

	public void setTime(Integer time) {
		this.time = time;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}


	public Set getClasss() {
		return classs;
	}



	public void setClasss(Set classs) {
		this.classs = classs;
	}



	public Set getTopics() {
		return topics;
	}

	public void setTopics(Set topics) {
		this.topics = topics;
	}



	public Integer getFenshu() {
		return fenshu;
	}



	public void setFenshu(Integer fenshu) {
		this.fenshu = fenshu;
	}



	public Integer getTishu() {
		return tishu;
	}



	public void setTishu(Integer tishu) {
		this.tishu = tishu;
	}



	public String getKaishishijian() {
		return kaishishijian;
	}



	public void setKaishishijian(String kaishishijian) {
		this.kaishishijian = kaishishijian;
	}
	
	
	
}