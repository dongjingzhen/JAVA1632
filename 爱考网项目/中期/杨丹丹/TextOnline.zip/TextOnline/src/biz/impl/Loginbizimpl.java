package biz.impl;

import java.util.List;

import dao.impl.LoginDaoimpl;

import bean.Administrator;
import bean.Cunti;
import bean.Direction;
import bean.Paper;
import bean.Phase;
import bean.Subject;
import bean.Topic;
import biz.Loginbiz;

public class Loginbizimpl implements Loginbiz {
	LoginDaoimpl ldi=new LoginDaoimpl();
	
	//�鿴�Ծ�
	public List<Topic> ckshijuan(int[] x) {
		// TODO Auto-generated method stub
		return ldi.ckshijuan(x);
	}
	//�����Ծ�     i-->paid
	public List<Cunti> chakanshijuan(int i) {
		// TODO Auto-generated method stub
		return ldi.chakanshijuan(i);
	}
	
	
	//�����ѯ�в�ѯ��Ŀ��id	
	public List<Topic> suijiidfind() {
		// TODO Auto-generated method stub
		return ldi.suijiidfind();
	}
	
	
	//��ѯ�Ծ�
	public List<Paper> shijuanfind() {
		return ldi.shijuanfind();
	}
	
	//�����
	public int tianjiashijuan(int x[],int i,String biaoti,String zhuangtai,int shijian,int tishu,int fenshu){
		return ldi.tianjiashijuan(x,i,biaoti,zhuangtai,shijian,tishu,fenshu);
	}
	//�Ծ��в�ѯ���
	public List<Topic> shijuantikufind(int i) {
		// TODO Auto-generated method stub
		return ldi.shijuantikufind(i);
	}
	
	
	//ɾ������
	public int dele(int i) {
		// TODO Auto-generated method stub
		return ldi.dele(i);
	}
	//�޸������ѯ
	public List<Topic> upsel(int i) {
		// TODO Auto-generated method stub
		return ldi.upsel(i);
	}
	//��������
	public int addtop(Topic top) {
		// TODO Auto-generated method stub
		return ldi.addtop(top);
	}

	
	//�����ѯ
	public List<Topic> topfind(int i,int j) {
		// TODO Auto-generated method stub
		return ldi.topfind(i,j);
	}
	//�����ڲ�ѯ�׶�	
	public String fph(int i) {
		// TODO Auto-generated method stub
		return ldi.fph(i);
	}
	
	//��ѯ�׶�
	public List<Phase> phfind() {
		return ldi.phfind();
	}
	//��ѯ����
	public List<Direction> dirfind() {
		// TODO Auto-generated method stub
		return ldi.dirfind();
	}

	
	//��ѯ��Ŀ
	public List<Object []> subfind(int i) {
		// TODO Auto-generated method stub
		return ldi.subfind(i);
	}
	
	
	
	public List<bean.Lecturer> Lecturer(bean.Lecturer lect) {
		
		return ldi.Lecturer(lect);
	}

	public List<bean.Student> Student(bean.Student stu) {
		return ldi.Student(stu);
	}

	public List<Administrator> administrator(Administrator admin) {
		return ldi.administrator(admin);
	}


	


	
	
	


	
	

	





	
	
	

}
