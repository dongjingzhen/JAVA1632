package dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import bean.Administrator;
import bean.Cunti;
import bean.Difficulty;
import bean.Direction;
import bean.Paper;
import bean.Phase;
import bean.Subject;
import bean.Topic;
import bean.Type;
import dao.HibernateSessionFactory;
import dao.LoginDao;

public class LoginDaoimpl implements LoginDao {
	Session se=HibernateSessionFactory.getSession();	
	
	//�鿴�Ծ�
	public List<Topic> ckshijuan(int x[]){
		List<Topic> list=new ArrayList<Topic>();
		String hql="from Topic where topid=?";
		Query q=null;
		for (int i = 0; i < x.length; i++) {
			q=se.createQuery(hql);
			q.setInteger(0, x[i]);
			list.add((Topic) q.list().get(0));
		}
		System.out.println(q.list().size()+"cccccccccccccccccccc");
		return list;		
	}
	
	
	//�����Ծ�     i-->paid
	public List<Cunti> chakanshijuan(int i){
		String hql="from Cunti where paid=?";
		Query q=se.createQuery(hql);
		q.setInteger(0, i);
		return q.list();		
	}
	
	
	
	
	//�����ѯ�в�ѯ��Ŀ��id	
	public List<long[]> Aaa(){
		return null;
		
	}
	
	public List<Topic> suijiidfind(){
		String hql="select t.topid from Topic t";
		Query q=se.createQuery(hql);
//		List<String []> list=new ArrayList<String []>();
//		List<Integer []> inlist=new ArrayList<Integer[]>();
//		
//		for (Object[] obj : re) {
//
//			//System.out.println(Integer.parseInt(obj[0].toString()));
//		}	
		
		return q.list();		
	}
	
	
	//��ѯ�Ծ�
	public List<Paper> shijuanfind(){
		String hql="from Paper";
		Query q=se.createQuery(hql);
		return q.list();
	}
	
	
	/**
	 * �����Ծ����� 
	 * ����������1:int x[]��ʾ���Ծ���Ӧ�����id  2:int i��ʾ�Ծ���Ӧ��Ŀid
	 * ����ֵz��ʾ�Ƿ����ӳɹ�
	 */
	public int tianjiashijuan(int x[],int i,String biaoti,String zhuangtai,int shijian,int tishu,int fenshu){
		Transaction t=se.getTransaction();
		//�½��Ծ�
		Paper paper=new Paper();
		paper.setHeadline(biaoti);
		paper.setState(zhuangtai);
		paper.setTime(shijian);
		paper.setTishu(tishu);
		paper.setFenshu(fenshu);
		Topic top;
		int z=0;
		try {
			String hql="from Topic where topid=?";
			t.begin();
			//ѭ���������� ��������id�鵽�������  ����浽set������
			for (int j = 0; j < x.length; j++) {
				Query q=se.createQuery(hql);
				q.setInteger(0, x[j]);
				top=(Topic)q.uniqueResult();
				System.out.println(top.getConten());
				paper.getTopics().add(top);
			}
			//���ݿ�Ŀid ��ѯ����Ŀ���� ����
			Subject s=(Subject)se.get(Subject.class, i);
			s.getPapers().add(paper);
			paper.setSubject(s);
			System.out.println(paper.getTopics());
			se.save(paper);
			t.commit();
		} catch (Exception e) {
			z=1;
			t.rollback();
			e.printStackTrace();
			// TODO: handle exception
		}
		
	
		return z;
	};
	
	//�Ծ��в�ѯ���	
	public List<Topic> shijuantikufind(int i){
		String hql="from Topic where subid=?";
		Query q=se.createQuery(hql);
		q.setInteger(0, i);
		q.list();
		
		return q.list();
	 }
	
	
	
	//ɾ������
	public int dele(int i){
		int j=0;
		try {
			Transaction tx=se.beginTransaction();
			Topic t=(Topic) se.get(Topic.class, i);
			System.out.println(t.getConten());
//			t.setDifficulty(t.getDifficulty());
//			t.getDifficulty().getTopics().add(t);
			System.out.println(t.getDifficulty().getDifid());
			System.out.println(t.getDifficulty().getDifname());
			System.out.println(t.getDifficulty().getTopics());
			se.delete(t);
			tx.commit();
		} catch (Exception e) {
			j=1;
			e.printStackTrace();
		}		
		return j;
		
	}
	
	//�޸������ѯ
	public List<Topic> upsel(int i){
		String hql="from Topic where topid=?";
		Query q=se.createQuery(hql);
		q.setInteger(0, i);
		return q.list();
	}	
	//��������
	public int addtop(Topic topp){
		int i=0;
		Transaction tx=se.beginTransaction();
		System.out.println(topp.getTopid()+"ooooooooooooooooooooooooo");
		try {
			if(topp.getTopid()==null){				
				Subject su=(Subject) se.get(Subject.class,topp.getSubject().getSubid());
				topp.setSubject(su);			
				Difficulty di=(Difficulty)se.get(Difficulty.class, topp.getDifficulty().getDifid());
			    Type type=(Type) se.get(Type.class, topp.getType().getTyid());
			    topp.setType(type);		    
				topp.setDifficulty(di);
				System.out.println("111111111111");
				se.save(topp);
				
			}else{
				Subject oldsubject=(Subject) se.get(Subject.class, topp.getSubject().getSubid());
				topp.setSubject(oldsubject);
				Topic oldtopic=(Topic) se.get(Topic.class, topp.getTopid());
				Type oldtype=(Type) se.get(Type.class, topp.getType().getTyid());
				topp.setType(oldtype);
				Difficulty difficulty=(Difficulty)se.get(Difficulty.class, topp.getDifficulty().getDifid());
				topp.setDifficulty(difficulty);
				//�Ƿ��޸�A				
				if (!oldtopic.getA().equals(topp.getA())) {
					oldtopic.setA(topp.getA());
				}             
				//�Ƿ��޸�B
				if(!oldtopic.getB().equals(topp.getB())){
					oldtopic.setB(topp.getB());
				}
				//�Ƿ��޸�C
				if(!oldtopic.getC().equals(topp.getC())){
					oldtopic.setC(topp.getC());
				}
				//�Ƿ��޸�D
				if(!oldtopic.getD().equals(topp.getD())){
					oldtopic.setD(topp.getD());
				}
				//�Ƿ��޸�Answer    
				if(oldtopic.getAnswer()!=topp.getAnswer()){
					oldtopic.setAnswer(topp.getAnswer());
				}
				//�Ƿ��޸�Subject
				if(oldtopic.getSubject()!=topp.getSubject()){
					oldtopic.setSubject(topp.getSubject());
				}
				//�Ƿ��޸�Type
				if(oldtopic.getType()!=topp.getType()){
					oldtopic.setType(topp.getType());
				}
				//�Ƿ��޸�Diffculty
				if(oldtopic.getDifficulty()!=topp.getDifficulty()){
					oldtopic.setDifficulty(topp.getDifficulty());
				}
				System.out.println("22222222222");
				se.merge(topp);
				
			}			
			tx.commit();
		} catch (Exception e) {
			i=1;
			e.printStackTrace();
		}		
		return i;
	}
	
	
	
	
	
	
	
	
	
	//�����ѯ*****************
	public List<Topic> topfind(int i,int j){
		String hql="from Topic where subid=?";
		Query q=se.createQuery(hql);
		q.setInteger(0, i);
		q.setFirstResult(j);
		q.setMaxResults(5);
		System.out.println(q.list());
		return q.list();
		
	}
	
	
	
	
	
	
	
	//�����ڲ�ѯ�׶�	
	public String fph(int i){
		String hql="select phname from Phase where phid=?";
		Query q=se.createQuery(hql);
		q.setInteger(0, i);
		return (String) q.uniqueResult();
	}
	
	//��ѯ�׶�
	public List<Phase> phfind() {
		String hql="from Phase";
		Query q=se.createQuery(hql);
		return q.list();
	}
	//��ѯ����	
	public List<Direction> dirfind(){
		String hql="from Direction";
		Query q=se.createQuery(hql);
		return q.list();
	}
	//��Ŀ��id
	public List<Object []> subfind(int i) {
		String hql="select s.subname,s.subid,count(t.topid) from Topic t right join t.subject s  where s.direction.dirid=? and s.phase.phid=? group by s.subid,s.subname";
		Query q=se.createQuery(hql);
		q.setInteger(0, 1);
		q.setInteger(1, i);
		System.out.println(q.list().size()+"qqqqqqqqqqqqqqqq");
		return q.list();
	}
	

	
	
	
	public List<bean.Lecturer> Lecturer(bean.Lecturer lect) {
		String hql="from Lecturer where lecname=? and lecpwd=?";
		Query q=se.createQuery(hql);
		q.setString(0, lect.getLecname());
		q.setString(1, lect.getLecpwd());
		return q.list();
	}

	public List<bean.Student> Student(bean.Student stu) {
		String hql="from Student where stuname=? and stupwd=?";
		Query q=se.createQuery(hql);
		q.setString(0, stu.getStuname());
		q.setString(1, stu.getStupwd());
		List list=q.list();
		System.out.println(list.size());
		return list;
	}

	public List<Administrator> administrator(Administrator admin) {
		String hql="from Administrator where admname=? and admpwd=?";
		Query q=se.createQuery(hql);
		q.setString(0, admin.getAdmname());
		q.setString(1, admin.getAdmpwd());
		return q.list();
	}

	

	
}
