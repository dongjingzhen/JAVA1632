package com;

import java.util.List;

import bean.Clas;
import bean.Shijuanbanji;
import kaoshi.Kaoshi;

public class KaoshiAction {
	Kaoshi ks=new Kaoshi();
	private List<Clas> clas;//�༶
	
	private List<Shijuanbanji> sjbjlist;
	
	private int [] canjiabanjiid;//��ʼ���԰༶��id
	
	private static int shijuanid;//�����ʼ���Դ��������Ծ�id
	
	private String kaishishijian;//��ʼʱ��
	
	private static int sueshengid;//�����ѧ���༶id
	
	
	//�Ծ��༶
	public String sjbj(){
		System.out.println(sueshengid+"xxxx");
		sjbjlist=ks.xueshengxianshi(sueshengid);
		return "sjbj";
	}
	
	
	//�����ʼ���԰�ť���Ծ��༶����������
	public String addshijuanbanji(){
		System.out.println("jinru");
		System.out.println(kaishishijian);
		System.out.println(shijuanid);
		ks.starexam(canjiabanjiid, shijuanid,kaishishijian);
		
		return "addsjbj";
	}
	
	
	//�����ʼ����ҳ����Կ��԰༶�б�
	public String clasfind(){
		clas=ks.clasfind();
		return "clas";
	}
	
	
	
	
	
	
	
	public List<Clas> getClas() {
		return clas;
	}
	public void setClas(List<Clas> clas) {
		this.clas = clas;
	}


	public int[] getCanjiabanjiid() {
		return canjiabanjiid;
	}


	public void setCanjiabanjiid(int[] canjiabanjiid) {
		this.canjiabanjiid = canjiabanjiid;
	}


	public int getShijuanid() {
		return shijuanid;
	}


	public void setShijuanid(int shijuanid) {
		this.shijuanid = shijuanid;
	}


	public String getKaishishijian() {
		return kaishishijian;
	}


	public void setKaishishijian(String kaishishijian) {
		this.kaishishijian = kaishishijian;
	}


	public List<Shijuanbanji> getSjbjlist() {
		return sjbjlist;
	}


	public void setSjbjlist(List<Shijuanbanji> sjbjlist) {
		this.sjbjlist = sjbjlist;
	}


	public int getSueshengid() {
		return sueshengid;
	}


	public void setSueshengid(int sueshengid) {
		this.sueshengid = sueshengid;
	}
	
	


	
	
	
	
	

}
