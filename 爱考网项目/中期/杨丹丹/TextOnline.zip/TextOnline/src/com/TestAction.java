package com;

import java.util.List;

import com.opensymphony.xwork2.ModelDriven;

import bean.Direction;
import bean.Phase;
import bean.Subject;
import bean.Topic;
import biz.impl.Loginbizimpl;

public class TestAction {
	
	static int j=0;
	
	Loginbizimpl lbi=new Loginbizimpl();
	List<Object[]> listsub;//��Ŀ
	List<Direction> listdir;//����
	List<Phase> listph;//�׶�
	List<Topic> listtop;//����
	List<Topic> upsellist;//�޸Ĳ�ѯ����
	private String jieduan;//����׶�
	private Phase p=new Phase();//�׶�ʵ����
	private int kemuid;
	private Topic topic;
	private int kid;//��ת��������ҳ��ʱ����Ŀ�Ŀid   ������������
	private int kuid;//��һҳ��һҳʱ�����id
	private int zongshu;
	private int upid;//�޸�ʱ��������id
	static int k=0;
	static int zs;
	private int deid;
	
	
	//ɾ������
	public String del(){
		System.out.println(deid+"ddddddddddddddddddddddd");
		int j=lbi.dele(deid);
		if(j==0){
			return "dele";
		}else{
			return "sb";
		}
		
	}
	
	//�޸������ѯ
	public String upsel(){
		upsellist=lbi.upsel(upid);
		System.out.println(upsellist.size());
		return "upsel";
	}
	
	//��ҳ
	public String xia(){
		System.out.println("zssszsss"+zs);
		j=j+5;
		if(j>zs){
			j=j-5;
		}
		listtop=lbi.topfind(k ,j);
		return "jia";
	}
	public String shang(){		
		j=j-5;
		if(j<0){
			j=j+5;
		}
		System.out.println(j);
		listtop=lbi.topfind(k ,j);
		return "jian";
	}
	
	
	//��ת��������ҳ��
	public String shitiyemian(){
		
		return "stym";
	}
	
	//��������
	public String addtop(){
		int in=lbi.addtop(topic);		
		return "to";
	}	
	//�����ѯ
	public String topfind(){
		zs=zongshu;		
		k=kemuid;
		listtop=lbi.topfind(k ,j);
		return "topp";
	}
	
	
	//��Ŀ��ѯ ����ѯ���򡢲�ѯ�׶�
	public String findsub2(){
		//�׶�
		listph=lbi.phfind();
		//����
		listdir=lbi.dirfind();
		//��Ŀ		
		listsub=lbi.subfind(p.getPhid());		
		//����׶�
		jieduan=lbi.fph(p.getPhid());		
		return "sub";
		
	}
	
	//��Ŀ��ѯ ����ѯ���򡢲�ѯ�׶�
	public String findsub(){
		//�׶�
		listph=lbi.phfind();
		//����
		listdir=lbi.dirfind();
		
		//��Ŀ		
		listsub=lbi.subfind(1);	
		for (Object[] obj : listsub) {
			System.out.println(obj[0]+"---"+obj[1]);
		}
		
		
		
		//����׶�
		jieduan=lbi.fph(1);
		return "sub";
	}
	
	public List<Direction> getListdir() {
		return listdir;
	}
	public void setListdir(List<Direction> listdir) {
		this.listdir = listdir;
	}
	public List<Phase> getListph() {
		return listph;
	}
	public void setListph(List<Phase> listph) {
		this.listph = listph;
	}

	public Phase getP() {
		return p;
	}

	public void setP(Phase p) {
		this.p = p;
	}

	public String getJieduan() {
		return jieduan;
	}

	public void setJieduan(String jieduan) {
		this.jieduan = jieduan;
	}

	public List<Object[]> getListsub() {
		return listsub;
	}

	public void setListsub(List<Object[]> listsub) {
		this.listsub = listsub;
	}


	public int getKemuid() {
		return kemuid;
	}


	public void setKemuid(int kemuid) {
		this.kemuid = kemuid;
	}


	public List<Topic> getListtop() {
		return listtop;
	}


	public void setListtop(List<Topic> listtop) {
		this.listtop = listtop;
	}


	public Topic getTopic() {
		return topic;
	}


	public void setTopic(Topic topic) {
		this.topic = topic;
	}

	public int getKid() {
		return kid;
	}

	public void setKid(int kid) {
		this.kid = kid;
	}
	public int getKuid() {
		return kuid;
	}
	public void setKuid(int kuid) {
		this.kuid = kuid;
	}
	public int getZongshu() {
		return zongshu;
	}
	public void setZongshu(int zongshu) {
		this.zongshu = zongshu;
	}

	public List<Topic> getUpsellist() {
		return upsellist;
	}

	public void setUpsellist(List<Topic> upsellist) {
		this.upsellist = upsellist;
	}

	public int getUpid() {
		return upid;
	}

	public void setUpid(int upid) {
		this.upid = upid;
	}

	public int getDeid() {
		return deid;
	}

	public void setDeid(int deid) {
		this.deid = deid;
	}
	
	







	
	

}
