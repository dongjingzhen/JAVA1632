package com;

import java.util.List;
import java.util.Map;

import com.opensymphony.xwork2.ActionContext;

import bean.Administrator;
import bean.Lecturer;
import bean.Student;
import biz.impl.Loginbizimpl;

public class LoginAction {
	private String name;
	private String pwd;
	private int nam;
	private List<Lecturer> lect;
	private List<Administrator> admin;
	private List<Student> stu;
	private Administrator administrator=new Administrator();
	private Lecturer lecturer =new Lecturer();
	private Student student;
	Loginbizimpl lbi=new Loginbizimpl(); 
	//��½��ѯ
	public String loginfind(){
		if(nam==1){
			Map<String, Object> map=(Map<String, Object>) ActionContext.getContext().getSession();
			map.put("nam", nam);
			student=new Student();
			student.setStuname(name);
			student.setStupwd(pwd);
			stu=lbi.Student(student);
			map.put("banjiid", stu.get(0).getClas().getClid());
			System.out.println(stu.get(0).getClas().getClid()+"iiiiiiiiiiiiiiii");
			if(stu.size()!=0){
				return "index";
			}else{
				return "sb";
			}			
		}else if(nam==2){
			Map<String, Object> map=(Map<String, Object>) ActionContext.getContext().getSession();
			map.put("nam", nam);
			lecturer.setLecname(name);
			lecturer.setLecpwd(pwd);
			lect=lbi.Lecturer(lecturer);
			if(lect.size()!=0){
				return "index";
			}else{
				return "sb";
			}			
		}else if(nam==4){
			Map<String, Object> map=(Map<String, Object>) ActionContext.getContext().getSession();
			map.put("nam", nam);
			administrator.setAdmname(name);
			administrator.setAdmpwd(pwd);
			admin=lbi.administrator(administrator);
			if(admin.size()!=0){
				return "index";
			}else{
				return "sb";
			}			
		}
		return null;
				
	}
	public int getNam() {
		return nam;
	}
	public void setNam(int nam) {
		this.nam = nam;
	}
	public List<Lecturer> getLect() {
		return lect;
	}
	public void setLect(List<Lecturer> lect) {
		this.lect = lect;
	}
	public List<Administrator> getAdmin() {
		return admin;
	}
	public void setAdmin(List<Administrator> admin) {
		this.admin = admin;
	}
	public List<Student> getStu() {
		return stu;
	}
	public void setStu(List<Student> stu) {
		this.stu = stu;
	}
	public Administrator getAdministrator() {
		return administrator;
	}
	public void setAdministrator(Administrator administrator) {
		this.administrator = administrator;
	}
	public Lecturer getLecturer() {
		return lecturer;
	}
	public void setLecturer(Lecturer lecturer) {
		this.lecturer = lecturer;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
	

}
