package com;

import java.util.List;

import org.hibernate.tuple.Tuplizer;

import suijishu.Bbb;

import bean.Cunti;
import bean.Direction;
import bean.Paper;
import bean.Phase;
import bean.Topic;
import biz.impl.Loginbizimpl;

public class ShiJuanAction {
	Loginbizimpl lib=new Loginbizimpl();
	Bbb bbb=new Bbb();
	List<Object[]> listsub;//��Ŀ
	List<Direction> listdir;//����
	List<Phase> listph;//�׶�
	List<Topic> listshijuantiku;
	List<Topic> xianshishijuan;
	List<Topic> topid;
	List<Paper> pap;
	List<Cunti> cuntilist;
	List<Topic> chakanshitilist;//�鿴����
	private String jieduan;//�׶�
	private Phase phase;
	private Integer dianjixialakuangkemuid;
	static int djxlkxsid=1;
	static int zy=1;
	static Integer[] idd ;
	private static int tishu;
	private static int fenshu;
	private int[] xuanzhongti;
	
	private int suijigeshu;//���ѡ��ĸ���
	
	private String biaoti;
	private String zhuangtai;
	private int shijian;
	
	static String sjjd="";//�Ծ���ʾ�Ľ׶�
	static String sjkm="";//�Ծ���ʾ�Ŀ�Ŀ	
	private Paper paper;
	private int [] suijishu;
	
	private int shijuanid;//�鿴�Ծ�ʱ������Ծ�id
	private int []dedaotopid; //�ڴ�����л�����id��
	
	//�Ծ�ҳ��ĵ���鿴�Ծ�
	public String chakanshijuan(){
		System.out.println(shijuanid);
		cuntilist=lib.chakanshijuan(shijuanid);
		System.out.println(cuntilist.size()+"ccc");
		System.out.println("��Action");
		dedaotopid=new int[cuntilist.size()];
		for (int i = 0; i < cuntilist.size(); i++) {
			System.out.println("��ѭ��");
			dedaotopid[i]=cuntilist.get(i).getTopic().getTopid();
		}
		chakanshitilist=lib.ckshijuan(dedaotopid);
		
		return "cksj";
	}
	
	
	//������
	public String suijizujuan(){
		System.out.println("sssssssssssssssssssssssssssss"+suijigeshu);
		topid=lib.suijiidfind();
		idd=new Integer[topid.size()];
		for (int i = 0; i < topid.size(); i++) {		
			Object obj=topid.get(i);
			idd[i]=Integer.parseInt(String.valueOf(obj));
		}
		//�����
		int sjs[]=bbb.random(1, topid.size(), suijigeshu);
		suijishu=new int[suijigeshu];
		for (int i = 0; i < sjs.length; i++) {
			System.out.println(sjs[i]+"11111111111");
			suijishu[i]=sjs[i];
		}
		//������id	
		xuanzhongti=new int [suijigeshu];
		for (int i = 0; i < suijishu.length; i++) {
			xuanzhongti[i]=idd[i];
		}
		
		//�����ѡ�е�id��ֵ��ѡ�е���
		
		for (int i = 0; i < xuanzhongti.length; i++) {
			System.out.println(xuanzhongti[i]);
		}
		//ִ�����ӷ�����ѡ������ǻ����Ŀid   ��������������id��
		System.out.println("�˷���������");
		int x=lib.tianjiashijuan(xuanzhongti,djxlkxsid,biaoti,"δ����",shijian,tishu,fenshu);
		System.out.println(x);
		
		return "suiji";
	}
	
	
	
	//��ѯ�Ծ�	
	public void shijuanfind(){
		pap=lib.shijuanfind();
		System.out.println(pap.size()+"ppppppppppppppppppppppppppppppppppppppppp");
	}
	
	//��ʾ�Ծ�
	public String xianshishijuan(){
		for (int i = 0; i < xuanzhongti.length; i++) {
			System.out.println(xuanzhongti[i]);
			xianshishijuan=lib.shijuantikufind(xuanzhongti[i]);
		}		
		
		return "xssj";		
	}
	
	
	//ѡ�е���
	public String xuanzhongdeti(){
		System.out.println(dianjixialakuangkemuid);
		lib.tianjiashijuan(xuanzhongti,djxlkxsid,biaoti,"δ����",shijian,tishu,fenshu);
		return "xzdt";
	}
	
	
	//ѡ�������ʾ�ϱ�������
	public String xianshixialakuang(){
		listdir=lib.dirfind();//����
		listph=lib.phfind();//�׶�
		//��Ŀ		
		listsub=lib.subfind(zy);		
		for (Object[] obj : listsub) {
			System.out.println(obj[0]+"---"+obj[1]);
		}		
		//����׶�
		jieduan=lib.fph(zy);
		listshijuantiku=lib.shijuantikufind(1);	
		
		return "xsxlk";
	}
	
	
	public String suijixianshixialakuang(){
		listdir=lib.dirfind();//����
		listph=lib.phfind();//�׶�
		
		try {
			zy=phase.getPhid();
			System.out.println(zy+"zzzzzzzzzzzzzzzyyyyyyyyyyyyy");
			listsub=lib.subfind(zy);		
			for (Object[] obj : listsub) {
				System.out.println(obj[0]+"---"+obj[1]);
			}		
			//����׶�
			jieduan=lib.fph(zy);
			listshijuantiku=lib.shijuantikufind(1);	
		} catch (Exception e) {
			// TODO: handle exception
			//��Ŀ		
			listsub=lib.subfind(zy);		
			for (Object[] obj : listsub) {
				System.out.println(obj[0]+"---"+obj[1]);
			}		
			//����׶�
			jieduan=lib.fph(zy);
			listshijuantiku=lib.shijuantikufind(1);	
			
			
		}
		return "suijixsxlk";
		
		
	}
	
	
	
	
	public String xianshixialakuang2(){
		System.out.println(dianjixialakuangkemuid+"--------------------------");
		djxlkxsid=dianjixialakuangkemuid;
		System.out.println(djxlkxsid+"yyyyyyyyyyyyyyyy");
		try {
			zy=phase.getPhid();
		} catch (Exception e) {
			zy=1;
		}			
		listdir=lib.dirfind();//����
		listph=lib.phfind();//�׶�
		//��Ŀ		
		listsub=lib.subfind(zy);	
		System.out.println(zy);
		jieduan=lib.fph(zy);
		listshijuantiku=lib.shijuantikufind(djxlkxsid);
		return "xsxlk";
	}
	
	
	
	
	
	public String xianshi(){
		listdir=lib.dirfind();//����
		listph=lib.phfind();//�׶�
		//��Ŀ		
		listsub=lib.subfind(1);	
		
		for (Object[] obj : listsub) {
			System.out.println(obj[0]+"---"+obj[1]);
		}		
		//����׶�
		jieduan=lib.fph(1);
		
		//��ʾ�Ѿ��е��Ծ�
		shijuanfind();
		return "xianshi";
	}
	
	public String xianshi2(){
		listdir=lib.dirfind();//����
		listph=lib.phfind();//�׶�
		//��Ŀ		
		listsub=lib.subfind(phase.getPhid());	
		System.out.println(phase.getPhid());
		jieduan=lib.fph(phase.getPhid());	
		return "xianshi";
	}
	
	
	

	public List<Object[]> getListsub() {
		return listsub;
	}

	public void setListsub(List<Object[]> listsub) {
		this.listsub = listsub;
	}

	public List<Direction> getListdir() {
		return listdir;
	}

	public void setListdir(List<Direction> listdir) {
		this.listdir = listdir;
	}

	public List<Phase> getListph() {
		return listph;
	}

	public void setListph(List<Phase> listph) {
		this.listph = listph;
	}

	public Phase getPhase() {
		return phase;
	}

	public void setPhase(Phase phase) {
		this.phase = phase;
	}

	public String getJieduan() {
		return jieduan;
	}

	public void setJieduan(String jieduan) {
		this.jieduan = jieduan;
	}

	

	public static int getDjxlkxsid() {
		return djxlkxsid;
	}


	public static void setDjxlkxsid(int djxlkxsid) {
		ShiJuanAction.djxlkxsid = djxlkxsid;
	}


	public List<Topic> getListshijuantiku() {
		return listshijuantiku;
	}

	public void setListshijuantiku(List<Topic> listshijuantiku) {
		this.listshijuantiku = listshijuantiku;
	}


	public int[] getXuanzhongti() {
		return xuanzhongti;
	}


	public void setXuanzhongti(int[] xuanzhongti) {
		this.xuanzhongti = xuanzhongti;
	}


	public List<Topic> getXianshishijuan() {
		return xianshishijuan;
	}


	public void setXianshishijuan(List<Topic> xianshishijuan) {
		this.xianshishijuan = xianshishijuan;
	}


	public Paper getPaper() {
		return paper;
	}


	public void setPaper(Paper paper) {
		this.paper = paper;
	}


	public Integer getDianjixialakuangkemuid() {
		return dianjixialakuangkemuid;
	}


	public void setDianjixialakuangkemuid(Integer dianjixialakuangkemuid) {
		this.dianjixialakuangkemuid = dianjixialakuangkemuid;
	}

	public List<Paper> getPap() {
		return pap;
	}

	public void setPap(List<Paper> pap) {
		this.pap = pap;
	}

	public String getBiaoti() {
		return biaoti;
	}

	public void setBiaoti(String biaoti) {
		this.biaoti = biaoti;
	}

	public String getZhuangtai() {
		return zhuangtai;
	}

	public void setZhuangtai(String zhuangtai) {
		this.zhuangtai = zhuangtai;
	}

	public int getShijian() {
		return shijian;
	}

	public void setShijian(int shijian) {
		this.shijian = shijian;
	}



	public List<Topic> getTopid() {
		return topid;
	}



	public void setTopid(List<Topic> topid) {
		this.topid = topid;
	}



	public static Integer[] getIdd() {
		return idd;
	}



	public static void setIdd(Integer[] idd) {
		ShiJuanAction.idd = idd;
	}



	public int getSuijigeshu() {
		return suijigeshu;
	}



	public void setSuijigeshu(int suijigeshu) {
		this.suijigeshu = suijigeshu;
	}



	public int[] getSuijishu() {
		return suijishu;
	}



	public void setSuijishu(int[] suijishu) {
		this.suijishu = suijishu;
	}


	public int[] getDedaotopid() {
		return dedaotopid;
	}


	public void setDedaotopid(int[] dedaotopid) {
		this.dedaotopid = dedaotopid;
	}


	public List<Cunti> getCuntilist() {
		return cuntilist;
	}


	public void setCuntilist(List<Cunti> cuntilist) {
		this.cuntilist = cuntilist;
	}


	public int getShijuanid() {
		return shijuanid;
	}


	public void setShijuanid(int shijuanid) {
		this.shijuanid = shijuanid;
	}


	public List<Topic> getChakanshitilist() {
		return chakanshitilist;
	}


	public void setChakanshitilist(List<Topic> chakanshitilist) {
		this.chakanshitilist = chakanshitilist;
	}


	public int getTishu() {
		return tishu;
	}


	public void setTishu(int tishu) {
		this.tishu = tishu;
	}


	public int getFenshu() {
		return fenshu;
	}


	public void setFenshu(int fenshu) {
		this.fenshu = fenshu;
	}
	
	




	
	

}
