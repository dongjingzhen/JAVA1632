package kaoshi;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import dao.HibernateSessionFactory;

import bean.Clas;
import bean.Paper;
import bean.Shijuanbanji;
import bean.Topic;

public class Kaoshi {
	
	Session se=HibernateSessionFactory.getSession();
	
	//ѧ����¼ʱ���߿���ҳ��
	public List<Shijuanbanji> xueshengxianshi(int i){
		String hql="from Shijuanbanji where clid=?";
		Query q=se.createQuery(hql);
		q.setInteger(0, i);
		return q.list();
	}
	
	
	
	//��ѯ�༶
	public List<Clas> clasfind(){
		String hql="from Clas";
		Query q=se.createQuery(hql);
		return q.list();
	}
	
	//��ʼ���ԡ�������>���ӿ����Ծ���
	public int starexam(int x[],int sjid,String shijian){
		Transaction t=null;
		try {
			t=se.getTransaction();
			t.begin();
			Clas c=null;
			String hql="from Clas where clid=?";
			String qq="from Paper where paid="+sjid;
			Query query=se.createQuery(qq);
			Paper p=(Paper)query.list().get(0);
			for (int j = 0; j < x.length; j++) {
				Query q=se.createQuery(hql);
				q.setInteger(0, x[j]);
				c=(Clas)q.uniqueResult();
				System.out.println(c.getClname());
				p.getClasss().add(c);
			}
			 p=(Paper) se.get(Paper.class, sjid);
			p.setKaishishijian(shijian);
			se.saveOrUpdate(p);
			t.commit();
		} catch (Exception e) {
			t.rollback();
			e.printStackTrace();
			// TODO: handle exception
		}
		
		return 0;
		
	}
	public static void main(String[] args) {
		Kaoshi ks=new Kaoshi();
		int x[]={1,2};
		ks.starexam(x, 1,"44");
	}

}
