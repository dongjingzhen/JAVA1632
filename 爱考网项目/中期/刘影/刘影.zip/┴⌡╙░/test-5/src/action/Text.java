package action;



import org.hibernate.Session;
import org.hibernate.Transaction;

import dao.HibernateSessionFactory;
import domain.Admin;
import domain.Question;

public class Text {
	public static void main(String[] args) {
		
			save();
		
 	}
	public static void save()
	{
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		Admin a=new Admin();
		a.setAname("liuying");
		a.setPwd("123");
		session.save(a);
		for (int i = 0; i <10; i++) {
			Question question=new Question();
			question.setAnswer("B");
			question.setContent("��һ����ˮ����");
			question.setOptionA("����");
			question.setOptionB("ƻ��");
			question.setOptionC("����");
			question.setOptionD("����");
			question.setChapter("G1");
			question.setMajor("java");
			question.setDifficulty("��");
			question.setJsbs("����");			
			session.save(question);
		  	
		}
		
		for (int i = 0; i <10; i++) {
			Question question=new Question();
			question.setAnswer("B");
			question.setContent("��ѡ�񣬣���");
			question.setOptionA("m1");
			question.setOptionB("m22");
			question.setOptionC("m3");
			question.setOptionD("m3");
			question.setChapter("G2");
			question.setMajor("java");
			question.setJsbs("������");			
			session.save(question);
		  	
		}

		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
 
    
	
}
