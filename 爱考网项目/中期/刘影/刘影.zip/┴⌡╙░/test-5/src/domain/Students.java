package domain;

public class Students {
	private int sid;
	private String shao;
	private String pwd;
	private String sname;
	private String stelphont;
	private Classes classes;
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getShao() {
		return shao;
	}
	public void setShao(String shao) {
		this.shao = shao;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getStelphont() {
		return stelphont;
	}
	public void setStelphont(String stelphont) {
		this.stelphont = stelphont;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public Classes getClasses() {
		return classes;
	}
	public void setClasses(Classes classes) {
		this.classes = classes;
	}
	

}
