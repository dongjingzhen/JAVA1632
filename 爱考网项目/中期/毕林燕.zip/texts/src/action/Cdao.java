package action;

import org.apache.log4j.chainsaw.Main;
import org.hibernate.Session;
import org.hibernate.Transaction;

import dao.HibernateSessionFactory;
import domain.Admain;
import domain.Classes;
import domain.Paper;
import domain.Question;
import domain.Student;

import domain.Teacher;

public class Cdao {
	public static void main(String[] args) {
		Session session= HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		
		
		
		
		
		Question q=new Question();
		q.setKind("��ѡ");
		q.setContent("1��1���ڼ�");
		q.setSubjectId("JSP");
		q.setAnswer("A");
		q.setType("����");
		q.setObjectA("1");
		q.setObjectB("2");
		q.setObjectC("3");
		q.setObjectD("4");	 
		q.setDifficulty("����");
	
		Question q1=new Question();
		q1.setKind("��ѡ");
		q1.setContent("wwwww");
		q1.setSubjectId("JSP");
		q1.setAnswer("safasfgagsasf");
		q1.setAnswer("A");
		q1.setObjectB("safsdfdg");
		q1.setObjectC("xvfxcb");
		q1.setObjectD("sfds");
		q1.setSubjectId("JSP");
		q1.setType("����");
		q1.setDifficulty("��");
		
		
		
		
		 Admain a=new Admain();
	        a.setMima("admin");
	        a.setZhanghao("123");

			
			Classes class1 = new Classes();                                                                                                                                                                                                                                                                                
			class1.setClassName("1632");

			Student student = new Student();
			student.setUname("tom");
			student.setStupwd("123");
			student.setClasses(class1);

			
			
			 Teacher t=new Teacher();
		        t.setTname("w");
		        t.setPwd("123");
		        t.setClasses(class1);
		        
			Student student1 = new Student();
			student1.setUname("Jack");
			student1.setStupwd("123");
			student1.setClasses(class1);

			class1.getStudentSet().add(student);
			class1.getStudentSet().add(student1);

			session.save(class1);
			session.save(t);
			session.save(a);
		
		    session.save(q);
		    session.save(q1);
	


		transaction.commit();
		HibernateSessionFactory.closeSession();

	}

}
