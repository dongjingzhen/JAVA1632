package action;




import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;





import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;
import domain.Admain;
import domain.Student;
import domain.Teacher;
import domain.User;



public class LoginAction implements Action {
	
	
	
	private Student students;
	private Teacher teachers;
	private Admain admain;
	private User user;



	public Student getStudents() {
		return students;
	}



	public void setStudents(Student students) {
		this.students = students;
	}



	public Teacher getTeachers() {
		return teachers;
	}



	public void setTeachers(Teacher teachers) {
		this.teachers = teachers;
	}



	public Admain getAdmain() {
		return admain;
	}



	public void setAdmain(Admain admain) {
		this.admain = admain;
	}



	public User getUser() {
		return user;
	}



	public void setUser(User user) {
		this.user = user;
	}





	@Override
	public String execute() throws Exception {
		return SUCCESS;
	}
	
		public String login(){
			if (user.getRole().equals("1")){
				Session session = HibernateSessionFactory.getSession();
				Transaction transaction =  session.beginTransaction();
				
				Student students = (Student)session.createCriteria(Student.class)
				.add(Restrictions.eq("uname",user.getName()))
				.add(Restrictions.eq("stupwd",user.getPwd())).uniqueResult();
				if (students!=null) {
					ServletActionContext.getRequest().getSession().setAttribute("massage","ѧ��");
					transaction.commit();
					HibernateSessionFactory.closeSession();
					
					return "index";
				}
				
			}else if (user.getRole().equals("2")) {
				Session session = HibernateSessionFactory.getSession();
				Transaction transaction =  session.beginTransaction();
				
				Teacher teachers = (Teacher)session.createCriteria(Teacher.class)
				.add(Restrictions.eq("tname",user.getName()))
				.add(Restrictions.eq("pwd",user.getPwd())).uniqueResult();
				if (teachers!=null) {
					ServletActionContext.getRequest().getSession().setAttribute("massage", "��ʦ");
					transaction.commit();
					HibernateSessionFactory.closeSession();
					
					return "index";
				}
				
				
				
			}else if (user.getRole().equals("4")) {
				Session session = HibernateSessionFactory.getSession();
				Transaction transaction =  session.beginTransaction();
				
				Admain admain = (Admain)session.createCriteria(Admain.class)
				.add(Restrictions.eq("zhanghao",user.getName()))
				.add(Restrictions.eq("mima",user.getPwd())).uniqueResult();
				if (admain!=null) {
					ServletActionContext.getRequest().getSession().setAttribute("massage","����Ա");
					transaction.commit();
					HibernateSessionFactory.closeSession();
					
					return "index";
				}
			}
			return ERROR;
		}

}
