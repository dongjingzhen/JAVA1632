package domain;

import java.util.HashSet;
import java.util.Set;

public class Question {

	private int qid;
	private String kind;//������ѡ
	private String type;
	private String content;//��Ŀ
	private String objectA;
	private String objectB;
	private String objectC;
	private String objectD;
	private String answer;//��
	private String difficulty;//�Ѷ�
	private String subjectId;//��Ŀ
	private String chapter;//���

	private String stage;

	private String direction;//��������
	
	private Set<Paper> paperSet=new HashSet<Paper>();
	
	
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getStage() {
		return stage;
	}
	public void setStage(String stage) {
		this.stage = stage;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Set<Paper> getPaperSet() {
		return paperSet;
	}
	public void setPaperSet(Set<Paper> paperSet) {
		this.paperSet = paperSet;
	}
	
	
	
	
	public int getQid() {
		return qid;
	}
	public void setQid(int qid) {
		this.qid = qid;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	
	public String getObjectA() {
		return objectA;
	}
	public void setObjectA(String objectA) {
		this.objectA = objectA;
	}
	public String getObjectB() {
		return objectB;
	}
	public void setObjectB(String objectB) {
		this.objectB = objectB;
	}
	public String getObjectC() {
		return objectC;
	}
	public void setObjectC(String objectC) {
		this.objectC = objectC;
	}
	public String getObjectD() {
		return objectD;
	}
	public void setObjectD(String objectD) {
		this.objectD = objectD;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getDifficulty() {
		return difficulty;
	}
	public void setDifficulty(String difficulty) {
		this.difficulty = difficulty;
	}
	public String getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}
	public String getChapter() {
		return chapter;
	}
	public void setChapter(String chapter) {
		this.chapter = chapter;
	}
	
}
