package action;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Restrictions;

import com.opensymphony.xwork2.Action;
import dao.HibernateSessionFactory;
import domain.Admain;
import domain.Classes;
import domain.Questions;
import domain.Students;
import domain.Teachers;
import domain.TestPaper;
import domain.User;
import domain.Temporary;

public class ExamAction implements Action {
	private String classDaima;
	private Classes classes;
	private List list;
	private Students students;
	private Teachers teachers;
	private Admain admain;
	private User user;
	private Questions questions;
	private String subject;
	private String stage;
	private String types;
	private Temporary temporary;
	private TestPaper testPaper;
	private String newtime;
	private Set<TestPaper> paperset = new HashSet<TestPaper>();
	private Set<Questions> questions2 = new HashSet<Questions>();
	
	@SuppressWarnings("unchecked")
	public String exams(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =  session.beginTransaction();
		
		if (ServletActionContext.getRequest().getSession().getAttribute("quelist")==null) {
			testPaper = (TestPaper) session.get(TestPaper.class, testPaper.getTid());
			list = new ArrayList(testPaper.getQuestionsset());
			
			ServletActionContext.getRequest().getSession().setAttribute("quelist", list);
		}else {
			System.out.println("111");
			System.out.println(questions.getQid());
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "exams";
	}
	
	public String updq(){//�޸��Ծ�
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =  session.beginTransaction();
		testPaper = (TestPaper) session.get(TestPaper.class, testPaper.getTid());
		Questions q = (Questions) session.get(Questions.class, temporary.getQid());
		questions = (Questions) session.get(Questions.class, questions.getQid());
		testPaper.getQuestionsset().remove(q);
		testPaper.getQuestionsset().add(questions);
		session.flush();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "over";
	}
	public String updque(){//�޸��Ծ�����
		
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =  session.beginTransaction();
		
		list = session.createCriteria(Questions.class)
				.add(Restrictions.eq("types",questions.getTypes()))
				.add(Restrictions.eq("direction",questions.getDirection()))
				.add(Restrictions.eq("stage",questions.getStage()))
				.add(Restrictions.eq("subject",questions.getSubject())).list();
		for (int i = 0; i<list.size();i++) {
			System.out.println(list.get(i));
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		return "updque";
	}
	@SuppressWarnings("unchecked")
	public String listpaper(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =  session.beginTransaction();
		TestPaper testPaper1 = (TestPaper) session.get(TestPaper.class, testPaper.getTid());
		questions2 = testPaper1.getQuestionsset();
		
		list = new ArrayList(questions2);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "listpaper";
	}
	public String online(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =  session.beginTransaction();
		
		Students students1 = (Students) ServletActionContext.getRequest().getSession().getAttribute("adm");
		
		paperset = students1.getClasses().getPapers();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "online";
	}
	public String paepare() throws ParseException{//׼������
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =  session.beginTransaction();
		String classNo = "";
		String [] strings = classDaima.split(",");
		for (String string : strings) {
			System.out.println(string.trim());
			if (!(string.trim()).equals("��ѡ��")) {
				classNo = string.trim();
				classes =(Classes) session.createCriteria(Classes.class)
					.add(Restrictions.eq("classDaima",string.trim())).uniqueResult();
			}
		}
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String times = "";
		String [] time = newtime.split(",");
		for (String string : time) {
			System.out.println(string.trim());
			if (!(string.trim()).equals("")) {
				times = string.trim();
			}
		}
		
		Date date;
	
		date = format.parse(times);
		
		testPaper = (TestPaper)session.get(TestPaper.class, testPaper.getTid());
		
		testPaper.setState("׼������");
		testPaper.setClassse(classNo);
		testPaper.setNewtime(date);
		
		testPaper.getClassset().add(classes);
		
		session.save(testPaper);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "over";
	}
	
	public String boadring(){//��ʼ����
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =  session.beginTransaction();
		
		list = session.createCriteria(Classes.class).list();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "boadring";
	}
	public String delpaper(){//ɾ���Ծ�
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =  session.beginTransaction();
		
		testPaper =  (TestPaper) session.get(TestPaper.class,testPaper.getTid());
		
		System.out.println(testPaper.getHours());
		
		session.delete(testPaper);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "over";
	}
	
	public String addpaper(){//�����Ծ�
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =  session.beginTransaction();
		System.out.println(temporary.getDirection());
		String sql = "select qid from (" +
				" select top "+temporary.getNum1()+" qid from questionS where difficulty= '��' and types=:types and mr='��ѡ'and subject=:subject and direction=:direction and stage=:stage order by newId()" +
				" union " +
				" select top "+temporary.getNum2()+" qid from questionS where difficulty= 'һ��' and types=:types and mr='��ѡ'and subject=:subject and direction=:direction and stage=:stage  order by newId()" +
				" union" +
				" select top "+temporary.getNum3()+" qid from questionS where difficulty= '����' and types=:types and mr='��ѡ'and subject=:subject and direction=:direction and stage=:stage  order by newId()" +
				" union" +
				" select top "+temporary.getNum4()+" qid from questionS where difficulty= '��' and types=:types and mr='��ѡ'and subject=:subject and direction=:direction and stage=:stage order by newId()" +
				" union" +
				" select top "+temporary.getNum5()+" qid from questionS where difficulty= 'һ��' and types=:types and mr='��ѡ'and subject=:subject and direction=:direction and stage=:stage  order by newId()" +
				" union" +
				" select top "+temporary.getNum6()+" qid from questionS where difficulty= '����' and types=:types and mr='��ѡ'and subject=:subject and direction=:direction and stage=:stage  order by newId()" +
				") as t";
		list = session.createSQLQuery(sql)
			.setParameter("direction",temporary.getDirection())
			.setParameter("subject",temporary.getSubject())
			.setParameter("stage",temporary.getStage())
			.setParameter("types",temporary.getTypes())
			.list();
		if (list.size()==0) {
			return ERROR;
		}
		testPaper.setTypes(temporary.getTypes());
		testPaper.setState("δ����");
		testPaper.setSubject(temporary.getSubject()+","+temporary.getStage()+","+temporary.getDirection());
		for (int i = 0; i < list.size(); i++) {
			questions =  (Questions) session.get(Questions.class,Integer.parseInt(list.get(i).toString()));
			testPaper.getQuestionsset().add(questions);
		}
		System.out.println(temporary.getNum1()+","+temporary.getSubject()+","+temporary.getStage()+","+temporary.getTypes());
		session.save(testPaper);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "over";
	}
	
	public String showaddpaper(){//��ʾ�����Ծ�����
		return "showaddpaper";
	}
	
	public String showpaper(){//�Ծ���Ϣ
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =  session.beginTransaction();
			
		list = session.createCriteria(TestPaper.class).list();

		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		return "showpaper";
	}
	public String addque(){//��������
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =  session.beginTransaction();
		
		session.save(questions);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return SUCCESS;
	}
	public String showaddque(){//�����������
		subject = ServletActionContext.getRequest().getParameter("subject");
		stage = ServletActionContext.getRequest().getParameter("stage");
		types = ServletActionContext.getRequest().getParameter("types");
		return "showaddque";
	}
	public String listque(){//��������
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =  session.beginTransaction();
		subject = ServletActionContext.getRequest().getParameter("subject");
		stage = ServletActionContext.getRequest().getParameter("stage");
		types = ServletActionContext.getRequest().getParameter("types");
		Criteria criteria =session.createCriteria(Questions.class)
			.add(Restrictions.eq("subject",subject))
			.add(Restrictions.eq("stage",stage))
			.add(Restrictions.eq("types",types));
		list = criteria.list();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "listque";
	}
	public String login(){//��¼
		if (user.getRole().equals("1")){
			Session session = HibernateSessionFactory.getSession();
			Transaction transaction =  session.beginTransaction();
			
			Students students = (Students)session.createCriteria(Students.class)
			.add(Restrictions.eq("xueHao",user.getName()))
			.add(Restrictions.eq("pwd",user.getPwd())).uniqueResult();
			if (students!=null) {
				ServletActionContext.getRequest().getSession().setAttribute("adm",students);
				ServletActionContext.getRequest().getSession().setAttribute("massage","ѧ��");
				transaction.commit();
				HibernateSessionFactory.closeSession();
				
				return "login";
			}
			
		}else if (user.getRole().equals("2")) {
			Session session = HibernateSessionFactory.getSession();
			Transaction transaction =  session.beginTransaction();
			
			Teachers teachers = (Teachers)session.createCriteria(Teachers.class)
			.add(Restrictions.eq("zhanghao",user.getName()))
			.add(Restrictions.eq("pwd",user.getPwd())).uniqueResult();
			if (teachers!=null) {
				ServletActionContext.getRequest().getSession().setAttribute("adm",teachers);
				ServletActionContext.getRequest().getSession().setAttribute("massage", "��ʦ");
				transaction.commit();
				HibernateSessionFactory.closeSession();
				
				return "login";
			}
			
			
		}else if (user.getRole().equals("4")) {
			Session session = HibernateSessionFactory.getSession();
			Transaction transaction =  session.beginTransaction();
			
			Admain admain = (Admain)session.createCriteria(Admain.class)
			.add(Restrictions.eq("zhanghao",user.getName()))
			.add(Restrictions.eq("mima",user.getPwd())).uniqueResult();
			if (admain!=null) {
				ServletActionContext.getRequest().getSession().setAttribute("adm",admain);
				ServletActionContext.getRequest().getSession().setAttribute("massage","����Ա");
				transaction.commit();
				HibernateSessionFactory.closeSession();
				
				return "login";
			}
		}
		return "log";
	}
	
	public String questions(){//�����ҳ
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =  session.beginTransaction();
		String sql = "select types,stage,subject,count(types) as typeSize " +
				"from questions " +
				"group by " +
				"subject,stage,types";
		list =  session.createSQLQuery(sql).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "questions";
	}
	
	public String logout(){//ע��
		ServletActionContext.getRequest().getSession().invalidate();
		return "logout";
	}
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Students getStudents() {
		return students;
	}
	public void setStudents(Students students) {
		this.students = students;
	}
	public Teachers getTeachers() {
		return teachers;
	}
	public void setTeachers(Teachers teachers) {
		this.teachers = teachers;
	}
	public Admain getAdmain() {
		return admain;
	}
	public void setAdmain(Admain admain) {
		this.admain = admain;
	}

	public Questions getQuestions() {
		return questions;
	}

	public void setQuestions(Questions questions) {
		this.questions = questions;
	}
	
	public Temporary getTemporary() {
		return temporary;
	}

	public void setTemporary(Temporary temporary) {
		this.temporary = temporary;
	}

	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getStage() {
		return stage;
	}

	public void setStage(String stage) {
		this.stage = stage;
	}

	public String getTypes() {
		return types;
	}

	public void setTypes(String types) {
		this.types = types;
	}

	public TestPaper getTestPaper() {
		return testPaper;
	}

	public void setTestPaper(TestPaper testPaper) {
		this.testPaper = testPaper;
	}
	public Classes getClasses() {
		return classes;
	}
	public void setClasses(Classes classes) {
		this.classes = classes;
	}

	public String getClassDaima() {
		return classDaima;
	}

	public void setClassDaima(String classDaima) {
		this.classDaima = classDaima;
	}

	public String getNewtime() {
		return newtime;
	}
	public void setNewtime(String newtime) {
		this.newtime = newtime;
	}
	public Set<TestPaper> getPaperset() {
		return paperset;
	}
	public void setPaperset(Set<TestPaper> paperset) {
		this.paperset = paperset;
	}
	public Set<Questions> getQuestions2() {
		return questions2;
	}
	public void setQuestions2(Set<Questions> questions2) {
		this.questions2 = questions2;
	}

}
