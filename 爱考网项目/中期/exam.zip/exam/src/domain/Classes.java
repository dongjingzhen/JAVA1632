package domain;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Classes {
	
	private int id;
	private String classDaima; //�༶����
	private String className;  //�༶����
	private String fangxiang;  //��������
	private Teachers teachers;//��ʦ
	private Teachers tea;//ѧ��
	private Date begainDate;  //��������
	private String zhuangTai; //״̬
	private String beizhu;
	private Set<Students> studentSet = new HashSet<Students>();  //����ѧ��
	private Set<TestPaper> papers = new HashSet<TestPaper>();
	
	public Set<TestPaper> getPapers() {
		return papers;
	}
	public void setPapers(Set<TestPaper> papers) {
		this.papers = papers;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getClassDaima() {
		return classDaima;
	}
	public void setClassDaima(String classDaima) {
		this.classDaima = classDaima;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getFangxiang() {
		return fangxiang;
	}
	public void setFangxiang(String fangxiang) {
		this.fangxiang = fangxiang;
	}
	
	public Teachers getTeachers() {
		return teachers;
	}
	public void setTeachers(Teachers teachers) {
		this.teachers = teachers;
	}
	public Teachers getTea() {
		return tea;
	}
	public void setTea(Teachers tea) {
		this.tea = tea;
	}
	public Date getBegainDate() {
		return begainDate;
	}
	public void setBegainDate(Date begainDate) {
		this.begainDate = begainDate;
	}
	public String getZhuangTai() {
		return zhuangTai;
	}
	public void setZhuangTai(String zhuangTai) {
		this.zhuangTai = zhuangTai;
	}
	public String getBeizhu() {
		return beizhu;
	}
	public void setBeizhu(String beizhu) {
		this.beizhu = beizhu;
	}
	public Set<Students> getStudentSet() {
		return studentSet;
	}
	public void setStudentSet(Set<Students> studentSet) {
		this.studentSet = studentSet;
	}
	
}
 