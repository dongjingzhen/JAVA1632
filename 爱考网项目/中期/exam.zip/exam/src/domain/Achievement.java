package domain;

public class Achievement {
	private int aid;
	private Students students;
	private TestPaper testPaper;
	private Classes classes;
	
}
