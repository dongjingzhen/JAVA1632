package domain;

import java.util.HashSet;
import java.util.Set;

public class Teachers {
	
	private int id;
	private String zhanghao; //�˺�
	private String pwd;  //����
	private String name;  //����
	private String sex;  //�Ա�
	private String birthday; //����
	private String xueli;// ѧ��
	private String telephone; //��ϵ�绰
	private String gangwei; //��λ
	private String beizhu;  //��ע
	private Set<Classes> classes = new HashSet<Classes>();
	private Set<Classes> classset = new HashSet<Classes>();
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getZhanghao() {
		return zhanghao;
	}
	public void setZhanghao(String zhanghao) {
		this.zhanghao = zhanghao;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getXueli() {
		return xueli;
	}
	public void setXueli(String xueli) {
		this.xueli = xueli;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getGangwei() {
		return gangwei;
	}
	public void setGangwei(String gangwei) {
		this.gangwei = gangwei;
	}
	public String getBeizhu() {
		return beizhu;
	}
	public void setBeizhu(String beizhu) {
		this.beizhu = beizhu;
	}
	public Set<Classes> getClasses() {
		return classes;
	}
	public void setClasses(Set<Classes> classes) {
		this.classes = classes;
	}
	public Set<Classes> getClassset() {
		return classset;
	}
	public void setClassset(Set<Classes> classset) {
		this.classset = classset;
	}
	
}
