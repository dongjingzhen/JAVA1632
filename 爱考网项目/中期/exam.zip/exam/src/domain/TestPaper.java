package domain;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class TestPaper {
	private int tid;
	private Date newtime;//����ʱ��
	private int hours;//����ʱ��
	private String classse;//���԰༶
	private Set<Classes> classset = new HashSet<Classes>();//���԰༶
	private Set<Questions> questionsset = new HashSet<Questions>();//�Ծ�����
	private Set<Students> students = new HashSet<Students>();
	private String title;//����
	private int average;//ÿ�����
	private String types; //����or����
	private String subject;//��Ŀ
	private String state;//״̬
	private int coun;//������
	private int countage;//�ܷ���
	
	public Set<Students> getStudents() {
		return students;
	}
	public void setStudents(Set<Students> students) {
		this.students = students;
	}
	public String getClassse() {
		return classse;
	}
	public void setClassse(String classse) {
		this.classse = classse;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getCoun() {
		return coun;
	}
	public void setCoun(int coun) {
		this.coun = coun;
	}
	public int getCountage() {
		return countage;
	}
	public void setCountage(int countage) {
		this.countage = countage;
	}
	public String getTypes() {
		return types;
	}
	public void setTypes(String types) {
		this.types = types;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public Date getNewtime() {
		return newtime;
	}
	public void setNewtime(Date newtime) {
		this.newtime = newtime;
	}
	public int getHours() {
		return hours;
	}
	public void setHours(int hours) {
		this.hours = hours;
	}
	public Set<Classes> getClassset() {
		return classset;
	}
	public void setClassset(Set<Classes> classset) {
		this.classset = classset;
	}
	public Set<Questions> getQuestionsset() {
		return questionsset;
	}
	public void setQuestionsset(Set<Questions> questionsset) {
		this.questionsset = questionsset;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getAverage() {
		return average;
	}
	public void setAverage(int average) {
		this.average = average;
	}
	
}
