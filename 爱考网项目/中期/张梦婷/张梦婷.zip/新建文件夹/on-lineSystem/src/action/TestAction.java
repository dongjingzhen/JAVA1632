package action;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.dao.HibernateSessionFactory;
import com.domain.Admin;
import com.domain.Paper;
import com.domain.Question;
import com.domain.Students;
import com.domain.Teacher;
import com.domain.Temporary;
import com.domain.Users;
import com.opensymphony.xwork2.Action;




public class TestAction implements Action {
	private Users user;
	private Students stu;
	private Teacher tea;
	private Admin admin;
	private int qid;
	private int pid;
	private Question question;
	private List<Object[]> qbList = new ArrayList<Object[]>();
	private List<Question> quesList = new ArrayList<Question>();
	private List<Paper> paperList=new ArrayList<Paper>();//����Ծ�
	private Temporary temporary;
	private Paper paper;

	public String admain(){
		//�ж�����Ϊѧ��
		if (user.getRole().equals("1")) {
			Session session = HibernateSessionFactory.getSession();
			Transaction transaction = session.beginTransaction();
			
			Students stu = (Students)session.createCriteria(Students.class)
							.add(Restrictions.eq("xueHao",user.getAccount()))
							.add(Restrictions.eq("pwd", user.getPassword())).uniqueResult();
			if(stu != null){
				ServletActionContext.getRequest().getSession().setAttribute("massage", "ѧ��");
				transaction.commit();
				HibernateSessionFactory.closeSession();
				return SUCCESS;
			}

		}else if (user.getRole().equals("2")) {//�ж�����Ϊ��ʦ
			Session session = HibernateSessionFactory.getSession();
			Transaction transaction = session.beginTransaction();
			
			Teacher tea = (Teacher)session.createCriteria(Teacher.class)
						.add(Restrictions.eq("taccount",user.getAccount()))
						.add(Restrictions.eq("tpwd", user.getPassword())).uniqueResult();
			if(tea != null){
				ServletActionContext.getRequest().getSession().setAttribute("massage", "��ʦ");
				transaction.commit();
				HibernateSessionFactory.closeSession();
				return SUCCESS;
			}
			
		}else if (user.getRole().equals("4")) {//�ж�����Ϊ����Ա
			Session session = HibernateSessionFactory.getSession();
			Transaction transaction = session.beginTransaction();
			
			Admin admin = (Admin)session.createCriteria(Admin.class)
						.add(Restrictions.eq("name",user.getAccount()))
						.add(Restrictions.eq("pwd", user.getPassword())).uniqueResult();
			if(admin != null){
				ServletActionContext.getRequest().getSession().setAttribute("massage", "����Ա");
				transaction.commit();
				HibernateSessionFactory.closeSession();
				return SUCCESS;
			}
			
		}
		return ERROR;
	}
	//��ѯ�������
	public String bankAction(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		Criteria criteria = session.createCriteria(Question.class);
		
		ProjectionList projectionList = Projections.projectionList()
										.add(Projections.groupProperty("direction"))
										.add(Projections.groupProperty("stage"))
										.add(Projections.groupProperty("type"))
										.add(Projections.count("qid").as("count"));
		criteria.setProjection(projectionList);
		qbList = criteria.list();

		
		System.out.println(qbList.size());
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "bankAction";
		
	}
	
	public String selectOne(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		String direction=ServletActionContext.getRequest().getParameter("direction");//����
		String stage=ServletActionContext.getRequest().getParameter("stage");//�׶�
		String type=ServletActionContext.getRequest().getParameter("type");// ����/����
		System.out.println(direction);
		System.out.println(stage);
		System.out.println(type);
		
		Criteria criteria = session.createCriteria(Question.class)//��ѯ��������������Ҫ���������
							.add(Restrictions.eq("type",type))//���Ӳ�ѯ���������ѻ�ȡ���Ĳ����Ž�ȥ  ���Ի����
							.add(Restrictions.eq("direction",direction))//����
							.add(Restrictions.eq("stage",stage));//�׶�
		
		quesList=criteria.list();//�ŵ��������ļ�����
//		System.out.println(quesList.size());
		
		//������רҵ�ͽ׶δ��������������ʱʹ��
		ServletActionContext.getRequest().getSession().setAttribute("direction", direction);
		ServletActionContext.getRequest().getSession().setAttribute("stage", stage);

		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		//������ʾһ�������Ի�������ҳ��
		return "selectOne";
		
	}

	//��ת�����������jspҳ��
	public String addQuestion(){

		return "addQuestion";
	}
	//�������ӵ�����
	public String addOkAction(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		String direction = (String) ServletActionContext.getRequest().getSession().getAttribute("direction");
		String stage = (String) ServletActionContext.getRequest().getSession().getAttribute("stage");

		question.setDirection(direction);
		question.setStage(stage);

		
		session.save(question);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "addOk";
	}

	//ɾ������
	public String delAction(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		Question ques = (Question) session.get(Question.class, qid);
		session.delete(ques); 
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "delAction";
	}
	
	//�����������
	public String paperAction(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		paperList=session.createCriteria(Paper.class).list();
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "paperAction";
	}
	//������
	public String showaddPaper(){
		
		return "showaddPaper";
	}
	//�����Ծ��ķ���
	@SuppressWarnings("unchecked")
	public String addPaper(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
				
		String sql="select qid from (" +
		" select top "+temporary.getRjiandan()+" qid from tb_question where direction=:direction and stage=:stage and type= '��ѡ' and difficulty='��'  order by newId()" +
		" union  " +
		" select top "+temporary.getRyiban()+" qid from tb_question where  direction=:direction and stage=:stage  and type= '��ѡ' and difficulty='һ��'  order by newId()" +
		" union  " +
		" select top "+temporary.getRkunnan()+" qid from tb_question where  direction=:direction and stage=:stage  and type= '��ѡ' and difficulty='����'  order by newId()" +
		" union " +
		" select top "+temporary.getMjiandan()+" qid from tb_question where  direction=:direction and stage=:stage  and type= '��ѡ' and difficulty='��'  order by newId()" +
		" union  " +
		" select top "+temporary.getMyiban()+" qid from tb_question where  direction=:direction and stage=:stage  and type= '��ѡ' and difficulty='һ��'  order by newId()" +
		" union  " +
		" select top "+temporary.getMkunnan()+" qid from tb_question where  direction=:direction and stage=:stage  and type= '��ѡ' and difficulty='����'  order by newId()" +
		") as t";
		
		//��list�����е�qid����
		List<Integer> qidList=session.createSQLQuery(sql)
								.setParameter("direction", temporary.getDirection())//��ռλ����ֵ��רҵ
								.setParameter("stage", temporary.getStage())//�׶�
								.list();
		
		//paper���Ծ����� ����ʱ�Ծ������Ѿ����������ԣ���רҵ�ͽ׶�ƴ����������paper�Ŀ�Ŀ
		paper.setSubjects(temporary.getDirection()+temporary.getStage());
		
		//�����洢qid��LIst����
		for (Integer integer : qidList) {
			//ͨ��qid���question����  
			Question q=(Question)session.get(Question.class,integer);
			//paper�������Ƕ�Զ��ϵ�����paper��QuestionSet������ȡ����question�����Ž�ȥ
			//paper��question�Ƕ�Զ࣬��������ǵ��м���ͻ�����������������
			paper.getSetQuestion().add(q);
		}
		
		//�����Ծ�����
		session.save(paper);

		transaction.commit();
		HibernateSessionFactory.closeSession();
		
		//ͨ��struts2.xml�����õ��ض������󣬷��ص���ʾ�Ծ���ҳ��
		return "addOk";
	}
	
	public String delPaper(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		Paper paper = (Paper)session.get(Paper.class,pid);
		session.delete(paper);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "delPaper";
	}
	public String checkPaper(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		paper = (Paper)session.get(Paper.class,pid);
		
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "checkPaper";
	}
	
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}
	public List<Question> getQuesList() {
		return quesList;
	}
	public void setQuesList(List<Question> quesList) {
		this.quesList = quesList;
	}
	public List<Object[]> getQbList() {
		return qbList;
	}
	public void setQbList(List<Object[]> qbList) {
		this.qbList = qbList;
	}
	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

	public Teacher getTea() {
		return tea;
	}

	public void setTea(Teacher tea) {
		this.tea = tea;
	}

	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}
	public Students getStu() {
		return stu;
	}

	public void setStu(Students stu) {
		this.stu = stu;
	}

	public int getQid() {
		return qid;
	}
	public void setQid(int qid) {
		this.qid = qid;
	}
	
	public List<Paper> getPaperList() {
		return paperList;
	}
	public void setPaperList(List<Paper> paperList) {
		this.paperList = paperList;
	}
	
	public Temporary getTemporary() {
		return temporary;
	}
	public void setTemporary(Temporary temporary) {
		this.temporary = temporary;
	}
	public Paper getPaper() {
		return paper;
	}
	public void setPaper(Paper paper) {
		this.paper = paper;
	}
	
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
}
