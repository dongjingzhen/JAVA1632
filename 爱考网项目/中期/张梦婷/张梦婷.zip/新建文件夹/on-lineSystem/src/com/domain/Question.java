package com.domain;

import java.util.HashSet;
import java.util.Set;


public class Question {
	private int qid;
	private String kind;   //��ѡor��ѡ
	private String content;//��������
	private String optionA;
	private String optionB;
	private String optionC;
	private String optionD;
	private String answer; //��
	private String difficulty;//�Ѷ�
	private String chapter;//�½�
	private String type;//���� ����
	private String remark;//����
	private String direction;
	private String stage;
	private Set<Paper> paperSet = new HashSet<Paper>();


	public Set<Paper> getPaperSet() {
		return paperSet;
	}
	public void setPaperSet(Set<Paper> paperSet) {
		this.paperSet = paperSet;
	}
	public String getRemark() {
		return remark;
	}
	@Override
	public String toString() {
		return "Question [answer=" + answer + ", chapter=" + chapter
				+ ", content=" + content + ", difficulty=" + difficulty
				+ ", direction=" + direction + ", kind=" + kind + ", optionA="
				+ optionA + ", optionB=" + optionB + ", optionC=" + optionC
				+ ", optionD=" + optionD + ", remark=" + remark + ", stage="
				+ stage + ", type=" + type + "]";
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getStage() {
		return stage;
	}
	public void setStage(String stage) {
		this.stage = stage;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}

	public int getQid() {
		return qid;
	}
	public void setQid(int qid) {
		this.qid = qid;
	}


	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getOptionA() {
		return optionA;
	}
	public void setOptionA(String optionA) {
		this.optionA = optionA;
	}
	public String getOptionB() {
		return optionB;
	}
	public void setOptionB(String optionB) {
		this.optionB = optionB;
	}
	public String getOptionC() {
		return optionC;
	}
	public void setOptionC(String optionC) {
		this.optionC = optionC;
	}
	public String getOptionD() {
		return optionD;
	}
	public void setOptionD(String optionD) {
		this.optionD = optionD;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getDifficulty() {
		return difficulty;
	}
	public void setDifficulty(String difficulty) {
		this.difficulty = difficulty;
	}
//	public String getSubjectId() {
//		return subjectId;
//	}
//	public void setSubjectId(String subjectId) {
//		this.subjectId = subjectId;
//	}
	public String getChapter() {
		return chapter;
	}
	public void setChapter(String chapter) {
		this.chapter = chapter;
	}

	
}
