package com.dao;


import java.util.Date;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.domain.Admin;
import com.domain.Classes;
import com.domain.Paper;
import com.domain.Question;
import com.domain.Students;
import com.domain.Teacher;



public class TestDAO {
	public static void main(String[] args) {
		save();
	}
	
	public static void save(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		Admin admain = new Admin();
		admain.setName("250");
		admain.setPwd("123");
		
		Teacher tea = new Teacher();
		tea.setTaccount("000");
		tea.setTjop("��ʦ");
		tea.setTname("��ʦ1");
		tea.setTpwd("123");
		tea.setTsex("��");
		tea.setTtelphone("1111111");
		tea.setRemarks("����");
		
		Students stu = new Students();
		stu.setBaseInfo("������Ϣ");
		stu.setBeizhu("��ע");
		stu.setCity("����");
		stu.setEdcutionBg("��������");
		stu.setIdCard("411423111111111111");
		stu.setInDate("2013-11-11");
		stu.setJiudu("java");
		stu.setParentsTel("22222222");
		stu.setPwd("123");
		stu.setReleation("ĸ��");
		stu.setSex("��");
		stu.setShengFen("ʡ��");
		stu.setStudentName("ѧ������");
		stu.setSushe("����");
		stu.setSusheNum("111");
		stu.setTelephone("5435353");
		stu.setXueHao("1603302222");
		stu.setZhengzLook("��Ա");
		stu.setZhuanYe("java��������");
		
		
		Students stu1 = new Students();
		stu1.setBaseInfo("������Ϣ");
		stu1.setBeizhu("��ע");
		stu1.setCity("����");
		stu1.setEdcutionBg("��������");
		stu1.setIdCard("411423111111111111");
		stu1.setInDate("2013-11-11");
		stu1.setJiudu("java");
		stu1.setParentsTel("22222222");
		stu1.setPwd("123");
		stu1.setReleation("ĸ��");
		stu1.setSex("��");
		stu1.setShengFen("ʡ��");
		stu1.setStudentName("ѧ������");
		stu1.setSushe("����");
		stu1.setSusheNum("111");
		stu1.setTelephone("5435353");
		stu1.setXueHao("1603302222");
		stu1.setZhengzLook("��Ա");
		stu1.setZhuanYe("java��������");
		
		
		
		Question question = new Question();
		question.setKind("��ѡ");
		question.setContent("����1");
		question.setDifficulty("��");
		question.setOptionA("A");
		question.setOptionB("B");
		question.setOptionC("C");
		question.setOptionD("D");
		question.setAnswer("a");
		question.setChapter("�½�һ");
		question.setType("����");
		question.setDirection("SCCE");
		question.setStage("G1");
		
		Question question1 = new Question();
		question1.setKind("��ѡ");
		question1.setContent("����2");
		question1.setDifficulty("����");
		question1.setOptionA("A");
		question1.setOptionB("B");
		question1.setOptionC("C");
		question1.setOptionD("D");
		question1.setAnswer("b");
		question1.setChapter("�½ڶ�");
		question1.setType("����");
		question1.setDirection("SCCE");
		question1.setStage("G1");
		
		Question question2 = new Question();
		question2.setKind("��ѡ");
		question2.setContent("����3");
		question2.setDifficulty("�е�");
		question2.setOptionA("A");
		question2.setOptionB("B");
		question2.setOptionC("C");
		question2.setOptionD("D");
		question2.setAnswer("d");
		question2.setChapter("�½ڶ�");
		question2.setType("����");
		question2.setDirection("SCME");
		question2.setStage("G1");
		
		Question question3 = new Question();
		question3.setKind("��ѡ");
		question3.setContent("����3");
		question3.setDifficulty("�е�");
		question3.setOptionA("A");
		question3.setOptionB("B");
		question3.setOptionC("C");
		question3.setOptionD("D");
		question3.setAnswer("d");
		question3.setChapter("�½ڶ�");
		question3.setType("����");
		question3.setDirection("SCME");
		question3.setStage("G1");

		Classes c = new Classes();
		c.setClassDaima("1632");
		c.setClassName("java1632");
		c.setFangxiang("��������");
		c.setTeachers(tea);
		c.setBegainDate(new Date());
		c.setZhuangTai("����");
		c.setBeizhu("��ע");
		c.getStudentSet().add(stu);
		c.getStudentSet().add(stu1);
		
		Paper paper = new Paper();
		paper.setTitle("java����");
		paper.setSubjects("java");
		paper.setType("����");
		paper.setState("δ����");
		paper.setStart(new Date());
		paper.setMinute(120);
		paper.setCountScore(100);
		paper.setCountQuestion(10);
		paper.setAverage(10);


		
		session.save(paper);
		session.save(c);
		session.save(admain);
		session.save(tea);
		session.save(stu);
		session.save(stu1);
		session.save(question);
		session.save(question1);
		session.save(question2);
		session.save(question3);

		
		

		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
}
