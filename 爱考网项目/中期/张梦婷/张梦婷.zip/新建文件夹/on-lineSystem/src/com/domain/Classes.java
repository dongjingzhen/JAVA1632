package com.domain;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Classes {
	
	private int id;
	private String classDaima; //�༶����
	private String className;  //�༶����
	private String fangxiang;  //��������
	private Teacher teachers;
	private Teacher tea;
	private Date begainDate;  //��������
	private String zhuangTai; //״̬
	private String beizhu;
	private Set<Students> studentSet = new HashSet<Students>();  //����ѧ��
	private Set<Paper> paperSet = new HashSet<Paper>();
	
	public Set<Paper> getPaperSet() {
		return paperSet;
	}
	public void setPaperSet(Set<Paper> paperSet) {
		this.paperSet = paperSet;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getClassDaima() {
		return classDaima;
	}
	public void setClassDaima(String classDaima) {
		this.classDaima = classDaima;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getFangxiang() {
		return fangxiang;
	}
	public void setFangxiang(String fangxiang) {
		this.fangxiang = fangxiang;
	}
	

	public Teacher getTeachers() {
		return teachers;
	}
	public void setTeachers(Teacher teachers) {
		this.teachers = teachers;
	}
	public Teacher getTea() {
		return tea;
	}
	public void setTea(Teacher tea) {
		this.tea = tea;
	}
	public Date getBegainDate() {
		return begainDate;
	}
	public void setBegainDate(Date begainDate) {
		this.begainDate = begainDate;
	}
	public String getZhuangTai() {
		return zhuangTai;
	}
	public void setZhuangTai(String zhuangTai) {
		this.zhuangTai = zhuangTai;
	}
	public String getBeizhu() {
		return beizhu;
	}
	public void setBeizhu(String beizhu) {
		this.beizhu = beizhu;
	}
	public Set<Students> getStudentSet() {
		return studentSet;
	}
	public void setStudentSet(Set<Students> studentSet) {
		this.studentSet = studentSet;
	}
	
}
 