package domain;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Paper {
	private int pid;
	private String title;//�Ծ�����
	private String 	subjName;//��Ŀ
	private String state="δ����";//״̬  Ĭ�ϣ�δ����   �������� �����Խ���
	private Date goPaper;//����ʱ��
	private String cName;//���԰༶
	private int testHour;//����ʱ��
	private int totalScore;//�ܷ�
	private int totalQuestion;//������
	private int avgScore;//ÿ��ƽ����
	private Set<Question> questionSet = new HashSet<Question>();//�Ծ��е����⼯��
	private Set<Classes> classesSet = new HashSet<Classes>();//�ĸ��༶���Եļ���
	
	
	
	
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public int getTotalQuestion() {
		return totalQuestion;
	}
	public void setTotalQuestion(int totalQuestion) {
		this.totalQuestion = totalQuestion;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSubjName() {
		return subjName;
	}
	public void setSubjName(String subjName) {
		this.subjName = subjName;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Date getGoPaper() {
		return goPaper;
	}
	public void setGoPaper(Date goPaper) {
		this.goPaper = goPaper;
	}
	public int getTestHour() {
		return testHour;
	}
	public void setTestHour(int testHour) {
		this.testHour = testHour;
	}
	public int getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(int totalScore) {
		this.totalScore = totalScore;
	}
	public int getAvgScore() {
		return avgScore;
	}
	public void setAvgScore(int avgScore) {
		this.avgScore = avgScore;
	}
	public Set<Question> getQuestionSet() {
		return questionSet;
	}
	public void setQuestionSet(Set<Question> questionSet) {
		this.questionSet = questionSet;
	}
	public Set<Classes> getClassesSet() {
		return classesSet;
	}
	public void setClassesSet(Set<Classes> classesSet) {
		this.classesSet = classesSet;
	}
	
	
	
	
}
