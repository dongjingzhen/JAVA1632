package domain;

/*
 * ��ʦ��
 */
public class Teacher {
	private int id;
	private String tAccount;//�˺�
	private String tName;//����
	private String tPwd;//����
	private String sex;//�Ա�
	private String tbirthday;//����
	private String teducation;//ѧ��
	private String ttelPhone;//�绰
	private String tjop;//��λ
	private String tremarks;//��ע
	
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String gettAccount() {
		return tAccount;
	}
	public void settAccount(String tAccount) {
		this.tAccount = tAccount;
	}
	public String gettName() {
		return tName;
	}
	public void settName(String tName) {
		this.tName = tName;
	}
	public String gettPwd() {
		return tPwd;
	}
	public void settPwd(String tPwd) {
		this.tPwd = tPwd;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getTbirthday() {
		return tbirthday;
	}
	public void setTbirthday(String tbirthday) {
		this.tbirthday = tbirthday;
	}
	public String getTeducation() {
		return teducation;
	}
	public void setTeducation(String teducation) {
		this.teducation = teducation;
	}
	public String getTtelPhone() {
		return ttelPhone;
	}
	public void setTtelPhone(String ttelPhone) {
		this.ttelPhone = ttelPhone;
	}
	public String getTjop() {
		return tjop;
	}
	public void setTjop(String tjop) {
		this.tjop = tjop;
	}
	public String getTremarks() {
		return tremarks;
	}
	public void setTremarks(String tremarks) {
		this.tremarks = tremarks;
	}
	
	
	
}
