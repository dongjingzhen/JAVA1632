package dao;


import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import domain.Admin;
import domain.Classes;
import domain.Paper;
import domain.Question;
import domain.Student;
import domain.Teacher;

public class TestDao {
	private static final String Integer = null;


	public static void main(String[] args) {
		run();
		//get();
		//ii();
		//qq();
		//addqq();
		addzhong();
		addkun();
		//showchakanshijuan();
		//getc();
		
	}
	
	public static void adminn(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();

		Admin admin= (Admin) session.createCriteria(Admin.class)
					.setProjection(Projections.projectionList()
							.add(org.hibernate.criterion.Property.forName("admin"))
							.add(org.hibernate.criterion.Property.forName("admin")));
					
					
		System.out.println(admin);
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	
	public static void run(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Admin ad = new Admin();
		ad.setAdminName("admin");
		ad.setAdminPwd("admin");
		session.save(ad);
		
		Admin ad1 = new Admin();
		ad1.setAdminName("adminn");
		ad1.setAdminPwd("adminn");
		session.save(ad1);
		
		Teacher t1 = new Teacher();
		t1.settName("����");
		t1.settPwd("123");
		session.save(t1);
	
		Classes c1 = new Classes();
		c1.setClassName("java1631");
		c1.setHeadteacher(t1);
		c1.setLecturer(t1);
		session.save(c1);
		
		Student s1 = new Student();
		s1.setStuNo("001");
		s1.setStuPwd("123");
		session.save(s1);
		
		
		for (int i = 0; i < 20; i++) {
			Question q1 = new Question();
			q1.setKind("��ѡ");
			q1.setContent("����"+i);
			q1.setOptionA("��"+i);
			q1.setOptionB("����"+i);
			q1.setOptionC("�ǲ���"+i);
			q1.setOptionD("������"+i);
			q1.setAnswer("B");
			q1.setDifficulty("��");
			q1.setQuestionType("����");
			q1.setChapter("��һ��");
			q1.setSubjectName("java");
			q1.setStage("G1");
			q1.setDirection("SCME");
			session.save(q1);
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	
	public static void ad(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
//
//		Admin admin= (Admin) session.createCriteria(Admin.class)
//					.setProjection(Projections.projectionList()
//							.add(org.hibernate.criterion.Property.forName("admin"))
//							.add(org.hibernate.criterion.Property.forName("admin")));
		String hql = "select t from Teacher t where t.tName=:userName and t.tPwd=:userPwd";
		String loginName="����";
		String loginPwd="123";
		Teacher teacherName = (Teacher)session.createQuery(hql)
							.setParameter("userName", loginName)
							.setParameter("userPwd", loginPwd)
							.uniqueResult();
		System.out.println(teacherName);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		
	}
	

	public static void get(){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Criteria criteria = session.createCriteria(Question.class);
		
		ProjectionList projectionList = Projections.projectionList()
							.add(Projections.groupProperty("subjectName"))
							.add(Projections.groupProperty("questionType"))
							.add(Projections.groupProperty("stage"))
							.add(Projections.count("subjectName"));
		criteria.setProjection(projectionList);
		System.out.println(criteria.list().size());
		for (Object[] o :(List<Object[]>)criteria.list()) {
			System.out.println(o[0]+","+o[1]+","+o[2]+","+o[3]);
		}

		
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}

	public static void ii(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Criteria criteria = session.createCriteria(Question.class)
									.setFetchMode("subject", FetchMode.JOIN)
									.createAlias("subject", "s")
									.add(Restrictions.eq("questionType", "����"))
									.add(Restrictions.eq("s.subjectName", "java"));
		for (Object o : criteria.list()) {
			System.out.println(o);
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	
	
	public static void qq(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Criteria criteria = session.createCriteria(Question.class)	
		.add(Restrictions.eq("questionType", "����"))
		.add(Restrictions.eq("subjectName", "java"));
		System.out.println(criteria.list());
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	
	public static void addqq(){//�����Ծ�
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Paper p = new Paper();
		p.setTitle("java����");
		p.setSubjName("java");
		p.setTestHour(60);
		session.save(p);
		
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	
	public static void addzhong(){//�����е�
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		for (int i = 0; i < 20; i++) {
			Question q1 = new Question();
			q1.setKind("��ѡ");
			q1.setContent("zhong"+i);
			q1.setOptionA("��"+i);
			q1.setOptionB("����"+i);
			q1.setOptionC("�ǲ���"+i);
			q1.setOptionD("������"+i);
			q1.setAnswer("B");
			q1.setDifficulty("��ͨ");
			q1.setQuestionType("����");
			q1.setChapter("��һ��");
			q1.setSubjectName("java");
			q1.setStage("G1");
			q1.setDirection("SCME");
			session.save(q1);
		}
		
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	
	public static void addkun(){//�����Ծ�
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		for (int i = 0; i < 20; i++) {
			Question q1 = new Question();
			q1.setKind("��ѡ");
			q1.setContent("kun"+i);
			q1.setOptionA("��"+i);
			q1.setOptionB("����"+i);
			q1.setOptionC("�ǲ���"+i);
			q1.setOptionD("������"+i);
			q1.setAnswer("B");
			q1.setDifficulty("����");
			q1.setQuestionType("����");
			q1.setChapter("��һ��");
			q1.setSubjectName("java");
			q1.setStage("G1");
			q1.setDirection("SCME");
			session.save(q1);
		}
		
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	
	public static void showchakanshijuan(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		Criteria criteria=session.createCriteria(Classes.class)
						.add(Restrictions.eq("classNo", "JAVA1631"));
		String hql = "select c from Classes c where c.classNo=:classNo";
		Classes classes = (Classes) session.createQuery(hql).setParameter("classNo", "JAVA1631").uniqueResult();
		
		
		
		System.out.println(classes);
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	
	public static void getc(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		Criteria criteria =(Criteria)session.createCriteria(Classes.class);
		ProjectionList projectionList = Projections.projectionList().add(Projections.property("classNo"));
		criteria.setProjection(projectionList);
		System.out.println(criteria.list());
		for (Object o :criteria.list()) {
			System.out.println(o);
		}

		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	
}
