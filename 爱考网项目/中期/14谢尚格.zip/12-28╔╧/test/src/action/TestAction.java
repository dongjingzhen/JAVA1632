package action;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.struts2.ServletActionContext;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.opensymphony.xwork2.Action;
import com.sun.org.apache.bcel.internal.util.ClassSet;

import dao.HibernateSessionFactory;
import domain.Admin;
import domain.Classes;
import domain.Paper;
import domain.Question;
import domain.Student;
import domain.randomGain;

import domain.Teacher;

public class TestAction implements Action {
	private String role;//��½ҳ�������˵���ֵֻ
	private String loginName;//��½���ڵ��˻���
	private String loginPwd;//��½���ڵ�����
	private List<Object []> questionList = new ArrayList<Object[]>();
	private List<Question> queList = new ArrayList<Question>();
	private Question question;//����
	private int qid;//����id����ɾ��
	private List<Paper> paperList = new ArrayList<Paper>();
	private randomGain randomgain;//������������ȡֵ
	private Paper paper;//����������
	private int pid;//�����Ծ������޸�ɾ��
	private String queSubjectName;//�����޸�ĳһ����
	private List<Classes> claList = new ArrayList<Classes>();
	private String classN;//��ʼ���Եİ༶
	private Date goDate;//��ʼ���Ե�ʱ��
	private List<Classes> classNoList = new ArrayList<Classes>();//��Ű༶��list 
	private List<Student> stuList = new ArrayList<Student>();//�鿴ѧ��
	

	public List<Student> getStuList() {
		return stuList;
	}
	public void setStuList(List<Student> stuList) {
		this.stuList = stuList;
	}
	public List<Classes> getClassNoList() {
		return classNoList;
	}
	public void setClassNoList(List<Classes> classNoList) {
		this.classNoList = classNoList;
	}
	public String getClassN() {
		return classN;
	}
	public void setClassN(String classN) {
		this.classN = classN;
	}
	public Date getGoDate() {
		return goDate;
	}
	public void setGoDate(Date goDate) {
		this.goDate = goDate;
	}
	public List<Classes> getClaList() {
		return claList;
	}
	public void setClaList(List<Classes> claList) {
		this.claList = claList;
	}
	public String getQueSubjectName() {
		return queSubjectName;
	}
	public void setQueSubjectName(String queSubjectName) {
		this.queSubjectName = queSubjectName;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public randomGain getRandomgain() {
		return randomgain;
	}
	public void setRandomgain(randomGain randomgain) {
		this.randomgain = randomgain;
	}
	public Paper getPaper() {
		return paper;
	}
	public void setPaper(Paper paper) {
		this.paper = paper;
	}
	public List<Paper> getPaperList() {
		return paperList;
	}
	public void setPaperList(List<Paper> paperList) {
		this.paperList = paperList;
	}
	public int getQid() {
		return qid;
	}
	public void setQid(int qid) {
		this.qid = qid;
	}
	public Question getQuestion() {
		return question;
	}
	public void setQuestion(Question question) {
		this.question = question;
	}

	public List<Question> getQueList() {
		return queList;
	}
	public void setQueList(List<Question> queList) {
		this.queList = queList;
	}
	public List<Object[]> getQuestionList() {
		return questionList;
	}
	public void setQuestionList(List<Object[]> questionList) {
		this.questionList = questionList;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getLoginPwd() {
		return loginPwd;
	}
	public void setLoginPwd(String loginPwd) {
		this.loginPwd = loginPwd;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	//��½
	public String login(){		
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		if (role.equals("4")) {
			String hql = "select a from Admin a where a.adminName=:userName and a.adminName=:userPwd";
			Admin admin =(Admin)session.createQuery(hql)
								.setParameter("userName", loginName)
								.setParameter("userPwd", loginPwd)
								.uniqueResult();
			transaction.commit();
			HibernateSessionFactory.closeSession();
			if(admin!=null){
				ServletActionContext.getRequest().getSession().setAttribute("user", "����Ա");
				return SUCCESS;
			}	
		}else if(role.equals("2")){
			String hql = "select t from Teacher t where t.tName=:userName and t.tPwd=:userPwd";
			Teacher teacherName = (Teacher)session.createQuery(hql)
								.setParameter("userName", loginName)
								.setParameter("userPwd", loginPwd)
								.uniqueResult();
			transaction.commit();
			HibernateSessionFactory.closeSession();
			if(teacherName!=null){
				ServletActionContext.getRequest().getSession().setAttribute("user", "��ʦ");
				return SUCCESS;	
			}	
		}else if(role.equals("1")){
			String hql = "select s from Student s where s.stuNo=:userName and s.stuPwd=:userPwd";
			Student studentName = (Student) session.createQuery(hql)
								.setParameter("userName", loginName)
								.setParameter("userPwd", loginPwd)
								.uniqueResult();
			transaction.commit();
			HibernateSessionFactory.closeSession();
			if(studentName!=null){
				ServletActionContext.getRequest().getSession().setAttribute("user", "ѧ��");
				return SUCCESS;
			}
		}
		ServletActionContext.getRequest().getSession().setAttribute("massage", "�˺Ż��������");
		return ERROR;
		
			
	}
	
	//������ ��ʾ��Ŀ ���ٵ����Զ��ٵ�����
	public String quesList(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Criteria criteria = session.createCriteria(Question.class);
							
		ProjectionList projectionList = Projections.projectionList()
							.add(Projections.groupProperty("subjectName"))
							.add(Projections.groupProperty("questionType"))
							.add(Projections.groupProperty("stage"))
							.add(Projections.count("subjectName"));
		criteria.setProjection(projectionList);
		questionList=criteria.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "list";
		
	}
	//��ʾ����ķ���
	public String listQuestion(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		String type = ServletActionContext.getRequest().getParameter("type");//���Ա���
		String subName = ServletActionContext.getRequest().getParameter("subName");//רҵ
		String stage=ServletActionContext.getRequest().getParameter("stage");//�׶�		
		Criteria criteria = session.createCriteria(Question.class)	
						.add(Restrictions.eq("questionType", type))
						.add(Restrictions.eq("subjectName", subName))
						.add(Restrictions.eq("stage", stage));
						
		
		
		
		ServletActionContext.getRequest().getSession().setAttribute("type", type);
		ServletActionContext.getRequest().getSession().setAttribute("subName", subName);
		ServletActionContext.getRequest().getSession().setAttribute("stage", stage);
		queList=criteria.list();
		System.out.println(queList.size());
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "listqwe";
	}
	
	//��ת������ҳ��
	public String showAddQue(){
		return "showadd";
		
	}
	
	
	//��������ķ���
	public String addQuestion(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		String type = (String) ServletActionContext.getRequest().getSession().getAttribute("type");
		String subName=(String) ServletActionContext.getRequest().getSession().getAttribute("subName");
		String stage = (String) ServletActionContext.getRequest().getSession().getAttribute("stage");
		
		question.setQuestionType(type);
		question.setSubjectName(subName);
		question.setStage(stage);
		question.setDirection("SCME");
		session.save(question);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "addques";
		
	}
	
	
	
	//ɾ������
	public String delectQue(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Question question = (Question) session.get(Question.class, qid);
		session.delete(question);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "delete";
		
	}
	
	//���Ҫ�޸ĵ�����
	public String showupdateQue(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Question question = (Question) session.get(Question.class, qid);
		queList.add(question);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "showupdate";	
	}
	
	//�޸�
	public String updateQue(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		String type = (String) ServletActionContext.getRequest().getSession().getAttribute("type");
		String subName=(String) ServletActionContext.getRequest().getSession().getAttribute("subName");
		String stage = (String) ServletActionContext.getRequest().getSession().getAttribute("stage");
		
		Question que=(Question)session.get(Question.class, question.getQid());
		que.setKind(question.getKind());
		que.setContent(question.getContent());
		que.setOptionA(question.getOptionA());
		que.setOptionB(question.getOptionB());
		que.setOptionC(question.getOptionC());
		que.setOptionD(question.getOptionD());
		que.setDifficulty(question.getDifficulty());
		que.setChapter(question.getChapter());
		que.setAnswer(question.getAnswer());
		que.setQuestionType(type);
		que.setSubjectName(subName);
		que.setStage(stage);
		que.setDirection("SCME");
		
		
		
		session.update(que);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "updateQUE";
	}
	
	
	//�鿴�����Ծ��ķ���
	public String showPaper(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Criteria criteria = (Criteria)session.createCriteria(Paper.class);
		paperList=criteria.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "showpaper";	
	}
	
	//�������ķ���
	public String randomP(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		String sql = "select qid from"+ 
					"(select top "+randomgain.getRdj()+" qid from question where difficulty= '��' and kind='��ѡ'  order by newId()"+					
					" union "+ 
					"select top "+randomgain.getRdz()+" qid from question where difficulty= '��ͨ'  and kind='��ѡ' order by newId()"+ 					
					" union "+
					"select top "+randomgain.getRdk()+" qid from question where difficulty= '����' and kind='��ѡ' order by newId()"+
					" union "+
					"select top "+randomgain.getRduoj()+" qid from question where difficulty= '��' and kind='��ѡ' order by newId()"+					
					" union "+ 
					"select top "+randomgain.getRduoz()+" qid from question where difficulty= '��ͨ' and kind='��ѡ' order by newId()"+ 					
					" union "+
					"select top "+randomgain.getRdouk()+" qid from question where difficulty= '����' and kind='��ѡ' order by newId()"+	
					") as k";
		List<Integer> qidList = session.createSQLQuery(sql).list();
		paper.setSubjName(randomgain.getFangxiang()+randomgain.getJieduan()+paper.getSubjName());
		paper.setTotalQuestion(paper.getTotalQuestion());
		for (Integer integer : qidList) {
			Question q = (Question) session.get(Question.class, integer);
			paper.getQuestionSet().add(q);
		}
		session.save(paper);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "randompaper";	
	}
	
	//�鿴�Ծ��ķ���
	public String getOnepaperQuestion(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
			paper = (Paper) session.get(Paper.class, pid);
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "getOnepaperQ";
	}
	
	//��ȡ�޸��Ծ���ĳһ��ķ���
	public String updateOnepaperQuestion(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		String queSubjectName =  ServletActionContext.getRequest().getParameter("queSubjectName");//���Ա���
		Criteria criteria = (Criteria)session.createCriteria(Question.class).add(Restrictions.eq("subjectName", queSubjectName));	
		queList=criteria.list();

		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "updateOnepaperOneQ";
	}
	
	//�޸��Ծ�ĳһ��ķ���
	public String updateOnepaperQu(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		int ppid = Integer.parseInt(ServletActionContext.getRequest().getParameter("onepid"));

		Question question = (Question) session.get(Question.class, qid);
		Paper paper = (Paper) session.get(Paper.class, pid);
		paper.getQuestionSet().remove(question);
		
		String hql = "select q from Question q where q.qid=:qid";
		Question question2 =(Question) session.createQuery(hql).setParameter("qid",ppid).uniqueResult();
		
		paper.getQuestionSet().add(question2);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "updateOnepaperQqq";
	}
	
	
	//ɾ���Ծ��ķ���
	public String delOnepaperQuestion(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		paper = (Paper) session.get(Paper.class, pid);
		session.delete(paper);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "delOnepaperQ";
	}
	
	//�鿴�༶�ķ��� 
	public String classesList(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Criteria criteria = (Criteria)session.createCriteria(Classes.class);
		claList=criteria.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "classList";
		
	}
	
	//�鿴ѧ���ķ��� 
	public String studentList(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Criteria criteria = (Criteria)session.createCriteria(Student.class);
		stuList=criteria.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "studentList";
		
	}
	//���뿪ʼ����ҳ��ͻ�ȡ�༶�ķ���
	public String gogostartTest(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Criteria criteria =(Criteria)session.createCriteria(Classes.class);

		classNoList=criteria.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "gogogo";
		
	}
	
	//��ʼ���Եķ���
	public String paperStartTest(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		
		Paper paper = (Paper) session.get(Paper.class, pid);
		
		String hql = "select c from Classes c where c.classNo=:classNo";
		Classes classes = (Classes) session.createQuery(hql).setParameter("classNo", classN).uniqueResult();
		paper.getClassesSet().add(classes);
		paper.setcName(classN);
		paper.setGoPaper(goDate);
		paper.setState("������");
		session.update(paper);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "pstarttest";
	}
	
	
}
