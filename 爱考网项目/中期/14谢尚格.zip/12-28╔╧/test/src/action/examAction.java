package action;

import java.util.ArrayList;
import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.opensymphony.xwork2.Action;

import dao.HibernateSessionFactory;
import domain.Paper;

public class examAction implements Action {
	private List<Paper> paperList = new ArrayList<Paper>();
	private int pid;//�Ծ�id
	private Paper paper;
	
	
	
	
	public Paper getPaper() {
		return paper;
	}
	public void setPaper(Paper paper) {
		this.paper = paper;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public List<Paper> getPaperList() {
		return paperList;
	}
	public void setPaperList(List<Paper> paperList) {
		this.paperList = paperList;
	}





	//�鿴�����Ծ��ķ���
	public String stushowPaper(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		Criteria criteria = (Criteria)session.createCriteria(Paper.class);
		paperList=criteria.list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "stushowpaper";	
	}
	//��ʼ���Ե��Ծ�
	public String getOnepaperQuest(){
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction = session.beginTransaction();
		paper = (Paper) session.get(Paper.class, pid);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "getOnepaperQ";
	}
	
	
	
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
}
