package action;



import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.xml.crypto.Data;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import dao.HibernateSessionFactory;
import domain.Admin;
import domain.Classes;
import domain.Jishiti;
import domain.Jvanzi;
import domain.Kaoshiti;
import domain.Shiti;
import domain.Students;
import domain.Teacher;
import domain.Tiku;

public class textBooks {
	public static void main(String[] args) {
		
//			save();
			get();
//		add();
//			savejishi();
//		 saveaaa();
//		fenye();
	}
	public static void save()
	{
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		Admin a=new Admin();
		a.setName("zgp");
		a.setPwd("123");
		session.save(a);
		
		Classes classes=new Classes();
		classes.setCname("java1632");
		classes.setCnum("CUSNM");
		
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date date1 = new Date();
			date1 = sdf.parse("2007-06-06");
			classes.setCdata(date1);
			classes.setCstatus("����");
			session.save(classes);
			
			Students s=new Students();
			s.setShao("sss");
			s.setPwd("111");
			s.setName("����");
			s.setClasses(classes);
			s.setStelphont("123456789");
			session.save(s);
			Teacher t=new Teacher();
			t.setTzhanghao("ttt");
			t.setPwd("1111");
			
			Date date = new Date();
			date = sdf.parse("2007-06-06");
			t.setTbithbpdy(date);
			t.setJop("��Ա");
			t.setTelphont("123456789");
			t.setTsex("��");
			t.setXveli("����");
			t.setName("��ʷ");
			session.save(t);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		Tiku sub1=new Tiku();
//		sub1.setTname("Java");
		Shiti st=new Shiti();
		st.setStype("��ѡ");
		st.setSname("��������");
		st.setOptionA("�ǵ�");
		st.setOptionB("����");
		st.setOptionC("�ٵ�");
		st.setOptionD("���");
		
		st.setAnswer("A,B,C");
		st.setKemu("java");
		st.setNandu("��");
		st.setTitype("T01");
		st.setTyles("����");
//		st.setTiku(sub1);
		session.save(st);
		Shiti st1=new Shiti();
		st1.setStype("��ѡ");
		st1.setSname("��������");
		st1.setOptionA("�ǵ�");
		st1.setOptionB("����");
		st1.setOptionC("�ٵ�");
		st1.setOptionD("���");
		
		st1.setAnswer("A,B,C");
		st1.setKemu("java");
		st1.setNandu("��");
		st1.setTitype("T01");
		st1.setTyles("����");
//		st1.setTiku(sub1);
		session.save(st1);
		Shiti st2=new Shiti();
		st2.setStype("��ѡ");
		st2.setSname("��������");
		
		
		st2.setAnswer("A,B,C");
		st2.setKemu("java");
		st2.setNandu("��");
		st2.setTitype("T01");
		st2.setTyles("����");
//		st2.setTiku(sub1);
		session.save(st2);
		Jvanzi jz=new Jvanzi();
		jz.setJname("��һ�ο���");
		jz.setJstate("δ����");
		jz.setShichang(60);
		jz.setKemu("java");
		jz.setJiorbi("����");
		jz.setBanji("java1631");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String string2 = "2016-11-11 00:00:00";
		Date date2;
		try {
			date2 = (Date) sdf.parse(string2);
			jz.setJtime(date2);
			session.save(jz);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
//		sub1.getBishiSet().add(st1);
//		sub1.getBishiSet().add(st);
//		sub1.getBishiSet().add(st2);
//		session.save(sub1);
//		//ʱ��ĸ�ʽ
//		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//		Sort classes=new Sort();
//		classes.setSname("����");
//
//		Books student=new Books();
//		student.setBname("����ʱ��");
//		student.setAuthor("����");
//		String string2 = "2016-11-11 00:00:00";
//		Date date2=(Date) sdf.parse(string2);
//		student.setButyime(date2);
//		student.setSort(classes);
//		
//		Books student1=new Books();
//		student1.setBname("��������");
//		student1.setAuthor("����");
//		
//		//�Զ���������Ĺ���ʱ�䣬ת��Ϊָ����ʱ���ʽ
//		String string1 = "2016-10-10 00:00:00";
//		Date date1=(Date) sdf.parse(string1);
//		student1.setButyime(date1);
//		student1.setSort(classes);
//		
//		
//		classes.getBooksSet().add(student);
//		classes.getBooksSet().add(student1);
//		session.save(classes);
//		
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
//	public static void saveaaa()
//	{
//	Session session=HibernateSessionFactory.getSession();
//	Transaction transaction=session.beginTransaction();
//	
//	
//	Criteria  s =session.createCriteria(Sort.class);
//	List lis=s.list();
//	for (int i = 0; i < lis.size(); i++) {
//		Sort students=(Sort)lis.get(i);
//		System.out.println(students.getSname()
//				);
//	}
//	Query q = session.createQuery("from books");
//	q.setFirstResult(0);
//	q.setMaxResults(3);
//	lis = q.list();
//	
//	transaction.commit();
//	HibernateSessionFactory.closeSession();
//
//}

//	public static void fenye()
//	{
//	Session session=HibernateSessionFactory.getSession();
//	Transaction transaction=session.beginTransaction();
//	String hql="select b  from Sort s inner join s.booksSet b ";
//	List<Books> lis = session.createQuery(hql)
//      .setFirstResult(0)
//      .setMaxResults(2)
//      .list();
//	  for (Books s : lis) {
//			System.out.println(s.getButyime()+""+s.getSort().getSname());
//	  }
//	  hql="select count(s)  from Sort s inner join s.booksSet b  ";
//		 List<Object> obj=session.createQuery(hql).list();
//		 for (Object object : obj) {
//			 System.out.println(Integer.parseInt(String.valueOf(object)));
//		}
//		 
//	transaction.commit();
//	HibernateSessionFactory.closeSession();
//
//}
	public static void savejishi()
	{
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		String str="����";
		String sql="select sid from ";
		sql+=" (select top 2 sid from shiti where kemu='java' and tyles='"+str+"' and titype='T01' and stype='��ѡ'  and nandu='��' ";
		sql+=" order by newId() union ";
		sql+=" select top 2 sid from shiti where kemu='java' and tyles='����' and titype='T01' and stype='��ѡ'  and  nandu='�е�' ";
		sql+=" order by newId() union ";
		sql+=" select top 2 sid from shiti where kemu='java' and tyles='����' and titype='T01' and stype='��ѡ'  and  nandu='����' ";
		sql+=" order by newId() union ";
		sql+=" select top 2 sid from shiti where kemu='java' and tyles='����' and titype='T01' and stype='��ѡ'  and nandu='��' " ;
		sql+=" order by newId() union ";
		sql+=" select top 2 sid from shiti where kemu='java' and tyles='����' and titype='T01' and stype='��ѡ'  and  nandu='�е�' ";
		sql+=" order by newId() union ";
		sql+=" select top 2 sid from shiti where kemu='java' and tyles='����' and titype='T01' and stype='��ѡ'  and  nandu='����' ";
		sql+=" order by newId() ) as t ";
		List lis= session.createSQLQuery(sql).list();
		int ss=0;
		
		String hql="select top 1 j.jid from Jvanzi j order by j.jid desc";
		List list= session.createSQLQuery(hql).list();
		for (int i = 0; i <list.size(); i++) {
			ss=Integer.parseInt(lis.get(i).toString());
		}
		Jvanzi c=(Jvanzi) session.get(Jvanzi.class, ss);
		
		for (int i = 0; i < lis.size(); i++) {
			int in=Integer.parseInt(lis.get(i).toString()) ;
			Shiti st=(Shiti) session.get(Shiti.class, in);
			c.getShitSet().add(st);
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	public static void add(){
		List lis=new ArrayList();
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		Jvanzi jz=(Jvanzi) session.get(Jvanzi.class, 1);
		Set<Shiti> st=jz.getShitSet();
		for (Shiti shi : st) {
			Shiti s=shi;
			lis.add(s);
		}
		for (int i = 0; i <lis.size(); i++) {
			System.out.println(i);
		}
		
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	public static void get(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		List list=new ArrayList();
		String sql="select s.sname,s.optionA,s.optionB,s.optionC,s.optionD,s.answer,k.sname from Shiti s inner join Kaoshiti k on k.shitiId=s.sid";
		List<Object[]> obj=session.createSQLQuery(sql).list();
		for (Object[] object : obj) {
			Shiti st=new Shiti();
			st.setSname(object[0].toString());
			st.setOptionA(object[1].toString());
			st.setOptionB(object[2].toString());
			st.setOptionC(object[3].toString());
			st.setOptionD(object[4].toString());
			st.setAnswer(object[5].toString());
			st.setKemu(object[6].toString());
			list.add(st);
		}
		System.out.println(obj.size());
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	
}
