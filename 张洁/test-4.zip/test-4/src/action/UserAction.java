package action;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.servlet.RequestDispatcher;

import org.apache.struts2.ServletActionContext;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;


import com.opensymphony.xwork2.Action;
import com.sun.xml.internal.bind.v2.runtime.RuntimeUtil.ToStringAdapter;

import dao.HibernateSessionFactory;
import domain.Admin;
import domain.Classes;
import domain.Jvanzi;
import domain.Kaoshiti;
import domain.Mingxi;
import domain.PageBran;
import domain.Shiti;
import domain.Students;
import domain.Teacher;



public class UserAction implements Action {
	private String name;
	private int pagetotal;//��ҳ��
	private List lis;
	private int id;
	private int bid;
	private int jid;
	private int shichang;
	private int miao;
	private int xvhao;
	private List list;
	private Admin admin;
	private Jvanzi jvanzi;
	private Mingxi mingxi;
	private PageBran pageBran;
	private int jiandan;
	private int yiban;
	private int kunnan;
	private int djiandan;
	private int dyiban;
	private int dkunnan;
	private String titype;
	private Shiti shiti;
	public List aname;
	public List  kaoshisess;
	private String tishu;
	private Date data;
	public String list(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "list";
	}
	public String admins(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		if (bid==1) {
			list=session.createCriteria(Students.class).list();
			for (int i = 0; i <list.size(); i++) {
				Students a=	(Students) list.get(i);
				if (a. getShao().equals(admin.getName())&&a.getPwd().equals(admin.getPwd())) {
					ServletActionContext.getRequest().getSession().setAttribute("bm",1);
					ServletActionContext.getRequest().getSession().setAttribute("aname", a);
					return "admins";
				}
			}
		}else if (bid==2) {
			list=session.createCriteria(Teacher.class).list();
			for (int i = 0; i <list.size(); i++) {
				Teacher a=	(Teacher) list.get(i);
				if (a.getTzhanghao().equals(admin.getName())&&a.getPwd().equals(admin.getPwd())) {
					ServletActionContext.getRequest().getSession().setAttribute("bm",2);
					ServletActionContext.getRequest().getSession().setAttribute("aname", a);
					return "admins";
				}
			}
		}else {
			list=session.createCriteria(Admin.class).list();
			for (int i = 0; i <list.size(); i++) {
				Admin a=	(Admin) list.get(i);
				if (a.getName().equals(admin.getName())&&a.getPwd().equals(admin.getPwd())) {
					ServletActionContext.getRequest().getSession().setAttribute("bm",3);
					ServletActionContext.getRequest().getSession().setAttribute("aname", admin);
					return "admins";
				}
			}
		}
		name="�˺Ż��������";
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return ERROR;
	}
	/***
	 * ��ת�������Ƿ���ҳ��
	 * @return
	 */
	public String kkao(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		list=session.createCriteria(Classes.class).list();
		id=id;
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "kkao";
	}
	/***
	 * ��ת�����Ľ���
	 * @return
	 */
	public String kkw(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		List ls=session.createCriteria(Classes.class).list();
		for (int i = 0; i <ls.size(); i++) {
			Classes ca=(Classes) ls.get(i);
			if (ca.getCname().equals(jvanzi.getBanji())) {
				Jvanzi jz=(Jvanzi) session.get(Jvanzi.class, id);
				id=ca.getCid();
				jz.setJtime(jvanzi.getJtime());
				jz.setBanji(jvanzi.getBanji());
				jz.setJstate(jvanzi.getJstate());
				session.update(jz);
				ca.getJvanziSet().add(jz);
			}
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "kkw";
	}
	public String add(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		Jvanzi jz=jvanzi;
		session.save(jz);
		
		String sql="select sid from ";
			sql+=" (select top "+jiandan+" sid from shiti where kemu='"+jvanzi.getKemu()+"' and tyles='"+jvanzi.getJiorbi()+"' and titype='"+titype+"' and stype='��ѡ'  and nandu='��' ";
			sql+=" order by newId() union ";
			sql+=" select top "+yiban+" sid from shiti where kemu='"+jvanzi.getKemu()+"' and tyles='"+jvanzi.getJiorbi()+"' and titype='"+titype+"' and stype='��ѡ'  and  nandu='�е�' ";
			sql+=" order by newId() union ";
			sql+=" select top "+kunnan+" sid from shiti where kemu='"+jvanzi.getKemu()+"' and tyles='"+jvanzi.getJiorbi()+"' and titype='"+titype+"' and stype='��ѡ'  and  nandu='����' ";
			sql+=" order by newId() union ";
			sql+=" select top "+djiandan+" sid from shiti where kemu='"+jvanzi.getKemu()+"' and tyles='"+jvanzi.getJiorbi()+"' and titype='"+titype+"' and stype='��ѡ'  and nandu='��' " ;
			sql+=" order by newId() union ";
			sql+=" select top "+dyiban+" sid from shiti where kemu='"+jvanzi.getKemu()+"' and tyles='"+jvanzi.getJiorbi()+"' and titype='"+titype+"' and stype='��ѡ'  and  nandu='�е�' ";
			sql+=" order by newId() union ";
			sql+=" select top "+dkunnan+" sid from shiti where kemu='"+jvanzi.getKemu()+"' and tyles='"+jvanzi.getJiorbi()+"' and titype='"+titype+"' and stype='��ѡ'  and  nandu='����' ";
			sql+=" order by newId() ) as t ";
			List lis= session.createSQLQuery(sql).list();
			int ss=0;
			for (int i = 0; i < lis.size(); i++) {
				int in=Integer.parseInt(lis.get(i).toString()) ;
				Shiti st=(Shiti) session.get(Shiti.class, in);
				jvanzi.getShitSet().add(st);
			}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "add";
	}
	/**
	 * �Ծ�ҳ��
	 * @return
	 */
	public String jzi(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		lis=session.createCriteria(Jvanzi.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "jz";
	}
	/**
	 * ��ʾ�����Ծ�������
	 * @return
	 */
	public String ksj(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		Jvanzi jz=(Jvanzi) session.get(Jvanzi.class,id);
		jid=id;
		list=new ArrayList();
		Set<Shiti> st=jz.getShitSet();
		for (Shiti shi : st) {
			Shiti s=shi;
			list.add(s);
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "ksj";
	}
	public String adds(){
		ServletActionContext.getRequest().setAttribute("sname",name);
		return "add";
	}
	/***
	 * ���߿���ҳ��
	 * @return
	 */
	public String oper(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		Students s=(Students) session.get(Students.class, id);
		Classes c=s.getClasses();
		lis=new ArrayList();
		Set<Jvanzi> st=c.getJvanziSet();
		for (Jvanzi jvanzi : st) {
			lis.add(jvanzi);
		}
		
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "oper";
	}
	/***
	 * ��ʼ����ҳ��
	 * idΪ����
	 * jid��ʾ��ȥ
	 * pagetotal��ʾ����
	 * name��ʾ��
	 * @return
	 */
	public String kasj(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		id=id;
		
		if (jid==0) {
			Date da=new Date();
			long dint = da.getTime();
			miao=(int) (dint/1000+(shichang*60));
			Jvanzi jz=(Jvanzi) session.get(Jvanzi.class,id);
			//��ȡ������
			lis=new ArrayList();
			Set<Shiti> s=jz.getShitSet();
			for (Shiti shiti : s) {
				lis.add(shiti);
			}
			
			Students sd=(Students) ServletActionContext.getRequest().getSession().getAttribute("aname");
			//��ȡ���������
			list=new ArrayList();
			for (int i = 0; i <lis.size(); i++) {
				Shiti ss=(Shiti) lis.get(i);;
				if (bid==0&&i==0) {
					jid=ss.getSid();
					shiti=ss;
			}
//				else if(ss.){
//					shiti=(Shiti) session.get(Shiti.class, bid);
//				}
				Kaoshiti kst=new Kaoshiti();
				kst.setJid(id);
				kst.setShitiId(ss.getSid());
				kst.setShuliang(jz.getZongfen());
				kst.setYesDaan(ss.getAnswer());
				kst.setSid(sd.getSid());
				kst.setComeTime(new Date());
				list.add(kst);
				jvanzi=jz;
				xvhao=1;
			String hql="select count(*) from Shiti";
			List l =session.createQuery(hql).list();
			for (Object object : l) {
				tishu=object.toString();
				
			}
			
			}
			ServletActionContext.getRequest().getSession().setAttribute("kaoshisess", list);
		}else {
			lis=(List)ServletActionContext.getRequest().getSession().getAttribute("kaoshisess");
			list=new ArrayList();
			tishu=tishu;
			for (int i = 0; i < lis.size(); i++) {
				Kaoshiti kst=(Kaoshiti)lis.get(i);
				if (jid==kst.getShitiId()) {
					kst.setXveshengdaan(name);
				}
				list.add(kst);
			}
			jvanzi=(Jvanzi) session.get(Jvanzi.class, id);
			shiti=(Shiti)session.get(Shiti.class, pagetotal);
			jid=pagetotal;
			xvhao=xvhao;
		}
//		ServletActionContext.getRequest().getSession().setAttribute("kaoshisess", list);
		miao=miao;
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "kasj";
	}
	public String addu(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		
		session.save(shiti);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return ERROR;
	}
	/**
	 * ��ɿ���
	 * @return
	 */
	public String wch(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		int ss=0;
		lis=(List)ServletActionContext.getRequest().getSession().getAttribute("kaoshisess");
		for (int i = 0; i < lis.size(); i++) {
			
			Kaoshiti kst=(Kaoshiti) lis.get(i);
			if (kst.getYesDaan().equals(kst.getXveshengdaan())) {
				ss++;
			}
			data=kst.getComeTime();
			jid=kst.getJid();
			bid=kst.getShuliang();
			session.save(kst);
		}
		ServletActionContext.getRequest().getSession().setAttribute("kaoshisess","");
		Students s=(Students) ServletActionContext.getRequest().getSession().getAttribute("aname");
		
		Mingxi mx=new Mingxi();
		mx.setSid(s.getSid());
		mx.setJid(jid);
		id=bid/lis.size()*ss;
		mx.setComeTime(data);
		mx.setEndTime(new Date());
		mx.setFenshu(id);
		jvanzi=(Jvanzi) session.get(Jvanzi.class, jid);
		mx.setMname(jvanzi.getJname());
		session.save(mx);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "wch";
	}
	public String update(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "update";
	}
	public String logout(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "logout";
	}
	/***
	 * �޸��Ծ�
	 * bid������ȥ
	 * jid�����Ծ�
	 * id��������
	 * @return
	 */
	public String upj(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		Jvanzi c=(Jvanzi) session.get(Jvanzi.class, jid);
		Shiti ss=(Shiti) session.get(Shiti.class, bid);
		Shiti sss=(Shiti) session.get(Shiti.class, id);
		c.getShitSet().remove(ss);
		c.getShitSet().add(sss);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "upj";
	}
	/***
	 * ��ʾ�滻�ľ���
	 * @return
	 */
	public String upda(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		bid=id;
		id=jid;
		lis=session.createCriteria(Shiti.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "upda";
	}
	public String jz(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "jz";
	}
	public String  arti(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		lis=session.createCriteria(Teacher.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "arti";
	}
	public String airm(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		lis=new ArrayList();
		String hql="select s.kemu,count(s.sid), s.tyles   from Shiti s group by s.kemu , s.tyles order by s.kemu" ;
		List<Object[]> studentsList=session.createQuery(hql).list();
		for (Object[] objects : studentsList) {
			Shiti st=new Shiti();
			st.setKemu((String)objects[0]);
			st.setCounts((Long)objects[1]);
			st.setTyles((String)objects[2]);
			lis.add(st);
		}
		int s=1;
		String shitis="";
		list=new ArrayList();
		Shiti str=new Shiti();
		for (int i = 0; i < lis.size(); i++) {
			Shiti st=(Shiti) lis.get(i);
			if (i==s) {
				if (st.getTyles().equals("����")) {
					list.add(str);
					str=new Shiti();
					s=i+2;
					str.setKemu(st.getKemu());
					str.setCounts(st.getCounts());
				}else {
					str.setJishu(st.getCounts());
					list.add(str);
					str=new Shiti();
					s=i+2;
				}
			}else {
				if (st.getTyles().equals("����")) {
					str.setKemu(st.getKemu());
					str.setJishu(st.getCounts());
					list.add(str);
					str=new Shiti();
					s=i+2;
				}else {
					str.setKemu(st.getKemu());
					str.setCounts(st.getCounts());
					if (i==lis.size()-1) {
						list.add(str);
					}
				}
			}
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "airm";
	}
	/***
	 * ���Բ���
	 * @return
	 */
	public String bi(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		list=session.createCriteria(Shiti.class).list();
		ServletActionContext.getRequest().setAttribute("sname",name);
		lis=new ArrayList();
		for (int i = 0; i < list.size(); i++) {
			Shiti shiti= (Shiti) list.get(i);
			if (shiti.getKemu().equals(name)&&shiti.getTyles().equals("����")) {
				lis.add(shiti);
			}
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "bishi";
	}
	/***
	 * ���Բ���
	 * @return
	 */
	public String ji(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		list=session.createCriteria(Shiti.class).list();
		lis=new ArrayList();
		for (int i = 0; i < list.size(); i++) {
			Shiti shiti= (Shiti) list.get(i);
			if (shiti.getKemu().equals(name)&&shiti.getTyles().equals("����")) {
				lis.add(shiti);
			}
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "bishi";
	}
	public String baxj(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		lis=session.createCriteria(Mingxi.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "baxj";
	}
	/****
	 * ��ʾ��ϸ
	 * @return
	 */
	public String bamx(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		list=new ArrayList();
		String sql="select s.sname,s.optionA,s.optionB,s.optionC,s.optionD,s.answer,ks.xveshengdaan from Shiti s inner join Kaoshiti ks on ks.shitiId=s.sid where ks.jid="+id+" and ks.sid="+bid;
		List<Object[]> obj=session.createSQLQuery(sql).list();
		for (Object[] object : obj) {
			Shiti st=new Shiti();
			st.setSname(object[0].toString());
			st.setOptionA(object[1].toString());
			st.setOptionB(object[2].toString());
			st.setOptionC(object[3].toString());
			st.setOptionD(object[4].toString());
			if (object[6]==null) {
				object[6]="δ��";
			}
			st.setKemu(object[6].toString());
			list.add(st);
			st.setAnswer(object[5].toString());
			st.setKemu(object[6].toString());
			
		}
		jiandan=obj.size();
		jvanzi=(Jvanzi) session.get(Jvanzi.class, id);
		mingxi=(Mingxi) session.get(Mingxi.class, jid);
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return "bamx";
	}
	public String updates(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return ERROR;
	}
	public String delet(){
		Session session=HibernateSessionFactory.getSession();
		Transaction transaction=session.beginTransaction();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return ERROR;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPagetotal() {
		return pagetotal;
	}
	public void setPagetotal(int pagetotal) {
		this.pagetotal = pagetotal;
	}
	public List getLis() {
		return lis;
	}
	public void setLis(List lis) {
		this.lis = lis;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public List getList() {
		return list;
	}
	public void setList(List list) {
		this.list = list;
	}
	public PageBran getPageBran() {
		return pageBran;
	}
	public void setPageBran(PageBran pageBran) {
		this.pageBran = pageBran;
	}
	public Admin getAdmin() {
		return admin;
	}
	public void setAdmin(Admin admin) {
		this.admin = admin;
	}
	public Jvanzi getJvanzi() {
		return jvanzi;
	}
	public void setJvanzi(Jvanzi jvanzi) {
		this.jvanzi = jvanzi;
	}
	
	public int getJiandan() {
		return jiandan;
	}
	public void setJiandan(int jiandan) {
		this.jiandan = jiandan;
	}
	public int getYiban() {
		return yiban;
	}
	public void setYiban(int yiban) {
		this.yiban = yiban;
	}
	public int getKunnan() {
		return kunnan;
	}
	public void setKunnan(int kunnan) {
		this.kunnan = kunnan;
	}
	public int getDjiandan() {
		return djiandan;
	}
	public void setDjiandan(int djiandan) {
		this.djiandan = djiandan;
	}
	public int getDyiban() {
		return dyiban;
	}
	public void setDyiban(int dyiban) {
		this.dyiban = dyiban;
	}
	public int getDkunnan() {
		return dkunnan;
	}
	public void setDkunnan(int dkunnan) {
		this.dkunnan = dkunnan;
	}
	public String getTitype() {
		return titype;
	}
	public void setTitype(String titype) {
		this.titype = titype;
	}
	public Shiti getShiti() {
		return shiti;
	}
	public void setShiti(Shiti shiti) {
		this.shiti = shiti;
	}
	public int getJid() {
		return jid;
	}
	public void setJid(int jid) {
		this.jid = jid;
	}
	public List getAname() {
		return aname;
	}
	public void setAname(List aname) {
		this.aname = aname;
	}
	public List getKaoshisess() {
		return kaoshisess;
	}
	public void setKaoshisess(List kaoshisess) {
		this.kaoshisess = kaoshisess;
	}
	public int getXvhao() {
		return xvhao;
	}
	public void setXvhao(int xvhao) {
		this.xvhao = xvhao;
	}
	public String getTishu() {
		return tishu;
	}
	public void setTishu(String tishu) {
		this.tishu = tishu;
	}
	public Date getData() {
		return data;
	}
	public void setData(Date data) {
		this.data = data;
	}
	public int getShichang() {
		return shichang;
	}
	public void setShichang(int shichang) {
		this.shichang = shichang;
	}
	public int getMiao() {
		return miao;
	}
	public void setMiao(int miao) {
		this.miao = miao;
	}
	public Mingxi getMingxi() {
		return mingxi;
	}
	public void setMingxi(Mingxi mingxi) {
		this.mingxi = mingxi;
	}
	
	
	
	
	
	

}
