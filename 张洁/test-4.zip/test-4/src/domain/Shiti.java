package domain;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Shiti {
	private int sid;
	private String stype;
	private String sname;
	private String optionA;
	private String  optionB;
	private String  optionC;
	private String  optionD;
	private String answer;//��
	private String nandu;
	private String titype;
	private String kemu;
	private Long counts;
	private Tiku tiku;
	private String tyles;//��ʹ����
	private Long jishu;
	private Set<Jvanzi> jvanziSet=new HashSet<Jvanzi>();
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getStype() {
		return stype;
	}
	public void setStype(String stype) {
		this.stype = stype;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getOptionA() {
		return optionA;
	}
	public void setOptionA(String optionA) {
		this.optionA = optionA;
	}
	public String getOptionB() {
		return optionB;
	}
	public void setOptionB(String optionB) {
		this.optionB = optionB;
	}
	public String getOptionC() {
		return optionC;
	}
	public void setOptionC(String optionC) {
		this.optionC = optionC;
	}
	public String getOptionD() {
		return optionD;
	}
	public void setOptionD(String optionD) {
		this.optionD = optionD;
	}
	
	
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	public Tiku getTiku() {
		return tiku;
	}
	public void setTiku(Tiku tiku) {
		this.tiku = tiku;
	}
	public String getNandu() {
		return nandu;
	}
	public void setNandu(String nandu) {
		this.nandu = nandu;
	}
	public String getTitype() {
		return titype;
	}
	public void setTitype(String titype) {
		this.titype = titype;
	}
	public String getKemu() {
		return kemu;
	}
	public void setKemu(String kemu) {
		this.kemu = kemu;
	}
	public Long getCounts() {
		return counts;
	}
	public void setCounts(Long counts) {
		this.counts = counts;
	}
	public String getTyles() {
		return tyles;
	}
	public void setTyles(String tyles) {
		this.tyles = tyles;
	}
	public Long getJishu() {
		return jishu;
	}
	public void setJishu(Long jishu) {
		this.jishu = jishu;
	}
	public Set<Jvanzi> getJvanziSet() {
		return jvanziSet;
	}
	public void setJvanziSet(Set<Jvanzi> jvanziSet) {
		this.jvanziSet = jvanziSet;
	}
	
	
	
	
}
