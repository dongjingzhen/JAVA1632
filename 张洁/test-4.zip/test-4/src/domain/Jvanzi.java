package domain;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Jvanzi {
	private int jid;
	private String jname;
	private String jiorbi;
	private String kemu;
	private String banji;
	private int shichang;//����ʱ��
	private int zongfen;
	private int tishu;//������
	private Date jtime;
	private String jstate;//����״̬
	private Set<Shiti> shitSet=new HashSet<Shiti>();
	private Set<Classes> classesSet=new HashSet<Classes>();
	private Shiti shiti;
	public int getJid() {
		return jid;
	}
	public void setJid(int jid) {
		this.jid = jid;
	}
	public String getJname() {
		return jname;
	}
	public void setJname(String jname) {
		this.jname = jname;
	}
	public int getShichang() {
		return shichang;
	}
	public void setShichang(int shichang) {
		this.shichang = shichang;
	}
	public Date getJtime() {
		return jtime;
	}
	public void setJtime(Date jtime) {
		this.jtime = jtime;
	}
	public String getJstate() {
		return jstate;
	}
	public void setJstate(String jstate) {
		this.jstate = jstate;
	}
	public Set<Shiti> getShitSet() {
		return shitSet;
	}
	public void setShitSet(Set<Shiti> shitSet) {
		this.shitSet = shitSet;
	}
	public String getJiorbi() {
		return jiorbi;
	}
	public void setJiorbi(String jiorbi) {
		this.jiorbi = jiorbi;
	}
	public String getKemu() {
		return kemu;
	}
	public void setKemu(String kemu) {
		this.kemu = kemu;
	}
	public String getBanji() {
		return banji;
	}
	public void setBanji(String banji) {
		this.banji = banji;
	}
	public int getZongfen() {
		return zongfen;
	}
	public void setZongfen(int zongfen) {
		this.zongfen = zongfen;
	}
	public Shiti getShiti() {
		return shiti;
	}
	public void setShiti(Shiti shiti) {
		this.shiti = shiti;
	}
	public Set<Classes> getClassesSet() {
		return classesSet;
	}
	public void setClassesSet(Set<Classes> classesSet) {
		this.classesSet = classesSet;
	}
	public int getTishu() {
		return tishu;
	}
	public void setTishu(int tishu) {
		this.tishu = tishu;
	}
	
	
	

}
