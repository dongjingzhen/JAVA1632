package domain;

import java.util.Date;

public class Kaoshiti {
	private int kid;
	private int sid;
	private int jid;//����id
	private int shuliang;//����
	private String xveshengdaan;//ѧ����
	private int shitiId;//ѧ��id
	private String yesDaan;//��ȷ��
	private Date comeTime;
	public int getShuliang() {
		return shuliang;
	}
	public void setShuliang(int shuliang) {
		this.shuliang = shuliang;
	}
	
	public String getXveshengdaan() {
		return xveshengdaan;
	}
	public void setXveshengdaan(String xveshengdaan) {
		this.xveshengdaan = xveshengdaan;
	}
	public int getShitiId() {
		return shitiId;
	}
	public void setShitiId(int shitiId) {
		this.shitiId = shitiId;
	}
	public String getYesDaan() {
		return yesDaan;
	}
	public void setYesDaan(String yesDaan) {
		this.yesDaan = yesDaan;
	}
	public int getKid() {
		return kid;
	}
	public void setKid(int kid) {
		this.kid = kid;
	}
	public int getJid() {
		return jid;
	}
	public void setJid(int jid) {
		this.jid = jid;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public Date getComeTime() {
		return comeTime;
	}
	public void setComeTime(Date comeTime) {
		this.comeTime = comeTime;
	}
	

}
